"""เปิดหน้าโปรแกรม:  python app.py   (ตัวเลือก: --port 7860 --host 0.0.0.0 --no-browser)"""
import argparse

from forge import registry_bootstrap  # noqa: F401  (โหลด provider ทั้งหมด)
from forge.ui.app import launch


def main() -> None:
    ap = argparse.ArgumentParser(description="ShortsForge UI")
    ap.add_argument("--host", default="127.0.0.1", help="ใช้ 0.0.0.0 ถ้าจะเปิดจากเครื่องอื่น (ระวัง: ใครเข้าได้ก็ใช้ API key ของคุณได้)")
    ap.add_argument("--port", type=int, default=7860)
    ap.add_argument("--no-browser", action="store_true")
    a = ap.parse_args()
    launch(server_name=a.host, server_port=a.port, inbrowser=not a.no_browser)


if __name__ == "__main__":
    main()
