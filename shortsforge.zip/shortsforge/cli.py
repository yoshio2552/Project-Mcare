"""สร้างคลิปแบบไม่เปิดหน้าจอ (ใช้กับสคริปต์/เซิร์ฟเวอร์)

  python cli.py "เทคนิคนอนหลับลึก" --seconds 35 --scenes 5
  python cli.py "demo" --mock                  # ทดลองทั้งระบบโดยไม่ใช้ API key
  python cli.py --project <id> --from-step visuals   # ทำต่อ/ทำซ้ำจากสเต็ปที่ต้องการ
  python cli.py --list
"""
import argparse
import sys

from forge import registry_bootstrap  # noqa: F401
from forge.core.errors import ForgeError
from forge.core.models import STEP_LABELS, STEP_ORDER
from forge.studio import Studio


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="ShortsForge CLI")
    ap.add_argument("topic", nargs="?", help="หัวข้อคลิป (ถ้าไม่ระบุต้องใช้ --project)")
    ap.add_argument("--project", help="id โปรเจกต์เดิม")
    ap.add_argument("--list", action="store_true", help="แสดงโปรเจกต์ทั้งหมด")
    ap.add_argument("--seconds", type=int, help="ความยาวเป้าหมาย (วินาที)")
    ap.add_argument("--scenes", type=int, help="จำนวนฉาก")
    ap.add_argument("--lang", choices=["th", "en"], help="ภาษา")
    ap.add_argument("--from-step", choices=STEP_ORDER, help="เริ่มจากสเต็ปนี้ (ค่าตั้งต้น: สเต็ปแรกที่ยังไม่เสร็จ)")
    ap.add_argument("--to-step", choices=STEP_ORDER, default="render")
    ap.add_argument("--mock", action="store_true", help="ใช้ provider จำลองทั้งหมด (ไม่เรียก API ไม่เก็บลงไฟล์ตั้งค่า)")
    ap.add_argument("--edit", help="สั่งแก้ด้วยภาษาธรรมดา แล้วรันต่อ (ต้องใช้ --project)")
    a = ap.parse_args(argv)

    st = Studio()
    if a.list:
        for x in st.projects():
            print(f"{x['id']}  {x['title']}")
        return 0
    if a.mock:
        st.settings.update({"llm.provider": "mock", "tts.provider": "mock", "stock.providers": ["mock"],
                            "music.provider": "mock"}, save=False)
    try:
        if a.project:
            p = st.open(a.project)
        elif a.topic:
            p = st.new_project(a.topic, seconds=a.seconds, scenes=a.scenes, language=a.lang)
        else:
            ap.error("ต้องระบุหัวข้อ หรือ --project")
        if a.edit:
            plan = st.plan_edit(p, a.edit)
            print(plan.explanation or "")
            if plan.clarify:
                print("❓", plan.clarify)
                return 2
            for line in plan.describe(p):
                print(" •", line)
            res = st.apply_plan(p, plan)
            p = st.open(p.id)
            a.from_step = a.from_step or ("script" if res.regenerate_script else None)
        start = a.from_step or st.next_start(p)
        print(f"โปรเจกต์ {p.id} — เริ่มที่สเต็ป: {STEP_LABELS[start]}")

        def show(ev):
            if ev.status in ("running", "done", "error", "info"):
                print(f"[{STEP_LABELS.get(ev.step, ev.step)}] {ev.status}: {ev.message}")

        st.run(p, start=start, stop=a.to_step, on_event=show)
    except ForgeError as ex:
        print(f"ผิดพลาด: {ex}", file=sys.stderr)
        return 1
    p = st.open(p.id)
    if p.outputs.get("video"):
        print("วิดีโอ:", p.outputs["video"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
