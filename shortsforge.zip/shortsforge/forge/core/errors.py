"""ข้อผิดพลาดมาตรฐานของระบบ — ข้อความทั้งหมดต้องอ่านแล้วรู้ว่าแก้อะไร"""


class ForgeError(Exception):
    """ข้อผิดพลาดพื้นฐานของระบบ"""


class ConfigError(ForgeError):
    """ตั้งค่าไม่ครบ เช่น ยังไม่ใส่ API key"""


class ProviderError(ForgeError):
    """ผู้ให้บริการภายนอก (API) ตอบผิดพลาด"""


class QuotaExceeded(ProviderError):
    """โควตารายวันของ API หมด — ลองซ้ำตอนนี้ไม่มีประโยชน์"""


class FFmpegError(ForgeError):
    """คำสั่ง ffmpeg ล้มเหลว"""


class EditError(ForgeError):
    """คำสั่งแก้ไขที่ AI สร้างมาใช้ไม่ได้"""


class Cancelled(ForgeError):
    """ผู้ใช้กดยกเลิกระหว่างทำงาน"""
