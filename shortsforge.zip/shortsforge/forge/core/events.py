"""ระบบแจ้งความคืบหน้า: pipeline ส่ง Event → UI/CLI เลือกวิธีแสดงเอง"""
from __future__ import annotations

import threading
from dataclasses import dataclass
from typing import Callable

from .errors import Cancelled


@dataclass
class Event:
    step: str                 # script | voice | visuals | music | captions | render | edit
    status: str               # running | done | error | skipped | info
    message: str = ""
    progress: float = 0.0     # 0..1 ภายในสเต็ปนั้น
    scene_id: int | None = None


class CancelToken:
    def __init__(self) -> None:
        self._ev = threading.Event()

    def cancel(self) -> None:
        self._ev.set()

    @property
    def cancelled(self) -> bool:
        return self._ev.is_set()

    def check(self) -> None:
        if self._ev.is_set():
            raise Cancelled("ผู้ใช้ยกเลิกการทำงาน")


class Emitter:
    def __init__(self) -> None:
        self._subs: list[Callable[[Event], None]] = []

    def subscribe(self, fn: Callable[[Event], None]) -> None:
        self._subs.append(fn)

    def unsubscribe(self, fn: Callable[[Event], None]) -> None:
        if fn in self._subs:
            self._subs.remove(fn)

    def __call__(self, step: str, status: str, message: str = "",
                 progress: float = 0.0, scene_id: int | None = None) -> None:
        ev = Event(step, status, message, progress, scene_id)
        for fn in list(self._subs):
            try:
                fn(ev)
            except Exception:
                pass  # ตัวฟังพังต้องไม่ทำให้งานหลักพัง
