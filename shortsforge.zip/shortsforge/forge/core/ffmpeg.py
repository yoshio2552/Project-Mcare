"""ตัวช่วยเรียก ffmpeg/ffprobe — จุดเดียวที่โปรเจกต์ยุ่งกับ subprocess"""
from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

from .errors import ConfigError, FFmpegError


def require_ffmpeg() -> None:
    for tool in ("ffmpeg", "ffprobe"):
        if not shutil.which(tool):
            raise ConfigError(
                f"ไม่พบ {tool} ในเครื่อง — ติดตั้ง ffmpeg แล้วเปิดโปรแกรมใหม่ "
                "(Windows: winget install Gyan.FFmpeg)"
            )


def run(args: list[str], *, timeout: float = 900, loglevel: str = "error", cwd: str | Path | None = None) -> str:
    """รัน ffmpeg; ถ้าพังจะโชว์ท้าย stderr (ส่วนที่บอกสาเหตุจริง)
    cwd: ใช้ให้ path ใน filter (ซับ/ฟอนต์) เป็นชื่อสั้นๆ จะได้ไม่ติดปัญหา escape บน Windows"""
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", loglevel, "-y", *map(str, args)]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=cwd)
    except subprocess.TimeoutExpired:
        raise FFmpegError(f"ffmpeg ใช้เวลานานเกิน {int(timeout)} วินาที")
    if p.returncode != 0:
        tail = "\n".join(p.stderr.strip().splitlines()[-8:])
        raise FFmpegError(f"ffmpeg ล้มเหลว:\n{tail}")
    return p.stderr


def probe(path: str | Path) -> dict:
    """อ่านข้อมูลไฟล์สื่อ: duration, width, height, fps, has_audio"""
    p = subprocess.run(
        ["ffprobe", "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(path)],
        capture_output=True, text=True, timeout=60,
    )
    if p.returncode != 0:
        raise FFmpegError(f"อ่านไฟล์สื่อไม่ได้: {path}\n{p.stderr.strip()[-300:]}")
    info = json.loads(p.stdout or "{}")
    out = {"duration": float(info.get("format", {}).get("duration") or 0.0),
           "width": 0, "height": 0, "fps": 0.0, "has_audio": False}
    for s in info.get("streams", []):
        if s.get("codec_type") == "video" and not out["width"]:
            out["width"], out["height"] = int(s.get("width", 0)), int(s.get("height", 0))
            num, _, den = (s.get("avg_frame_rate") or "0/1").partition("/")
            try:
                out["fps"] = float(num) / float(den or 1)
            except (ValueError, ZeroDivisionError):
                out["fps"] = 0.0
        elif s.get("codec_type") == "audio":
            out["has_audio"] = True
    return out


def duration(path: str | Path) -> float:
    return probe(path)["duration"]
