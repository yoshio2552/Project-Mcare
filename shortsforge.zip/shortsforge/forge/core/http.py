"""HTTP กลางของระบบ: retry อัตโนมัติ + ซ่อน API key ไม่ให้หลุดลงข้อความ error/log"""
from __future__ import annotations

import os
import re
import time
from pathlib import Path
from typing import Iterable

import requests

from .errors import ProviderError, QuotaExceeded

_REDACT: set[str] = set()


def set_redactions(secrets: Iterable[str]) -> None:
    """ลงทะเบียนค่า secret ที่ต้องถูกปิดบังในข้อความ error"""
    _REDACT.clear()
    _REDACT.update(s for s in secrets if s and len(s) >= 6)


def redact(text: str) -> str:
    for s in _REDACT:
        text = text.replace(s, "***")
    return text


def request(method: str, url: str, *, retries: int = 3, backoff: float = 1.6,
            timeout: float = 60, ok: tuple[int, ...] = (200,), **kw) -> requests.Response:
    """เรียก HTTP พร้อม retry เมื่อเจอ 429/5xx/เน็ตหลุด"""
    last = ""
    for attempt in range(1, retries + 1):
        try:
            r = requests.request(method, url, timeout=timeout, **kw)
        except requests.RequestException as e:
            last = redact(f"{type(e).__name__}: {e}")
        else:
            if r.status_code in ok:
                return r
            full = redact(r.text[:3000])
            body = redact(r.text[:400].replace("\n", " "))
            last = f"HTTP {r.status_code}: {body}"
            if r.status_code not in (429, 500, 502, 503, 504):
                raise ProviderError(last)
            if r.status_code == 429 and re.search(r"PerDay|per day|daily", full, re.I):
                raise QuotaExceeded(last)               # โควตารายวันหมด — รอไปก็ไม่หาย
            wait = r.headers.get("Retry-After")
            m = re.search(r'"retryDelay"\s*:\s*"(\d+(?:\.\d+)?)s"', full)   # Gemini บอกให้รอกี่วินาที
            delay = float(wait) if wait and wait.isdigit() else (float(m.group(1)) if m else None)
            if delay is not None and attempt < retries:
                if delay > 65:
                    raise QuotaExceeded(last)
                time.sleep(min(delay, 65))
                continue
        if attempt < retries:
            time.sleep(backoff ** attempt)
    raise ProviderError(f"เรียก API ไม่สำเร็จหลังลอง {retries} ครั้ง — {last}")


def download(url: str, dest: Path, *, headers: dict | None = None, timeout: float = 120) -> Path:
    """โหลดไฟล์แบบ stream ลงไฟล์ชั่วคราวก่อน แล้วค่อยเปลี่ยนชื่อ (ไม่ทิ้งไฟล์ครึ่งๆ กลางๆ)"""
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    last = ""
    for attempt in range(1, 4):
        try:
            with requests.get(url, headers=headers, stream=True, timeout=timeout) as r:
                if r.status_code != 200:
                    last = f"HTTP {r.status_code}"
                else:
                    with open(tmp, "wb") as f:
                        for chunk in r.iter_content(1 << 16):
                            f.write(chunk)
                    if tmp.stat().st_size > 1024:
                        os.replace(tmp, dest)
                        return dest
                    last = "ไฟล์ที่ได้เล็กผิดปกติ"
        except requests.RequestException as e:
            last = redact(f"{type(e).__name__}: {e}")
        time.sleep(1.5 * attempt)
    tmp.unlink(missing_ok=True)
    raise ProviderError(f"ดาวน์โหลดไม่สำเร็จ ({last})")
