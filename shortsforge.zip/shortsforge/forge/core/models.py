"""โมเดลข้อมูลของโปรเจกต์ — เป็น dataclass ล้วน เก็บเป็น JSON อ่านด้วยตาได้

กฎ: ไฟล์ที่สร้างขึ้นเก็บ "fingerprint" (fp) ของ input ที่ใช้สร้าง
ถ้า input เปลี่ยน fp ไม่ตรง → สร้างใหม่เฉพาะส่วนนั้น (ไม่เสียเครดิต API ซ้ำ)
"""
from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import asdict, dataclass, field, fields
from typing import Any

STEP_ORDER = ["script", "voice", "visuals", "music", "captions", "render"]
STEP_LABELS = {
    "script": "เขียนบท",
    "voice": "เสียงพากย์",
    "visuals": "หาภาพ/คลิป",
    "music": "เพลงประกอบ",
    "captions": "ซับไตเติล",
    "render": "เรนเดอร์",
}
# สเต็ปไหนต้องรอสเต็ปไหน (แก้ต้นทาง → ปลายทางถูกทำเครื่องหมาย "ต้องทำใหม่")
DEPENDS = {
    "voice": ["script"],
    "visuals": ["voice"],
    "music": ["voice"],
    "captions": ["voice"],
    "render": ["visuals", "music", "captions"],
}


def fingerprint(*parts: Any) -> str:
    raw = json.dumps(parts, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:12]


def downstream(step: str) -> list[str]:
    """สเต็ปทั้งหมดที่ได้รับผลกระทบเมื่อ step เปลี่ยน (รวมตัวมันเอง)"""
    hit = {step}
    changed = True
    while changed:
        changed = False
        for s, deps in DEPENDS.items():
            if s not in hit and any(d in hit for d in deps):
                hit.add(s)
                changed = True
    return [s for s in STEP_ORDER if s in hit]


def _load(cls, data: dict | None):
    """โหลด dataclass แบบทนทาน: ฟิลด์ที่ไม่รู้จักข้าม ฟิลด์ที่ขาดใช้ค่าเริ่มต้น"""
    data = data or {}
    names = {f.name for f in fields(cls)}
    return cls(**{k: v for k, v in data.items() if k in names})


@dataclass
class Word:
    text: str
    start: float
    end: float


@dataclass
class Shot:
    """ช็อตหนึ่งในฉาก — ฉากยาวจะถูกแบ่งเป็นหลายช็อตเพื่อให้ภาพเปลี่ยนจังหวะ ไม่เด๋อ"""
    keyword: str = ""
    clip: dict | None = None      # ข้อมูลคลิปที่เลือก (provider,id,url,preview,duration,credit,...)
    path: str = ""                # ไฟล์ที่ดาวน์โหลดแล้ว
    start: float = 0.0            # เริ่มตัดจากวินาทีที่เท่าไรของคลิปต้นทาง
    duration: float = 0.0         # ความยาวบน timeline
    pinned: bool = False          # ผู้ใช้เลือกเอง → ระบบห้ามเปลี่ยนให้อัตโนมัติ
    beat: int = 0                 # ช็อตนี้เล่าประโยคย่อย (beat) ที่เท่าไรของฉาก
    part: int = 0                 # beat ยาว → แบ่งเป็นหลายช็อต: ชิ้นที่เท่าไร
    start_locked: bool = False    # ผู้ใช้เลื่อนจุดเริ่มคลิปเอง → ระบบไม่สุ่มใหม่
    score: float | None = None    # คะแนนความตรงบริบทจาก AI (0–10) ถ้ามี
    why: str = ""                 # เหตุผลสั้นๆ จาก AI


@dataclass
class Scene:
    id: int
    role: str = "body"            # hook | body | cta
    narration: str = ""
    keywords: list[str] = field(default_factory=list)   # คำค้นหลักของแต่ละ beat (ไว้โชว์/ให้ AI อ่าน — ตัวจริงอยู่ใน beats)
    # beat = ช่วงคำพูดสั้นๆ + ภาพที่ควรเห็นตอนพูดช่วงนั้น → ระบบตัดภาพตรงจังหวะคำพูด
    # {"text": "ข้อความช่วงนี้", "visual": "ภาพที่ควรเห็น (อังกฤษ)", "queries": ["คำค้นเจาะจง", "กว้างขึ้น", "กว้างสุด"],
    #  "start_word": None | ดัชนีคำที่ผู้ใช้เลือกให้ตัดเข้าช็อตนี้}
    beats: list[dict] = field(default_factory=list)
    note: str = ""                # ทิศทางภาพ/อารมณ์ (ให้คนอ่าน และให้ AI ใช้ตอนแก้)
    audio_path: str = ""
    audio_duration: float = 0.0
    words: list[Word] = field(default_factory=list)
    shots: list[Shot] = field(default_factory=list)
    candidates: list[dict] = field(default_factory=list)   # คลิปทางเลือกให้เลือกใน gallery
    fp: dict = field(default_factory=dict)                 # {"voice": ..., "visual": ...}
    pause: float | None = None    # เว้นหลังฉาก (None = ใช้ค่าตั้งต้น)
    avoid: list[str] = field(default_factory=list)         # คลิป (provider:id) ที่ผู้ใช้ไม่เอาในฉากนี้

    @classmethod
    def from_dict(cls, d: dict) -> "Scene":
        s = _load(cls, d)
        s.words = [_load(Word, w) for w in (d.get("words") or [])]
        s.shots = [_load(Shot, x) for x in (d.get("shots") or [])]
        return s


@dataclass
class MusicTrack:
    prompt: str = ""
    path: str = ""
    duration: float = 0.0
    provider: str = ""
    fp: str = ""
    meta: dict = field(default_factory=dict)


@dataclass
class StepState:
    status: str = "pending"       # pending | running | done | stale | error
    message: str = ""
    updated: float = 0.0


@dataclass
class Project:
    id: str
    topic: str = ""
    title: str = ""
    language: str = "th"
    created: float = field(default_factory=time.time)
    scenes: list[Scene] = field(default_factory=list)
    music: MusicTrack = field(default_factory=MusicTrack)
    steps: dict[str, StepState] = field(default_factory=dict)
    overrides: dict = field(default_factory=dict)   # ค่าตั้งค่าเฉพาะโปรเจกต์นี้ (เช่น ระดับเสียงเพลง)
    outputs: dict = field(default_factory=dict)     # {"video":..., "ass":..., "credits":...}
    measured_cps: float = 0.0                       # ตัวอักษรต่อวินาทีที่วัดได้จากเสียงจริง
    next_scene_id: int = 1
    revision: int = 0

    # ---------- สร้าง/โหลด ----------
    @classmethod
    def new(cls, topic: str, language: str = "th") -> "Project":
        p = cls(id=time.strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:4], topic=topic, language=language)
        p.steps = {s: StepState() for s in STEP_ORDER}
        return p

    @classmethod
    def from_dict(cls, d: dict) -> "Project":
        p = _load(cls, d)
        p.scenes = [Scene.from_dict(s) for s in (d.get("scenes") or [])]
        p.music = _load(MusicTrack, d.get("music"))
        p.steps = {s: _load(StepState, (d.get("steps") or {}).get(s)) for s in STEP_ORDER}
        return p

    def to_dict(self) -> dict:
        return asdict(self)

    # ---------- ตัวช่วย ----------
    def scene(self, scene_id: int) -> Scene:
        for s in self.scenes:
            if s.id == scene_id:
                return s
        raise KeyError(f"ไม่มีฉาก id={scene_id}")

    def index_of(self, scene_id: int) -> int:
        for i, s in enumerate(self.scenes):
            if s.id == scene_id:
                return i
        raise KeyError(f"ไม่มีฉาก id={scene_id}")

    def new_scene(self, **kw) -> Scene:
        s = Scene(id=self.next_scene_id, **kw)
        self.next_scene_id += 1
        return s

    def set_step(self, step: str, status: str, message: str = "") -> None:
        self.steps[step] = StepState(status, message, time.time())

    def invalidate(self, step: str, message: str = "ข้อมูลต้นทางเปลี่ยน — ต้องทำใหม่") -> list[str]:
        """ทำเครื่องหมายสเต็ปนี้และสเต็ปปลายน้ำทั้งหมดว่า stale (ถ้าเคยทำเสร็จแล้ว)"""
        hit = []
        for s in downstream(step):
            if self.steps.get(s) and self.steps[s].status in ("done", "error", "stale"):
                self.set_step(s, "stale", message)
                hit.append(s)
        return hit
