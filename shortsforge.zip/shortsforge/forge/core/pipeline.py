"""ตัวรัน pipeline — รู้แค่ "ลำดับสเต็ป + สถานะ" ไม่รู้ว่าแต่ละสเต็ปทำอะไรข้างใน

ทำงานแบบ incremental: สเต็ปที่สถานะ done ข้ามได้เลย, สเต็ปที่ stale/pending จะรัน
และข้างในสเต็ปเองใช้ fingerprint ข้ามงานย่อยที่ไม่เปลี่ยน (เช่น ฉากที่บทเดิมไม่ต้องพากย์ใหม่)
"""
from __future__ import annotations

import queue
import threading
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Iterator

from .errors import Cancelled, ForgeError
from .events import CancelToken, Emitter, Event
from .models import STEP_ORDER, Project, fingerprint
from .project_store import ProjectStore
from .settings import Cfg


@dataclass
class Context:
    project: Project
    cfg: Cfg
    store: ProjectStore
    emit: Emitter
    cancel: CancelToken

    def provider(self, kind: str, name: str | None = None):
        from . import registry
        return registry.create(kind, name or self.cfg[f"{kind}.provider"], self.cfg)

    def dir(self, sub: str):
        return self.store.asset_dir(self.project, sub)

    def save(self) -> None:
        self.store.save(self.project)


class Step(ABC):
    name: str = ""
    # คีย์ตั้งค่าที่มีผลต่อผลลัพธ์ของสเต็ปนี้ — ถ้าค่าเปลี่ยนหลังทำเสร็จ สเต็ปนี้และปลายน้ำจะถูกทำเครื่องหมาย "ต้องทำใหม่"
    config_keys: tuple[str, ...] = ()

    @abstractmethod
    def run(self, ctx: Context) -> str:
        """ทำงานของสเต็ป คืนข้อความสรุปสั้นๆ สำหรับโชว์ใน UI"""

    def config_sig(self, cfg) -> str:
        return fingerprint([cfg.get(k) for k in self.config_keys])


class Pipeline:
    def __init__(self, steps: list[Step]):
        self.steps = {s.name: s for s in steps}
        missing = [n for n in STEP_ORDER if n not in self.steps]
        if missing:
            raise ValueError(f"pipeline ขาดสเต็ป: {missing}")

    def refresh(self, project: Project, cfg) -> list[str]:
        """เทียบค่าตั้งค่าตอนนี้กับตอนที่แต่ละสเต็ปทำเสร็จ — ที่เปลี่ยนไปจะถูกทำเครื่องหมาย stale
        (เช่น เปลี่ยนความเร็วพูดหรือสีซับ แล้วสเต็ปที่เกี่ยวข้องต้องทำใหม่ ไม่ใช่ข้ามเพราะ 'เสร็จแล้ว')"""
        sigs = project.outputs.get("sigs") or {}
        hit: list[str] = []
        for name in STEP_ORDER:
            old = sigs.get(name)
            if old and project.steps[name].status == "done" and old != self.steps[name].config_sig(cfg):
                hit += [s for s in project.invalidate(name, "ตั้งค่าเปลี่ยน — ต้องทำใหม่") if s not in hit]
        return hit

    def run(self, ctx: Context, *, start: str = "script", stop: str = "render", force: set[str] | None = None) -> None:
        force = force or set()
        order = STEP_ORDER[STEP_ORDER.index(start): STEP_ORDER.index(stop) + 1]
        p = ctx.project
        self.refresh(p, ctx.cfg)
        for name in order:
            ctx.cancel.check()
            state = p.steps[name]
            if state.status == "done" and name not in force:
                ctx.emit(name, "skipped", state.message or "ทำเสร็จแล้ว ข้ามไป")
                continue
            p.set_step(name, "running", "กำลังทำงาน…")
            ctx.save()
            ctx.emit(name, "running", "เริ่ม", 0.0)
            try:
                msg = self.steps[name].run(ctx) or "เสร็จ"
            except Cancelled:
                p.set_step(name, "stale", "ยกเลิกกลางทาง")
                ctx.save()
                raise
            except ForgeError as e:
                p.set_step(name, "error", str(e))
                ctx.save()
                ctx.emit(name, "error", str(e))
                raise
            except Exception as e:  # บั๊กที่ไม่คาดคิด — เก็บสถานะไว้ให้ UI โชว์ แล้วโยนต่อ
                p.set_step(name, "error", f"{type(e).__name__}: {e}")
                ctx.save()
                ctx.emit(name, "error", f"{type(e).__name__}: {e}")
                raise
            p.set_step(name, "done", msg)
            p.outputs.setdefault("sigs", {})[name] = self.steps[name].config_sig(ctx.cfg)
            ctx.save()
            ctx.emit(name, "done", msg, 1.0)

    def run_iter(self, ctx: Context, **kw) -> Iterator[Event]:
        """รันใน thread แยก แล้วไล่ส่ง Event ออกมา — ใช้กับ Gradio generator ให้ UI อัปเดตสด"""
        q: queue.Queue = queue.Queue()
        done = object()
        ctx.emit.subscribe(q.put)
        result: dict = {}

        def worker():
            try:
                self.run(ctx, **kw)
            except BaseException as e:  # noqa: BLE001
                result["error"] = e
            finally:
                q.put(done)

        t = threading.Thread(target=worker, daemon=True)
        t.start()
        try:
            while True:
                item = q.get()
                if item is done:
                    break
                yield item
        finally:
            ctx.emit.unsubscribe(q.put)
            if t.is_alive():
                ctx.cancel.cancel()   # UI ปิด/หยุดฟังกลางคัน → สั่งงานเบื้องหลังหยุดด้วย
        t.join()
        if "error" in result:
            raise result["error"]
