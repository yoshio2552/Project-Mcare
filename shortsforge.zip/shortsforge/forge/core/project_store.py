"""เก็บโปรเจกต์ลงดิสก์ + ประวัติแต่ละครั้งที่แก้ (ย้อนกลับได้)

data/projects/<id>/
    project.json          สถานะปัจจุบัน
    history/0001.json     snapshot ก่อนการแก้แต่ละครั้ง (+ label บอกว่าแก้อะไร)
    audio/ video/ music/ cache/ renders/     ไฟล์ที่สร้าง (ตั้งชื่อตาม fingerprint → ย้อนกลับแล้วไม่ต้องสร้างใหม่)
"""
from __future__ import annotations

import json
import os
import shutil
import time
from pathlib import Path

from .models import Project

MAX_HISTORY = 40


def _atomic_write(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


class ProjectStore:
    def __init__(self, data_dir: Path):
        self.root = Path(data_dir) / "projects"
        self.root.mkdir(parents=True, exist_ok=True)

    # ---------- พื้นฐาน ----------
    def dir(self, pid: str) -> Path:
        return self.root / pid

    def asset_dir(self, project: Project, sub: str) -> Path:
        d = self.dir(project.id) / sub
        d.mkdir(parents=True, exist_ok=True)
        return d

    def cache_dir(self, sub: str) -> Path:
        """แคชที่ใช้ร่วมกันทุกโปรเจกต์ (คลิป stock ที่โหลดแล้ว, ผลค้นหา, ช็อตที่เข้ารหัสแล้ว)"""
        d = self.root.parent / "cache" / sub
        d.mkdir(parents=True, exist_ok=True)
        return d

    def create(self, topic: str, language: str = "th") -> Project:
        p = Project.new(topic, language)
        self.dir(p.id).mkdir(parents=True, exist_ok=True)
        self.save(p)
        return p

    def save(self, project: Project) -> None:
        d = self.dir(project.id)
        d.mkdir(parents=True, exist_ok=True)
        _atomic_write(d / "project.json", json.dumps(project.to_dict(), ensure_ascii=False, indent=2))

    def load(self, pid: str) -> Project:
        f = self.dir(pid) / "project.json"
        if not f.exists():
            raise FileNotFoundError(f"ไม่พบโปรเจกต์ {pid}")
        return Project.from_dict(json.loads(f.read_text(encoding="utf-8")))

    def list(self) -> list[dict]:
        out = []
        for d in sorted(self.root.iterdir(), reverse=True):
            f = d / "project.json"
            if f.exists():
                try:
                    j = json.loads(f.read_text(encoding="utf-8"))
                    out.append({"id": j["id"], "title": j.get("title") or j.get("topic") or j["id"],
                                "created": j.get("created", 0)})
                except (json.JSONDecodeError, KeyError):
                    continue
        return out

    def delete(self, pid: str) -> None:
        shutil.rmtree(self.dir(pid), ignore_errors=True)

    # ---------- ประวัติ / undo ----------
    def _hist_dir(self, pid: str) -> Path:
        d = self.dir(pid) / "history"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def snapshot(self, project: Project, label: str) -> int:
        """เก็บสถานะปัจจุบันไว้ก่อนแก้ — คืนเลขลำดับ"""
        h = self._hist_dir(project.id)
        nums = sorted(int(p.stem) for p in h.glob("*.json"))
        n = (nums[-1] + 1) if nums else 1
        payload = {"label": label, "ts": time.time(), "project": project.to_dict()}
        _atomic_write(h / f"{n:04d}.json", json.dumps(payload, ensure_ascii=False))
        for old in nums[: max(0, len(nums) + 1 - MAX_HISTORY)]:
            (h / f"{old:04d}.json").unlink(missing_ok=True)
        return n

    def history(self, pid: str) -> list[dict]:
        out = []
        for f in sorted(self._hist_dir(pid).glob("*.json"), reverse=True):
            try:
                j = json.loads(f.read_text(encoding="utf-8"))
                out.append({"n": int(f.stem), "label": j.get("label", ""), "ts": j.get("ts", 0)})
            except (json.JSONDecodeError, ValueError):
                continue
        return out

    def restore(self, pid: str, n: int | None = None) -> Project:
        """ย้อนกลับไป snapshot n (ไม่ระบุ = ล่าสุด) แล้วลบ snapshot นั้นออกจากสแตก"""
        h = self._hist_dir(pid)
        if n is None:
            nums = sorted(int(p.stem) for p in h.glob("*.json"))
            if not nums:
                raise FileNotFoundError("ยังไม่มีประวัติให้ย้อนกลับ")
            n = nums[-1]
        f = h / f"{n:04d}.json"
        j = json.loads(f.read_text(encoding="utf-8"))
        p = Project.from_dict(j["project"])
        p.revision += 1
        for later in h.glob("*.json"):
            if int(later.stem) >= n:
                later.unlink(missing_ok=True)
        self.save(p)
        return p
