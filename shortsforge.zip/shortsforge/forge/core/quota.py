"""โควตา API ฟรี: นับจำนวนคำขอต่อวัน + จำว่าโมเดลไหนโควตาหมดแล้ววันนี้ (จะได้ไม่ยิงซ้ำให้เสียเวลา)

Gemini นับวันตามเวลาแปซิฟิก (รีเซ็ตเที่ยงคืน PT) — คำนวณเองโดยไม่พึ่ง tzdata (Windows ไม่มีมาให้)
"""
from __future__ import annotations

import json
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path

DATA_DIR: Path | None = None          # Studio ตั้งให้ตอนเริ่ม
_LOCK = threading.Lock()
_EXHAUSTED: dict[str, str] = {}       # "gemini:model" -> วันที่ (PT) ที่โควตาหมด


def _us_dst(dt_utc: datetime) -> bool:
    """เวลาออมแสงของสหรัฐฯ: อาทิตย์ที่ 2 ของมี.ค. 02:00 ถึงอาทิตย์แรกของพ.ย. 02:00 (เวลาท้องถิ่น)"""
    y = dt_utc.year

    def nth_sunday(month: int, n: int) -> datetime:
        d = datetime(y, month, 1, tzinfo=timezone.utc)
        d += timedelta(days=(6 - d.weekday()) % 7)
        return d + timedelta(weeks=n - 1)
    start = nth_sunday(3, 2) + timedelta(hours=10)      # 02:00 PST = 10:00 UTC
    end = nth_sunday(11, 1) + timedelta(hours=9)        # 02:00 PDT = 09:00 UTC
    return start <= dt_utc < end


def pacific_now(now_utc: datetime | None = None) -> datetime:
    now_utc = now_utc or datetime.now(timezone.utc)
    off = -7 if _us_dst(now_utc) else -8
    return now_utc.astimezone(timezone(timedelta(hours=off)))


def pacific_date(now_utc: datetime | None = None) -> str:
    return pacific_now(now_utc).strftime("%Y-%m-%d")


def reset_local_text(now_utc: datetime | None = None) -> str:
    """เวลาที่โควตาจะรีเซ็ต เป็นเวลาของเครื่องผู้ใช้ เช่น 'วันนี้ 15:00'"""
    pt = pacific_now(now_utc)
    nxt = (pt + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
    local = nxt.astimezone()
    today = datetime.now().astimezone().date()
    day = "วันนี้" if local.date() == today else "พรุ่งนี้"
    return f"{day} {local:%H:%M} น."


def _file() -> Path | None:
    return DATA_DIR / "usage.json" if DATA_DIR else None


def record(key: str) -> None:
    f = _file()
    if not f:
        return
    with _LOCK:
        try:
            data = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
        except ValueError:
            data = {}
        d = pacific_date()
        data = {k: v for k, v in data.items() if k >= (pacific_now() - timedelta(days=7)).strftime("%Y-%m-%d")}
        day = data.setdefault(d, {})
        day[key] = day.get(key, 0) + 1
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")


def today() -> dict[str, int]:
    f = _file()
    if not f or not f.exists():
        return {}
    try:
        return json.loads(f.read_text(encoding="utf-8")).get(pacific_date(), {})
    except ValueError:
        return {}


def mark_exhausted(key: str) -> None:
    _EXHAUSTED[key] = pacific_date()


def is_exhausted(key: str) -> bool:
    return _EXHAUSTED.get(key) == pacific_date()


def summary() -> str:
    t = today()
    if not t:
        return "วันนี้ยังไม่ได้เรียก API ที่มีโควตา"
    return "ใช้วันนี้ (รีเซ็ต " + reset_local_text() + "): " + ", ".join(f"{k} {v} ครั้ง" for k, v in sorted(t.items()))


def compact() -> str:
    """ข้อความสั้นสำหรับแถบสถานะ เช่น 'Gemini วันนี้: gemini-3.6-flash 3 · gemini-3.5-flash-lite 8'"""
    t = {k.split(":", 1)[1]: v for k, v in today().items() if k.startswith("gemini:")}
    return ("Gemini วันนี้: " + " · ".join(f"{m} {n}" for m, n in sorted(t.items()))) if t else ""
