"""ทะเบียนผู้ให้บริการ (provider) — หัวใจของการเป็น LEGO

เพิ่ม provider ใหม่ = สร้างไฟล์ใหม่ใน forge/providers/<ชนิด>/ แล้วติด @register(...)
ไม่ต้องแก้ไฟล์อื่นเลย (ระบบสแกนโฟลเดอร์ให้เอง)
"""
from __future__ import annotations

import importlib
import pkgutil
from dataclasses import dataclass

_REG: dict[str, dict[str, "Entry"]] = {}
_DISCOVERED = False


@dataclass
class Entry:
    kind: str
    name: str
    label: str
    cls: type
    needs_keys: tuple[str, ...]


def register(kind: str, name: str, *, label: str | None = None, needs_keys: tuple[str, ...] = ()):
    def deco(cls):
        _REG.setdefault(kind, {})[name] = Entry(kind, name, label or name, cls, needs_keys)
        cls.kind, cls.name = kind, name
        return cls
    return deco


def discover() -> None:
    """import ทุกโมดูลใต้ forge.providers เพื่อให้ decorator ทำงาน"""
    global _DISCOVERED
    if _DISCOVERED:
        return
    import forge.providers as pkg
    for m in pkgutil.walk_packages(pkg.__path__, pkg.__name__ + "."):
        try:
            importlib.import_module(m.name)
        except Exception as e:  # provider ตัวหนึ่ง import พังต้องไม่ล้มทั้งระบบ
            print(f"[registry] ข้าม {m.name}: {type(e).__name__}: {e}")
    _DISCOVERED = True


def entries(kind: str) -> list[Entry]:
    discover()
    return list(_REG.get(kind, {}).values())


def choices(kind: str) -> list[tuple[str, str]]:
    """[(label, name)] สำหรับ dropdown ใน UI"""
    return [(e.label, e.name) for e in entries(kind)]


def create(kind: str, name: str, cfg):
    discover()
    try:
        entry = _REG[kind][name]
    except KeyError:
        known = ", ".join(_REG.get(kind, {})) or "-"
        raise KeyError(f"ไม่มี provider '{name}' ในกลุ่ม {kind} (มี: {known})")
    return entry.cls(cfg)
