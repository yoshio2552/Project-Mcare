"""ระบบตั้งค่า — ประกาศค่าไว้ที่เดียว (SCHEMA) แล้วหน้า Settings ใน UI สร้างตัวเองจากตารางนี้

เพิ่มการตั้งค่าใหม่ = เพิ่ม Field 1 บรรทัด ไม่ต้องแตะโค้ด UI
API key เก็บแยกใน data/secrets.json (สิทธิ์ 600) หรืออ่านจาก environment/.env
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from . import http


@dataclass
class Field:
    key: str
    label: str
    kind: str                       # text|int|float|bool|choice|choice_custom|multi|secret|color
    default: Any
    group: str
    help: str = ""
    choices: list | None = None     # [(label, value)] หรือ [value]
    min: float | None = None
    max: float | None = None
    step: float | None = None
    # ถ้า choices มาจาก registry ให้ใส่ชนิดไว้ที่นี่ (UI จะดึงรายชื่อ provider ล่าสุดเอง)
    registry: str | None = None


GROUPS = [
    ("project", "โปรเจกต์ & ความยาว"),
    ("llm", "สมอง AI (เขียนบท/สั่งแก้)"),
    ("tts", "เสียงพากย์"),
    ("stock", "แหล่งภาพ/คลิป"),
    ("music", "เพลง & การมิกซ์เสียง"),
    ("graphics", "ภาพอธิบาย (motion graphics)"),
    ("aiimage", "ภาพ AI"),
    ("captions", "ซับไตเติล"),
    ("render", "เรนเดอร์"),
    ("keys", "API Keys"),
]

SCHEMA: list[Field] = [
    # ---- โปรเจกต์ ----
    Field("language", "ภาษาของคลิป", "choice", "th", "project", choices=[("ไทย", "th"), ("English", "en")]),
    Field("target_seconds", "ความยาวคลิปเป้าหมาย (วินาที)", "int", 35, "project", min=10, max=180, step=1,
          help="ระบบจะคำนวณจำนวนตัวอักษรของบทพากย์ให้พอดีเป้า แล้ววัดจากเสียงจริงและปรับให้อีกรอบ"),
    Field("scene_count", "จำนวนฉาก", "int", 4, "project", min=2, max=12, step=1,
          help="1 ฉาก = 1 ประโยคพากย์ ฉากยาวจะถูกแบ่งเป็นหลายช็อตภาพโดยอัตโนมัติ"),
    Field("workflow.review", "หยุดให้ตรวจทีละสเต็ป", "bool", True, "project",
          help="เปิด = กดหนึ่งครั้งทำหนึ่งสเต็ป แล้วหยุดให้ดู/แก้ก่อน (บท → เสียง → ภาพ → เพลง → เรนเดอร์) · ปิด = ทำรวดเดียวจนจบ"),
    Field("max_shot_seconds", "ภาพเปลี่ยนทุกไม่เกิน (วินาที)", "float", 3.5, "project", min=1.5, max=8, step=0.5,
          help="ภาพจะตัดตามจังหวะคำพูดอยู่แล้ว ค่านี้ใช้แบ่งช่วงพูดที่ยาวเกินออกเป็นหลายช็อต — 2.5–4 วินาทีกำลังดี"),
    Field("scene_pause", "เว้นจังหวะหลังจบฉาก (วินาที)", "float", 0.25, "project", min=0, max=1.5, step=0.05),
    Field("auto_fit", "ปรับบทให้ยาวพอดีเป้าอัตโนมัติ", "bool", True, "project",
          help="หลังพากย์เสียงครั้งแรก ถ้าความยาวจริงเพี้ยนจากเป้าเกิน ~10% AI จะย่อ/ขยายบทให้ 1 รอบ (ไม่แตะบทที่คุณแก้เอง)"),
    Field("fps", "เฟรมเรต (fps)", "choice", 30, "project", choices=[24, 25, 30, 60]),
    Field("resolution", "ขนาดวิดีโอ", "choice", "1080x1920", "project",
          choices=[("แนวตั้ง 1080×1920 (Shorts/TikTok/Reels)", "1080x1920"), ("แนวตั้ง 720×1280 (เร็วกว่า)", "720x1280")]),

    # ---- LLM ----
    Field("llm.provider", "ตัวเขียนบท", "choice", "gemini", "llm", registry="llm"),
    Field("gemini.model", "Gemini model (เขียนบท/สั่งแก้)", "choice_custom", "gemini-3.6-flash", "llm",
          choices=["gemini-3.8-flash", "gemini-3.6-flash", "gemini-3-flash-preview", "gemini-3.5-flash-lite"],
          help="key ฟรี: รุ่น Flash ได้ราว 20 คำขอ/วัน (พอเขียนบท+สั่งแก้ ~5 คลิป/วัน) · พิมพ์ชื่อรุ่นอื่นเองได้"),
    Field("gemini.model_light", "Gemini model สำหรับงานจำนวนเยอะ (AI ตรวจภาพ)", "choice_custom", "gemini-3.5-flash-lite", "llm",
          choices=["gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-3.6-flash"],
          help="รุ่น Lite โควตาฟรีเยอะกว่ามาก (รายงานราว 500 คำขอ/วัน) และดูรูปได้ — ว่าง = ใช้รุ่นเดียวกับด้านบน"),
    Field("ollama.host", "Ollama host", "text", "http://localhost:11434", "llm"),
    Field("ollama.model", "Ollama model", "text", "qwen3:14b", "llm",
          help="ภาษาไทยแนะนำ qwen3:14b ขึ้นไป (8b เขียนบทได้ แต่ไทยจะแข็งกว่า) — ต้อง ollama pull ก่อน"),
    Field("ollama.vision_model", "Ollama model ที่ดูภาพได้ (ไม่บังคับ)", "text", "", "llm",
          help="เช่น qwen2.5vl:7b หรือ qwen3-vl:8b — ใส่แล้ว AI จะดูภาพตัวอย่างคลิปก่อนเลือก (ว่าง = ตัดสินจากชื่อ/แท็กของคลิป)"),
    Field("ollama.think", "ให้ Qwen คิดก่อนตอบ (ช้าลงมาก)", "bool", False, "llm"),
    Field("llm.temperature", "ความสร้างสรรค์ (temperature)", "float", 1.0, "llm", min=0, max=2, step=0.1,
          help="Gemini 3 แนะนำให้คงที่ 1.0"),

    # ---- TTS ----
    Field("tts.provider", "ตัวพากย์เสียง", "choice", "elevenlabs", "tts", registry="tts"),
    Field("elevenlabs.model", "ElevenLabs model", "choice_custom", "eleven_v3", "tts",
          choices=["eleven_v3", "eleven_multilingual_v2", "eleven_flash_v2_5"],
          help="ภาษาไทย: ตามเอกสาร ElevenLabs มีเฉพาะ eleven_v3 ที่รองรับ (multilingual_v2 และ flash_v2_5 ไม่มีไทย)"),
    Field("elevenlabs.voice_id", "Voice ID", "text", "", "tts",
          help="กดปุ่ม 'โหลดรายชื่อเสียง' ในแท็บเสียงเพื่อเลือกจากคลังของคุณ — ภาษาไทยให้เลือกเสียงที่ออกไทยชัด"),
    Field("elevenlabs.stability", "Stability", "float", 0.5, "tts", min=0, max=1, step=0.05),
    Field("elevenlabs.similarity", "Similarity boost", "float", 0.75, "tts", min=0, max=1, step=0.05),
    Field("tts.speed", "ความเร็วพูด", "float", 1.0, "tts", min=0.7, max=1.2, step=0.05,
          help="ElevenLabs รองรับ 0.7–1.2"),
    Field("edge.voice", "Edge TTS voice (สำรองฟรี)", "text", "th-TH-NiwatNeural", "tts"),

    # ---- Stock ----
    Field("stock.providers", "แหล่งภาพ (เรียงตามลำดับความสำคัญ)", "multi", ["pexels", "pixabay", "local"], "stock",
          registry="stock",
          help="ค้นทุกแหล่งที่เปิด แล้วจัดอันดับรวมกัน คลิปแนวตั้งและความยาวพอจะได้คะแนนสูงกว่า"),
    Field("stock.min_width", "ความคมชัดขั้นต่ำ (px กว้างหลังครอปเป็นแนวตั้ง)", "int", 540, "stock", min=360, max=1080, step=10,
          help="คลิปแนวนอน 1080p ครอปแล้วเหลือกว้างราว 608px; 720p เหลือ 405px (จะถูกตัดออก) — ตัวเลขนี้คือเกณฑ์ตัดคลิปไม่คม"),
    Field("stock.candidates", "จำนวนคลิปทางเลือกต่อช็อต", "int", 8, "stock", min=3, max=20, step=1),
    Field("stock.judge", "ให้ AI ตรวจว่าคลิปตรงบทไหม", "choice", "auto", "stock",
          choices=[("อัตโนมัติ (ดูภาพถ้าโมเดลดูได้)", "auto"), ("ดูภาพตัวอย่าง", "vision"),
                   ("อ่านชื่อ/แท็กคลิปเท่านั้น", "text"), ("ปิด (เร็วสุด แต่ตรงน้อยกว่า)", "off")],
          help="AI อ่านประโยคที่กำลังพูด แล้วให้คะแนนคลิปตัวเลือกแต่ละตัว 0–10 — เลือกตัวที่ตรงที่สุด"),
    Field("stock.judge_top", "จำนวนคลิปที่ให้ AI ตรวจต่อช็อต", "int", 6, "stock", min=3, max=12, step=1,
          help="มากขึ้น = มีโอกาสเจอคลิปที่ตรงกว่า แต่ช้าขึ้นและใช้โควตา AI มากขึ้น"),
    Field("stock.local_dir", "โฟลเดอร์คลังคลิปในเครื่อง", "text", "assets/stock", "stock",
          help="ใส่คลิปที่โหลดเอง (เช่นจาก Mixkit) ไว้ที่นี่ ตั้งชื่อไฟล์/โฟลเดอร์เป็นคำอังกฤษ"),

    # ---- Graphics ----
    Field("graphics.enabled", "ใช้ภาพอธิบายในช่วงที่เหมาะ", "bool", True, "graphics",
          help="AI เลือกเองว่าช่วงไหนควรเป็นตัวเลขใหญ่/ความเชื่อ vs ความจริง/ขั้นตอน/กราฟ/คำถาม แทนวิดีโอสต็อก — "
               "สร้างใหม่ทุกคลิป ไม่ซ้ำใคร ไม่มีปัญหาลิขสิทธิ์ ไม่ต้องใช้ API"),
    Field("graphics.share", "สัดส่วนภาพอธิบายในคลิป", "choice", "balanced", "graphics",
          choices=[("น้อย (~20%)", "few"), ("สมดุล (~40%)", "balanced"), ("เยอะ (~60%)", "many")]),
    Field("graphics.palette", "ชุดสีของภาพอธิบาย", "choice", "auto", "graphics",
          choices=[("อัตโนมัติ (สลับตามโปรเจกต์)", "auto"), ("กลางคืน น้ำเงินเข้ม + เหลือง", "midnight"),
                   ("มหาสมุทร ฟ้าอมเขียว", "ocean"), ("พระอาทิตย์ตก ม่วงชมพู", "sunset"),
                   ("ป่า เขียวเข้ม", "forest"), ("กระดาษ สว่าง อ่านง่าย", "paper")],
          help="ตั้งเป็นสีเดียวตลอดถ้าอยากให้ช่องมีเอกลักษณ์ / อัตโนมัติถ้าอยากให้แต่ละคลิปไม่เหมือนกัน"),
    Field("graphics.font", "ฟอนต์ของภาพอธิบาย", "text", "", "graphics",
          help="ว่าง = ใช้ฟอนต์เดียวกับซับ · ต้องเป็นฟอนต์ที่มีภาษาไทย (วางไฟล์ไว้ใน assets/fonts ได้)"),

    # ---- AI images ----
    Field("image.provider", "ตัวสร้างภาพ AI", "choice", "none", "aiimage", registry="image",
          help="Cloudflare = ฟรีวันละ ~150 ภาพ (สมัครบัญชีฟรี) · Gemini = ต้องเปิด billing · ไม่ใช้ = ไม่มีภาพ AI ในคลิป"),
    Field("image.share", "สัดส่วนภาพ AI ในคลิป", "choice", "few", "aiimage",
          choices=[("น้อย (~15%)", "few"), ("สมดุล (~30%)", "balanced"), ("เยอะ (~50%)", "many")],
          help="ภาพ AI ใช้กับประโยคเชิงนามธรรม/อุปมา/สิ่งที่สต็อกถ่ายไม่ได้ — AI ผู้วางแผนภาพเลือกเองว่าช่วงไหน"),
    Field("image.style", "สไตล์ภาพประจำช่อง", "choice", "flat", "aiimage",
          choices=[("ภาพประกอบแบน สีพาสเทล", "flat"), ("3D ดินปั้นน่ารัก", "clay"), ("สีน้ำ อบอุ่น", "watercolor"),
                   ("การ์ตูนคอมิก เส้นหนา", "comic"), ("ภาพถ่ายภาพยนตร์ (สมจริง — ต้องติดป้าย AI)", "cinematic"),
                   ("กำหนดเอง (ช่องด้านล่าง)", "custom")],
          help="ล็อกสไตล์เดียวทุกคลิป → คนจำช่องได้ · แบบที่ไม่สมจริงไม่ต้องติดป้าย AI ตามกฎ TikTok/YouTube (แบบสมจริงต้องติด)"),
    Field("image.style_custom", "สไตล์กำหนดเอง (อังกฤษ)", "text", "", "aiimage",
          help="เช่น 'minimal line art, navy and gold, lots of negative space, no text'"),
    Field("image.motion", "การเคลื่อนไหวของภาพ", "choice", "auto", "aiimage",
          choices=[("สลับอัตโนมัติ", "auto"), ("ซูมเข้า", "zoom_in"), ("ซูมออก", "zoom_out"),
                   ("แพนซ้าย", "pan_left"), ("แพนขวา", "pan_right")]),
    Field("image.fit", "การวางภาพ", "choice", "auto", "aiimage",
          choices=[("อัตโนมัติตามสัดส่วนภาพ", "auto"), ("เต็มจอ (ตัดขอบ)", "cover"), ("เต็มใบ + พื้นหลังเบลอ", "frame")]),
    Field("cloudflare.account_id", "Cloudflare Account ID", "text", "", "aiimage",
          help="dash.cloudflare.com → เมนู Workers AI → ปุ่ม 'Use REST API' จะเห็น Account ID และสร้าง API Token ได้"),
    Field("cloudflare.image_model", "Cloudflare image model", "choice_custom", "@cf/black-forest-labs/flux-1-schnell", "aiimage",
          choices=["@cf/black-forest-labs/flux-1-schnell", "@cf/black-forest-labs/flux-2-klein-4b"],
          help="flux-1-schnell ประหยัดโควตาที่สุด"),
    Field("cloudflare.steps", "ความละเอียดการสร้างภาพ (steps)", "int", 6, "aiimage", min=2, max=8, step=1,
          help="มาก = สวยขึ้นแต่กินโควตาฟรีมากขึ้น (4 steps ≈ 230 ภาพ/วัน, 8 steps ≈ 120 ภาพ/วัน)"),
    Field("gemini.image_model", "Gemini image model (ต้องเปิด billing)", "choice_custom", "gemini-3.1-flash-image", "aiimage",
          choices=["gemini-3.1-flash-image", "gemini-3-pro-image"]),

    # ---- Music ----
    Field("music.provider", "แหล่งเพลง", "choice", "elevenlabs", "music", registry="music"),
    Field("music.local_dir", "โฟลเดอร์คลังเพลงในเครื่อง", "text", "assets/music", "music"),
    Field("music.volume_db", "ระดับเสียงเพลงพื้นหลัง (dB)", "float", -17.0, "music", min=-40, max=-5, step=1,
          help="เทียบกับเสียงพากย์ — ปกติ -20 ถึง -14"),
    Field("music.duck_db", "ลดเพลงลงเมื่อมีเสียงพูด (dB)", "float", 9.0, "music", min=0, max=24, step=1,
          help="ระบบ ducking: เพลงลดอัตโนมัติตอนพูด แล้วค่อยๆ กลับมาตอนเงียบ"),
    Field("music.fade_in", "เพลงค่อยๆ ดังขึ้น (วินาที)", "float", 0.8, "music", min=0, max=5, step=0.1),
    Field("music.fade_out", "เพลงค่อยๆ เบาลงตอนจบ (วินาที)", "float", 1.8, "music", min=0, max=6, step=0.1),
    Field("music.lead_in", "ให้เพลงขึ้นก่อนเสียงพูด (วินาที)", "float", 0.35, "music", min=0, max=3, step=0.05),
    Field("music.tail", "เก็บท้ายคลิปหลังพูดจบ (วินาที)", "float", 0.9, "music", min=0, max=4, step=0.1),
    Field("render.target_lufs", "ความดังรวมเป้าหมาย (LUFS)", "float", -14.0, "music", min=-24, max=-9, step=0.5,
          help="-14 คือมาตรฐานที่ YouTube/TikTok ใช้ ไม่ต้องกลัวเสียงดังเบาไม่เท่าคลิปอื่น"),

    # ---- Captions ----
    Field("captions.enabled", "ใส่ซับไตเติล", "bool", True, "captions"),
    Field("captions.font", "ฟอนต์", "text", "Tahoma", "captions",
          help="ต้องมีฟอนต์ไทยในเครื่อง (Tahoma/Leelawadee UI บน Windows) หรือวางไฟล์ .ttf ไว้ใน assets/fonts แล้วใส่ชื่อฟอนต์"),
    Field("captions.size", "ขนาดตัวอักษร", "int", 74, "captions", min=30, max=140, step=2),
    Field("captions.color", "สีตัวอักษร", "color", "#FFFFFF", "captions"),
    Field("captions.highlight", "สีคำที่กำลังพูด", "color", "#FFE14A", "captions"),
    Field("captions.outline", "ความหนาขอบ", "int", 5, "captions", min=0, max=12, step=1),
    Field("captions.margin_v", "ระยะจากขอบล่าง (px)", "int", 420, "captions", min=50, max=900, step=10,
          help="เลี่ยงโซนปุ่มของแอป — Shorts/TikTok ประมาณ 350–500"),
    Field("captions.chunk_chars", "ตัวอักษรสูงสุดต่อบรรทัดซับ", "int", 18, "captions", min=8, max=40, step=1),
    Field("captions.karaoke", "ไฮไลต์คำตามเสียงพูด", "bool", True, "captions"),
    Field("captions.pop", "เอฟเฟกต์เด้งตอนซับขึ้น", "bool", True, "captions"),

    # ---- Render ----
    Field("render.crf", "คุณภาพ (CRF ยิ่งน้อยยิ่งชัด)", "int", 20, "render", min=14, max=30, step=1),
    Field("render.preset", "ความเร็วเข้ารหัส", "choice", "veryfast", "render",
          choices=["ultrafast", "superfast", "veryfast", "faster", "fast", "medium", "slow"]),

    # ---- Keys ----
    Field("key.elevenlabs", "ElevenLabs API key", "secret", "", "keys"),
    Field("key.gemini", "Gemini API key", "secret", "", "keys",
          help="key ฟรี: Google อาจนำข้อความที่ส่งไปใช้ปรับปรุงบริการและให้คนตรวจอ่านได้ — อย่าใส่ข้อมูลส่วนตัว/ความลับในหัวข้อหรือคำสั่ง"),
    Field("key.cloudflare", "Cloudflare API token (Workers AI)", "secret", "", "keys"),
    Field("key.pexels", "Pexels API key", "secret", "", "keys"),
    Field("key.pixabay", "Pixabay API key", "secret", "", "keys"),
]

_BY_KEY = {f.key: f for f in SCHEMA}
_ENV_NAMES = {
    "key.elevenlabs": "ELEVENLABS_API_KEY",
    "key.gemini": "GEMINI_API_KEY",
    "key.cloudflare": "CLOUDFLARE_API_TOKEN",
    "key.pexels": "PEXELS_API_KEY",
    "key.pixabay": "PIXABAY_API_KEY",
}


def field_of(key: str) -> Field:
    return _BY_KEY[key]


def load_dotenv(path: Path) -> None:
    """อ่านไฟล์ .env แบบง่าย (ไม่ต้องพึ่งแพ็กเกจเพิ่ม) — ค่าที่ตั้งใน environment จริงมีสิทธิ์เหนือกว่า"""
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip("'\""))


class Cfg:
    """ค่าตั้งค่าที่ "มีผลจริง" ของโปรเจกต์หนึ่ง = ค่าทั่วไป + ค่าเฉพาะโปรเจกต์ (overrides)"""

    def __init__(self, values: dict[str, Any]):
        self._v = values

    def __getitem__(self, key: str) -> Any:
        return self._v[key]

    def get(self, key: str, default: Any = None) -> Any:
        return self._v.get(key, default)

    def secret(self, name: str) -> str:
        return str(self._v.get(f"key.{name}", "") or "")

    def require_secret(self, name: str, hint: str) -> str:
        from .errors import ConfigError
        v = self.secret(name)
        if not v:
            raise ConfigError(f"ยังไม่ได้ใส่ {hint} — ไปที่แท็บ 'ตั้งค่า' → API Keys (หรือใส่ในไฟล์ .env)")
        return v

    def as_dict(self) -> dict[str, Any]:
        return dict(self._v)


class Settings:
    def __init__(self, data_dir: Path):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.file = self.data_dir / "settings.json"
        self.secret_file = self.data_dir / "secrets.json"
        self.values: dict[str, Any] = {}
        self.reload()

    # ---------- โหลด/บันทึก ----------
    def reload(self) -> None:
        vals = {f.key: f.default for f in SCHEMA if f.kind != "secret"}
        for path in (self.file,):
            if path.exists():
                try:
                    saved = json.loads(path.read_text(encoding="utf-8"))
                    vals.update({k: v for k, v in saved.items() if k in _BY_KEY})
                except (json.JSONDecodeError, OSError):
                    pass
        secrets: dict[str, str] = {}
        if self.secret_file.exists():
            try:
                secrets = json.loads(self.secret_file.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                secrets = {}
        for f in SCHEMA:
            if f.kind == "secret":
                vals[f.key] = os.environ.get(_ENV_NAMES[f.key]) or secrets.get(f.key, "")
        self.values = vals
        http.set_redactions(v for k, v in vals.items() if k.startswith("key.") and v)

    def save(self) -> None:
        plain = {k: v for k, v in self.values.items() if not k.startswith("key.")}
        self.file.write_text(json.dumps(plain, ensure_ascii=False, indent=2), encoding="utf-8")
        secrets = {k: v for k, v in self.values.items()
                   if k.startswith("key.") and v and not os.environ.get(_ENV_NAMES[k]) == v}
        self.secret_file.write_text(json.dumps(secrets, indent=2), encoding="utf-8")
        try:
            os.chmod(self.secret_file, 0o600)
        except OSError:
            pass
        http.set_redactions(v for k, v in self.values.items() if k.startswith("key.") and v)

    def update(self, changes: dict[str, Any], *, save: bool = True) -> None:
        for k, v in changes.items():
            if k not in _BY_KEY:
                continue
            f = _BY_KEY[k]
            if f.kind == "secret" and (v is None or v == ""):
                continue  # ช่องว่าง = ไม่เปลี่ยน (UI ไม่โชว์ค่า key เดิม)
            self.values[k] = coerce(f, v)
        if save:
            self.save()

    # ---------- ค่าที่มีผลจริง ----------
    def effective(self, overrides: dict | None = None) -> Cfg:
        vals = dict(self.values)
        for k, v in (overrides or {}).items():
            if k in _BY_KEY and not k.startswith("key."):
                vals[k] = v
        return Cfg(vals)


def coerce(f: Field, v: Any) -> Any:
    """แปลงค่าจากช่องกรอก UI ให้ตรงชนิด และจำกัดช่วงให้ปลอดภัย"""
    try:
        if f.kind == "int":
            v = int(round(float(v)))
        elif f.kind == "float":
            v = float(v)
        elif f.kind == "bool":
            v = bool(v)
        elif f.kind == "multi":
            v = list(v or [])
        elif f.kind in ("choice",) and isinstance(f.default, int) and not isinstance(f.default, bool):
            v = int(v)
        else:
            v = v if v is not None else f.default
    except (TypeError, ValueError):
        return f.default
    if f.kind in ("int", "float"):
        if f.min is not None:
            v = max(f.min, v)
        if f.max is not None:
            v = min(f.max, v)
    return v
