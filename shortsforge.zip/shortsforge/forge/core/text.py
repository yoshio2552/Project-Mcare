"""ตัวช่วยข้อความ: แบ่งคำ, จับเวลาคำจากเสียง (ใช้ทำซับตามจังหวะพูด)"""
from __future__ import annotations

import re
from typing import Sequence

from .models import Word

_TH_RANGE = re.compile(r"[฀-๿]")
_pythainlp = None
_tried = False


def has_thai(text: str) -> bool:
    return bool(_TH_RANGE.search(text))


def _thai_tokenizer():
    """ใช้ pythainlp ถ้าติดตั้งไว้ (ตัดคำไทยแม่นขึ้น) ไม่มีก็ข้ามไปใช้การตัดตามช่องว่าง"""
    global _pythainlp, _tried
    if not _tried:
        _tried = True
        try:
            from pythainlp.tokenize import word_tokenize  # type: ignore
            _pythainlp = word_tokenize
        except Exception:
            _pythainlp = None
    return _pythainlp


def tokenize(text: str) -> list[tuple[str, int, int]]:
    """คืน [(token, start_idx, end_idx)] ตามตำแหน่งในข้อความเดิม (ไม่รวมช่องว่าง)"""
    out: list[tuple[str, int, int]] = []
    tok = _thai_tokenizer() if has_thai(text) else None
    for m in re.finditer(r"\S+", text):
        chunk, base = m.group(), m.start()
        if tok and has_thai(chunk) and len(chunk) > 6:
            pos = 0
            for piece in tok(chunk, engine="newmm", keep_whitespace=False):
                i = chunk.find(piece, pos)
                if i < 0:
                    continue
                out.append((piece, base + i, base + i + len(piece)))
                pos = i + len(piece)
        else:
            out.append((chunk, base, m.end()))
    return out


def estimate_words(text: str, duration: float, lead: float = 0.06, tail: float = 0.12) -> list[Word]:
    """ไม่มีข้อมูลเวลาจริงจาก TTS → กระจายเวลาตามความยาวตัวอักษรของแต่ละคำ"""
    toks = tokenize(text)
    if not toks:
        return []
    span = max(0.2, duration - lead - tail)
    weights = [max(1, len(t)) + 1.5 for t, _, _ in toks]   # +1.5 = จังหวะหายใจต่อคำ
    total = sum(weights)
    t, words = lead, []
    for (tok, _, _), w in zip(toks, weights):
        d = span * w / total
        words.append(Word(tok, round(t, 3), round(t + d, 3)))
        t += d
    return words


def words_from_char_alignment(text: str, chars: Sequence[str], starts: Sequence[float],
                              ends: Sequence[float]) -> list[Word]:
    """แปลงเวลาระดับ "ตัวอักษร" (ElevenLabs) เป็นเวลาระดับ "คำ/วลี" ตามข้อความเดิมที่เราส่งไป"""
    n = min(len(chars), len(starts), len(ends))
    if n == 0 or not text.strip():
        return []
    joined = "".join(chars[:n])
    scale = 1.0 if len(joined) == len(text) else n / max(1, len(text))
    words: list[Word] = []
    for tok, a, b in tokenize(text):
        ia = min(n - 1, int(round(a * scale)))
        ib = min(n - 1, max(ia, int(round((b - 1) * scale))))
        s, e = float(starts[ia]), float(ends[ib])
        if e < s:
            e = s
        words.append(Word(tok, round(s, 3), round(e, 3)))
    # กันเวลาซ้อนกัน/ย้อนกลับ
    for i in range(1, len(words)):
        if words[i].start < words[i - 1].end:
            words[i].start = words[i - 1].end
        if words[i].end < words[i].start:
            words[i].end = words[i].start
    return words
