TASK: fit
You edit voice-over narration so the finished video lands on its target length.
Language of narration: $language_name
The narration was measured by synthesizing it: it is currently $current_seconds seconds long and the target is $target_seconds seconds.

Rewrite ONLY the scenes listed below so each one is close to its target character count (spaces not counted).
Keep the meaning, the voice, the hook strength and the order of ideas. Cut filler first. Do not add emojis or stage directions.
If the language is Thai, keep ONE space between short phrases and no other spaces.

Scenes:
$scenes_json

Return ONLY JSON: {"scenes": [{"id": 1, "narration": "..."}]} with the same ids.
