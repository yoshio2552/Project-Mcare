"""สัญญา (interface) ของ provider ทุกชนิด — แกนกลางคุยกับ provider ผ่านสิ่งนี้เท่านั้น"""
from __future__ import annotations

import json
import re
from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from ..core.errors import ProviderError
from ..core.models import Word
from ..core.settings import Cfg


class Provider:
    kind = ""
    name = ""

    def __init__(self, cfg: Cfg):
        self.cfg = cfg


# ============================== LLM ==============================
def extract_json(text: str) -> Any:
    """ดึง JSON ออกจากคำตอบ LLM แม้จะมี ```json ... ``` หรือข้อความนำหน้า/ต่อท้าย"""
    t = re.sub(r"<think>.*?</think>", "", text or "", flags=re.S).strip()
    t = re.sub(r"^```(?:json)?\s*|\s*```$", "", t, flags=re.S).strip()
    try:
        return json.loads(t)
    except json.JSONDecodeError:
        pass
    # หา JSON ก้อนแรกที่วงเล็บสมดุล
    for opener, closer in (("{", "}"), ("[", "]")):
        start = t.find(opener)
        while start != -1:
            depth, in_str, esc = 0, False, False
            for i in range(start, len(t)):
                ch = t[i]
                if in_str:
                    if esc:
                        esc = False
                    elif ch == "\\":
                        esc = True
                    elif ch == '"':
                        in_str = False
                    continue
                if ch == '"':
                    in_str = True
                elif ch == opener:
                    depth += 1
                elif ch == closer:
                    depth -= 1
                    if depth == 0:
                        try:
                            return json.loads(t[start:i + 1])
                        except json.JSONDecodeError:
                            break
            start = t.find(opener, start + 1)
    raise ProviderError("AI ตอบกลับมาไม่ใช่ JSON ที่อ่านได้: " + (text or "")[:200].replace("\n", " "))


class LLMProvider(Provider, ABC):
    light: bool = False        # True = ใช้รุ่นเบา/ถูก สำหรับงานจำนวนเยอะ (provider ที่ไม่มีรุ่นเบาไม่ต้องสนใจ)

    @abstractmethod
    def _complete(self, system: str, prompt: str, json_mode: bool, images: list[bytes] | None = None) -> str:
        """เรียกโมเดลหนึ่งครั้ง คืนข้อความดิบ (images = รูป JPEG แนบไปด้วย ถ้าโมเดลดูภาพได้)"""

    @property
    def supports_vision(self) -> bool:
        """โมเดลนี้ "ดูรูป" ได้ไหม — ใช้ให้ AI ดูภาพตัวอย่างคลิปแล้วตัดสินว่าตรงบทหรือไม่"""
        return False

    def generate_text(self, system: str, prompt: str) -> str:
        return self._complete(system, prompt, json_mode=False)

    def generate_json(self, system: str, prompt: str, attempts: int = 3, images: list[bytes] | None = None) -> Any:
        last: Exception | None = None
        for i in range(attempts):
            raw = self._complete(system, prompt if i == 0 else prompt + "\n\nตอบเป็น JSON ที่ถูกต้องเท่านั้น ห้ามมีข้อความอื่น",
                                 True, images)
            try:
                return extract_json(raw)
            except ProviderError as e:
                last = e
        raise last or ProviderError("AI ไม่ตอบ")


# ============================== TTS ==============================
@dataclass
class TTSResult:
    path: Path
    duration: float
    words: list[Word] = field(default_factory=list)   # เวลาเป็นคำ/กลุ่มคำ (ใช้ทำซับตามเสียง)
    meta: dict = field(default_factory=dict)


class TTSProvider(Provider, ABC):
    @abstractmethod
    def synthesize(self, text: str, out_path: Path, *, language: str) -> TTSResult: ...

    def list_voices(self) -> list[tuple[str, str]]:
        """[(ชื่อที่โชว์, voice_id)] — provider ที่ไม่มีคลังเสียงปล่อยว่างได้"""
        return []

    def fingerprint_parts(self) -> list:
        """ค่าที่ทำให้เสียงต่างไป (เปลี่ยนแล้วต้องพากย์ใหม่) — แต่ละ provider ระบุเอง"""
        return [self.name]


# ============================== Stock ==============================
@dataclass
class Clip:
    provider: str
    id: str
    download_url: str
    preview_url: str = ""
    page_url: str = ""
    duration: float = 0.0
    width: int = 0
    height: int = 0
    credit: str = ""
    local_path: str = ""          # เฉพาะ provider แบบ local
    title: str = ""               # คำบรรยาย/แท็กของคลิปจากแหล่ง (ใช้ตัดสินว่าตรงบริบทไหม)

    @property
    def key(self) -> str:
        return f"{self.provider}:{self.id}"

    @property
    def portrait(self) -> bool:
        return self.height > self.width > 0

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Clip":
        names = cls.__dataclass_fields__.keys()
        return cls(**{k: v for k, v in d.items() if k in names})


class StockProvider(Provider, ABC):
    @abstractmethod
    def search(self, query: str, *, per_page: int = 10) -> list[Clip]: ...

    @abstractmethod
    def download(self, clip: Clip, dest: Path) -> Path: ...


# ============================== Music ==============================
@dataclass
class MusicResult:
    path: Path
    duration: float
    meta: dict = field(default_factory=dict)


class MusicProvider(Provider, ABC):
    @abstractmethod
    def compose(self, prompt: str, length_s: float, out_path: Path) -> MusicResult: ...


# ============================== Image (ภาพ AI) ==============================
@dataclass
class ImageResult:
    path: Path
    width: int
    height: int
    meta: dict = field(default_factory=dict)


class ImageProvider(Provider, ABC):
    credit: str = "AI-generated image"      # ใส่ในไฟล์เครดิต (เปิดเผยว่าเป็นภาพ AI)

    @abstractmethod
    def generate(self, prompt: str, out_path: Path, *, seed: int) -> ImageResult:
        """สร้างภาพ 1 ภาพ (พยายามขอแนวตั้ง ถ้าบริการรองรับ) บันทึกเป็น JPEG/PNG ที่ out_path"""

    def fingerprint_parts(self) -> list:
        return [self.name]
