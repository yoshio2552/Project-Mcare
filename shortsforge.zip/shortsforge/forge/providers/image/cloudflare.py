"""Cloudflare Workers AI — สร้างภาพฟรีวันละ 10,000 neurons (FLUX.1 schnell ~60 neurons/ภาพ ที่ 6 steps ≈ 150 ภาพ/วัน)

ต้องมี: บัญชี Cloudflare (ฟรี) → Account ID + API Token ที่มีสิทธิ์ Workers AI
โควตาฟรีรีเซ็ตทุกวันเวลา 00:00 UTC (= 07:00 น. เวลาไทย)
"""
from __future__ import annotations

import base64
from datetime import datetime, timedelta, timezone
from pathlib import Path

from ...core import ffmpeg, http, quota
from ...core.errors import ConfigError, ProviderError, QuotaExceeded
from ...core.registry import register
from ..base import ImageProvider, ImageResult

API = "https://api.cloudflare.com/client/v4/accounts/{account}/ai/run/{model}"


def _reset_text() -> str:
    now = datetime.now(timezone.utc)
    nxt = (now + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
    return f"{nxt.astimezone():%H:%M} น."


@register("image", "cloudflare", label="Cloudflare Workers AI (ฟรี ~150 ภาพ/วัน)", needs_keys=("cloudflare",))
class CloudflareImage(ImageProvider):
    credit = "AI-generated image (FLUX.1 [schnell] via Cloudflare Workers AI)"

    def _model(self) -> str:
        return str(self.cfg.get("cloudflare.image_model") or "@cf/black-forest-labs/flux-1-schnell").strip()

    def fingerprint_parts(self) -> list:
        return [self.name, self._model(), int(self.cfg.get("cloudflare.steps", 6))]

    def generate(self, prompt: str, out_path: Path, *, seed: int) -> ImageResult:
        token = self.cfg.require_secret("cloudflare", "Cloudflare API token")
        account = str(self.cfg.get("cloudflare.account_id", "")).strip()
        if not account:
            raise ConfigError("ยังไม่ได้ใส่ Cloudflare Account ID (แท็บตั้งค่า → ภาพ AI)")
        qkey = f"cloudflare:{self._model()}"
        if quota.is_exhausted(qkey):
            raise ConfigError(f"โควตาฟรีของ Cloudflare วันนี้หมดแล้ว — รีเซ็ต {_reset_text()}")
        body = {"prompt": prompt[:2000], "steps": max(1, min(8, int(self.cfg.get("cloudflare.steps", 6)))),
                "seed": int(seed) % 2_147_483_647}
        try:
            r = http.request("POST", API.format(account=account, model=self._model()),
                             headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                             json=body, timeout=120)
        except QuotaExceeded:
            quota.mark_exhausted(qkey)
            raise ConfigError(f"โควตาฟรีของ Cloudflare วันนี้หมดแล้ว — รีเซ็ต {_reset_text()}") from None
        except ProviderError as e:
            msg = str(e)
            if "HTTP 401" in msg or "HTTP 403" in msg:
                raise ConfigError("Cloudflare ไม่ยอมรับ token/Account ID — ตรวจว่า token มีสิทธิ์ Workers AI") from None
            if "neurons" in msg.lower() or "allocation" in msg.lower():
                quota.mark_exhausted(qkey)
                raise ConfigError(f"โควตาฟรีของ Cloudflare วันนี้หมดแล้ว — รีเซ็ต {_reset_text()}") from None
            raise
        quota.record(qkey)
        if r.headers.get("Content-Type", "").startswith("image/"):
            raw = r.content                                   # บางรุ่นส่งไฟล์ภาพตรงๆ
        else:
            data = r.json()
            res = data.get("result") if isinstance(data.get("result"), dict) else data
            b64 = (res or {}).get("image")
            if not b64:
                raise ProviderError(f"Cloudflare ไม่ส่งภาพกลับมา: {str(data)[:200]}")
            raw = base64.b64decode(b64)
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_bytes(raw)
        info = ffmpeg.probe(out_path)
        return ImageResult(out_path, int(info["width"]), int(info["height"]), {"model": self._model()})
