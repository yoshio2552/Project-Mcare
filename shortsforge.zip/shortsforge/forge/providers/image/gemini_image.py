"""Gemini (Nano Banana) — คุณภาพสูง ขอแนวตั้ง 9:16 ได้ แต่ **ต้องเปิด billing** (key ฟรีไม่มีสิทธิ์สร้างภาพ)"""
from __future__ import annotations

import base64
from pathlib import Path

from ...core import ffmpeg, http, quota
from ...core.errors import ConfigError, ProviderError, QuotaExceeded
from ...core.registry import register
from ..base import ImageProvider, ImageResult

API = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"


@register("image", "gemini_image", label="Gemini Nano Banana (ต้องเปิด billing)", needs_keys=("gemini",))
class GeminiImage(ImageProvider):
    credit = "AI-generated image (Google Gemini)"

    def _model(self) -> str:
        return str(self.cfg.get("gemini.image_model") or "gemini-3.1-flash-image").strip()

    def fingerprint_parts(self) -> list:
        return [self.name, self._model()]

    def generate(self, prompt: str, out_path: Path, *, seed: int) -> ImageResult:
        key = self.cfg.require_secret("gemini", "Gemini API key")
        body = {"contents": [{"role": "user", "parts": [{"text": prompt}]}],
                "generationConfig": {"responseModalities": ["IMAGE"], "seed": int(seed) % 2_147_483_647,
                                     "imageConfig": {"aspectRatio": "9:16"}}}
        try:
            r = http.request("POST", API.format(model=self._model()),
                             headers={"x-goog-api-key": key, "Content-Type": "application/json"}, json=body, timeout=180)
        except QuotaExceeded:
            raise ConfigError("Gemini สร้างภาพไม่ได้: โควตาหมด/key ฟรีไม่มีสิทธิ์สร้างภาพ — เปิด billing หรือใช้ Cloudflare (ฟรี)") from None
        except ProviderError as e:
            if any(x in str(e) for x in ("HTTP 429", "HTTP 403", "billing", "limit: 0")):
                raise ConfigError("Gemini สร้างภาพไม่ได้กับ key ฟรี — เปิด billing ที่ Google AI Studio หรือเปลี่ยนเป็น Cloudflare (ฟรี)") from None
            raise
        quota.record(f"gemini:{self._model()}")
        cands = r.json().get("candidates") or []
        for part in ((cands[0].get("content") or {}).get("parts") or []) if cands else []:
            inline = part.get("inline_data") or part.get("inlineData")
            if inline and inline.get("data"):
                out_path = Path(out_path)
                out_path.parent.mkdir(parents=True, exist_ok=True)
                out_path.write_bytes(base64.b64decode(inline["data"]))
                info = ffmpeg.probe(out_path)
                return ImageResult(out_path, int(info["width"]), int(info["height"]), {"model": self._model()})
        raise ProviderError("Gemini ไม่ส่งภาพกลับมา (อาจโดนตัวกรองเนื้อหา) — ลองปรับคำบรรยายภาพ")
