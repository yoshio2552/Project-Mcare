"""ภาพจำลอง (สร้างด้วย ffmpeg) — ทดสอบระบบโดยไม่ใช้ API + ตัวเลือก 'ไม่ใช้ภาพ AI'"""
from __future__ import annotations

import hashlib
from pathlib import Path

from ...core import ffmpeg
from ...core.errors import ConfigError
from ...core.registry import register
from ..base import ImageProvider, ImageResult


@register("image", "none", label="ไม่ใช้ภาพ AI")
class NoImage(ImageProvider):
    def generate(self, prompt: str, out_path: Path, *, seed: int) -> ImageResult:
        raise ConfigError("ยังไม่ได้เลือกตัวสร้างภาพ AI (แท็บตั้งค่า → ภาพ AI)")


@register("image", "mock", label="เดโม (ภาพจำลอง ไม่ใช้ API)")
class MockImage(ImageProvider):
    credit = "AI-generated image (demo)"

    def generate(self, prompt: str, out_path: Path, *, seed: int) -> ImageResult:
        h = hashlib.md5(f"{prompt}{seed}".encode()).hexdigest()
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        ffmpeg.run(["-f", "lavfi", "-i", f"gradients=s=1024x1024:c0=0x{h[:6]}:c1=0x{h[6:12]}:c2=0x{h[12:18]}:nb_colors=3:d=1",
                    "-vf", "drawgrid=w=128:h=128:t=3:c=white@0.35", "-frames:v", "1", "-q:v", "3", out_path])
        return ImageResult(out_path, 1024, 1024, {"model": "mock"})
