"""Gemini ผ่าน REST ตรงๆ (ไม่ต้องติดตั้ง SDK เพิ่ม)"""
from __future__ import annotations

import base64

from ...core import http, quota
from ...core.errors import ConfigError, ProviderError, QuotaExceeded
from ...core.registry import register
from ..base import LLMProvider

API = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"


@register("llm", "gemini", label="Gemini (Google API)", needs_keys=("gemini",))
class Gemini(LLMProvider):
    @property
    def supports_vision(self) -> bool:
        return True                        # Gemini ทุกรุ่นปัจจุบันรับรูปได้

    def model(self) -> str:
        """light = งานจำนวนเยอะแต่ง่าย (ตรวจภาพ) → ใช้รุ่น Lite ที่โควตาฟรีเยอะกว่ามาก"""
        if self.light and str(self.cfg.get("gemini.model_light", "")).strip():
            return str(self.cfg["gemini.model_light"]).strip()
        return str(self.cfg["gemini.model"])

    def _complete(self, system: str, prompt: str, json_mode: bool, images: list[bytes] | None = None) -> str:
        key = self.cfg.require_secret("gemini", "Gemini API key")
        model = self.model()
        qkey = f"gemini:{model}"
        if quota.is_exhausted(qkey):
            raise ConfigError(self._quota_msg(model))
        parts: list[dict] = [{"text": prompt}]
        for i, img in enumerate(images or [], 1):
            parts += [{"text": f"[image {i}]"},
                      {"inline_data": {"mime_type": "image/jpeg", "data": base64.b64encode(img).decode()}}]
        body: dict = {
            "contents": [{"role": "user", "parts": parts}],
            "generationConfig": {"temperature": float(self.cfg.get("llm.temperature", 1.0))},
        }
        if system:
            body["systemInstruction"] = {"parts": [{"text": system}]}
        if json_mode:
            body["generationConfig"]["responseMimeType"] = "application/json"
        try:
            r = http.request("POST", API.format(model=model),
                             headers={"x-goog-api-key": key, "Content-Type": "application/json"},
                             json=body, timeout=150)
        except QuotaExceeded:
            quota.mark_exhausted(qkey)
            raise ConfigError(self._quota_msg(model)) from None
        quota.record(qkey)
        data = r.json()
        cands = data.get("candidates") or []
        if not cands:
            reason = (data.get("promptFeedback") or {}).get("blockReason", "ไม่ทราบสาเหตุ")
            raise ProviderError(f"Gemini ไม่ตอบ (blockReason: {reason}) — ลองปรับหัวข้อหรือเปลี่ยนโมเดล")
        parts = (cands[0].get("content") or {}).get("parts") or []
        text = "".join(p.get("text", "") for p in parts if not p.get("thought"))
        if not text.strip():
            raise ProviderError(f"Gemini ตอบว่าง (finishReason: {cands[0].get('finishReason')})")
        return text

    @staticmethod
    def _quota_msg(model: str) -> str:
        return (f"โควตาฟรีของ Gemini ({model}) วันนี้หมดแล้ว — รีเซ็ต {quota.reset_local_text()} "
                "· ระหว่างนี้: สลับตัวเขียนบทเป็น Ollama ในแท็บตั้งค่า หรือเปิด billing ที่ Google AI Studio")
