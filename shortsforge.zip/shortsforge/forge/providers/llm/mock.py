"""AI จำลอง — ตอบตามกฎตายตัวจากพรอมต์ ใช้ทดสอบระบบทั้งชุดโดยไม่ต้องมี key/อินเทอร์เน็ต
(ไม่ฉลาด: แค่พิสูจน์ว่าท่อทั้งเส้นทำงานถูก)"""
from __future__ import annotations

import json
import re

from ...core.registry import register
from ..base import LLMProvider


def _grab(prompt: str, pattern: str, default: str = "") -> str:
    m = re.search(pattern, prompt)
    return m.group(1).strip() if m else default


@register("llm", "mock", label="เดโม (AI จำลอง ไม่ใช้ API)")
class MockLLM(LLMProvider):
    @property
    def supports_vision(self) -> bool:
        return bool(self.cfg.get("mock.vision", False))

    def _complete(self, system: str, prompt: str, json_mode: bool, images: list[bytes] | None = None) -> str:
        task = _grab(prompt, r"TASK: (\w+)")
        if task == "judge":
            return json.dumps(self._judge(prompt), ensure_ascii=False)
        if task == "script":
            return json.dumps(self._script(prompt), ensure_ascii=False)
        if task == "fit":
            return json.dumps(self._fit(prompt), ensure_ascii=False)
        if task == "edit":
            return json.dumps(self._edit(prompt), ensure_ascii=False)
        return "ok"

    @staticmethod
    def _script(prompt: str) -> dict:
        topic = _grab(prompt, r"Topic: (.+)")
        n = int(_grab(prompt, r"Number of scenes: (\d+)", "4"))
        budgets = [int(x) for x in re.findall(r"scene \d+ ≈ (\d+)", prompt)] or [60] * n
        nbeats = [int(x) for x in re.findall(r"in (\d+) beats", prompt)] or [2] * n
        subjects = ["doctor hands", "city night traffic", "coffee pouring", "runner sunrise", "typing laptop",
                    "rain window", "crowd walking", "mountain clouds", "kitchen cooking", "ocean waves",
                    "office meeting", "phone scrolling"]
        scenes = []
        for i in range(n):
            role = "hook" if i == 0 else "cta" if i == n - 1 else "body"
            words = f"ฉาก {i + 1} เกี่ยวกับ {topic} " * 10
            text = "".join(words.split())[: budgets[min(i, len(budgets) - 1)]]
            text = re.sub(r"(.{12})", r"\1 ", text).strip()
            phrases = text.split(" ")
            k = max(1, min(nbeats[min(i, len(nbeats) - 1)], len(phrases)))
            per = -(-len(phrases) // k)
            beats = []
            for j in range(k):
                say = " ".join(phrases[j * per:(j + 1) * per])
                if not say:
                    continue
                subj = subjects[(i * 3 + j) % len(subjects)]
                beat = {"say": say, "kind": "stock", "visual": f"close-up of {subj}",
                        "queries": [subj, subj.split()[0], "background"]}
                if "AI illustrations" in prompt and (i + j) % 3 == 0 and j > 0:   # ทดสอบเส้นทางภาพ AI
                    beat.update({"kind": "aiimage", "image_prompt": f"a glowing brain resting on a soft cloud, scene {i + 1}"})
                elif "Visual planner" in prompt and (i + j) % 2 == 1:      # ทดสอบเส้นทางภาพอธิบาย
                    tpl = ["big_number", "myth_fact", "steps", "headline"][(i + j) % 4]
                    ex = {"big_number": {"value": f"{60 + i}%", "label": say[:30]},
                          "myth_fact": {"myth": say[:20], "fact": say[-20:]},
                          "steps": {"title": "ทำแบบนี้", "items": [say[:12], say[12:24] or "ข้อสอง", "ข้อสาม"]},
                          "headline": {"text": say[:40], "emphasis": say[:4]}}[tpl]
                    beat.update({"kind": "graphic", "graphic": {"template": tpl, **ex}})
                beats.append(beat)
            scenes.append({"role": role, "note": f"โทนภาพฉาก {i + 1}", "beats": beats})
        return {"title": f"คลิป {topic}"[:40], "music_prompt": "calm upbeat instrumental, light piano", "scenes": scenes}

    @staticmethod
    def _judge(prompt: str) -> dict:
        """ให้คะแนนตามคำที่ตรงกับ "intended picture" ของช็อตนั้น — แค่ให้ทดสอบเส้นทางการตัดสินได้"""
        rows, want = [], set()
        for line in prompt.splitlines():
            m = re.match(r"SHOT \w+ — .*intended picture: (.+)$", line)
            if m:
                want = {w for w in re.split(r"[^a-z]+", m.group(1).lower()) if len(w) > 2}
                continue
            m = re.match(r"\s+([A-Z]\d+)\. .*?title/tags: (.*?) ·", line)
            if m:
                have = {w for w in re.split(r"[^a-z]+", m.group(2).lower()) if len(w) > 2}
                hit = len(want & have)
                rows.append({"id": m.group(1), "score": min(10, 3 + 3 * hit), "why": "ตรงคำค้น" if hit else "ไม่ค่อยตรง"})
        return {"scores": rows}

    @staticmethod
    def _fit(prompt: str) -> dict:
        rows = json.loads(re.search(r"Scenes:\n(\[.*?\])\n\nReturn", prompt, re.S).group(1))
        out = []
        for r in rows:
            target = r["target_chars"]
            flat = "".join(r["narration"].split())
            flat = (flat * (target // max(1, len(flat)) + 1))[:target]
            out.append({"id": r["id"], "narration": re.sub(r"(.{12})", r"\1 ", flat).strip()})
        return {"scenes": out}

    @staticmethod
    def _edit(prompt: str) -> dict:
        instr = _grab(prompt, r"INSTRUCTION FROM THE USER:\n(.+)")
        focus = _grab(prompt, r"WHERE THE USER IS LOOKING.*?:\n(\{.*?\})")
        try:
            scene = (json.loads(focus) or {}).get("scene") or 1
        except json.JSONDecodeError:
            scene = 1
        m = re.search(r"ฉาก(?:ที่)?\s*(\d+)", instr)
        if m:
            scene = int(m.group(1))
        ops: list[dict] = []
        if "เพลง" in instr and ("เบา" in instr or "ลด" in instr):
            ops.append({"op": "set_music_volume", "db": -24})
        elif "เพลง" in instr:
            ops.append({"op": "set_music_prompt", "text": "energetic electronic instrumental, driving beat"})
        if "ภาพ AI" in instr or "ภาพเอไอ" in instr:
            ops.append({"op": "set_aiimage", "scene": scene, "shot": 1, "prompt": "a tired brain charging like a battery"})
        elif "ภาพอธิบาย" in instr or "ตัวเลขใหญ่" in instr:
            ops.append({"op": "set_graphic", "scene": scene, "shot": 1, "template": "headline",
                        "text": "ข้อความเด็ดของฉากนี้", "emphasis": "เด็ด"})
        elif "ภาพ" in instr or "คลิป" in instr:
            kw = _grab(instr, r"เป็น\s*([A-Za-z][A-Za-z ]+)")
            ops.append({"op": "set_keywords", "scene": scene, "keywords": [kw]} if kw
                       else {"op": "swap_visual", "scene": scene})
        if "พูดเร็ว" in instr or "เร็วขึ้น" in instr:
            ops.append({"op": "set_setting", "key": "tts.speed", "value": 1.1})
        if "บท" in instr and "ใหม่" not in instr and not ops:
            ops.append({"op": "set_narration", "scene": scene, "text": "บทใหม่ที่กระชับขึ้น ตรงประเด็นกว่าเดิม"})
        if not ops:
            return {"explanation": "", "clarify": "ช่วยบอกให้ชัดขึ้นอีกนิดว่าอยากแก้ส่วนไหน", "ops": []}
        return {"explanation": "จัดการตามที่ขอ (เดโม)", "clarify": "", "ops": ops}
