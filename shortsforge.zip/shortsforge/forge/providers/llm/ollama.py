"""Ollama (Qwen ฯลฯ) ผ่าน REST /api/chat — รันในเครื่อง ไม่เสียเงิน"""
from __future__ import annotations

import base64

from ...core import http
from ...core.errors import ConfigError, ProviderError
from ...core.registry import register
from ..base import LLMProvider


@register("llm", "ollama", label="Ollama (Qwen ในเครื่อง)")
class Ollama(LLMProvider):
    def _host(self) -> str:
        return str(self.cfg["ollama.host"]).rstrip("/")

    def list_models(self) -> list[str]:
        try:
            r = http.request("GET", f"{self._host()}/api/tags", retries=1, timeout=8)
        except ProviderError as e:
            raise ConfigError(f"เชื่อม Ollama ที่ {self._host()} ไม่ได้ — เปิดโปรแกรม Ollama ก่อน ({e})")
        return [m["name"] for m in r.json().get("models", [])]

    @property
    def supports_vision(self) -> bool:
        return bool(str(self.cfg.get("ollama.vision_model", "")).strip())

    def _complete(self, system: str, prompt: str, json_mode: bool, images: list[bytes] | None = None) -> str:
        user: dict = {"role": "user", "content": prompt}
        model = self.cfg["ollama.model"]
        if images and self.supports_vision:      # รูปต้องไปที่โมเดลที่ดูภาพได้ เช่น qwen2.5vl / qwen3-vl
            user["images"] = [base64.b64encode(b).decode() for b in images]
            model = str(self.cfg["ollama.vision_model"]).strip()
        messages = ([{"role": "system", "content": system}] if system else []) + [user]
        body: dict = {
            "model": model, "messages": messages, "stream": False,
            "options": {"temperature": float(self.cfg.get("llm.temperature", 1.0)), "num_ctx": 8192},
            "think": bool(self.cfg.get("ollama.think", False)),
        }
        if json_mode:
            body["format"] = "json"
        url = f"{self._host()}/api/chat"
        try:
            r = http.request("POST", url, json=body, timeout=900, retries=2)
        except ProviderError as e:
            msg = str(e)
            if "think" in msg.lower():       # โมเดลรุ่นที่ไม่รู้จัก think → ส่งใหม่โดยไม่มีฟิลด์นี้
                body.pop("think", None)
                r = http.request("POST", url, json=body, timeout=900, retries=2)
            elif "not found" in msg.lower():
                raise ConfigError(f"ยังไม่มีโมเดล {model} ในเครื่อง — รัน: ollama pull {model}")
            elif "ConnectionError" in msg or "Max retries" in msg:
                raise ConfigError(f"เชื่อม Ollama ที่ {self._host()} ไม่ได้ — เปิดโปรแกรม Ollama ก่อน")
            else:
                raise
        text = (r.json().get("message") or {}).get("content", "")
        if not text.strip():
            raise ProviderError("Ollama ตอบว่าง — ลองเพิ่ม num_ctx หรือเปลี่ยนโมเดล")
        return text
