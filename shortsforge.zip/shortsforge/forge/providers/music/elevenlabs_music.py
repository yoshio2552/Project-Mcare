"""ElevenLabs Music — สร้างเพลงประกอบ "ความยาวตรงกับคลิป" จากคำบรรยายหนึ่งประโยค (instrumental)

ตามเอกสาร: music_length_ms ต้องอยู่ระหว่าง 3,000–600,000 ms และ force_instrumental ใช้ได้กับ prompt
"""
from __future__ import annotations

from pathlib import Path

from ...core import ffmpeg, http
from ...core.registry import register
from ..base import MusicProvider, MusicResult

URL = "https://api.elevenlabs.io/v1/music?output_format=mp3_44100_128"


@register("music", "elevenlabs", label="ElevenLabs Music (สร้างเพลงตามคลิป)", needs_keys=("elevenlabs",))
class ElevenLabsMusic(MusicProvider):
    def compose(self, prompt: str, length_s: float, out_path: Path) -> MusicResult:
        key = self.cfg.require_secret("elevenlabs", "ElevenLabs API key")
        ms = int(min(600_000, max(3_000, round(length_s * 1000))))
        r = http.request(
            "POST", URL, headers={"xi-api-key": key, "Content-Type": "application/json", "Accept": "audio/*"},
            json={"prompt": prompt, "music_length_ms": ms, "force_instrumental": True, "model_id": "music_v1"},
            timeout=300,
        )
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_bytes(r.content)
        return MusicResult(out_path, ffmpeg.duration(out_path), {"requested_ms": ms})
