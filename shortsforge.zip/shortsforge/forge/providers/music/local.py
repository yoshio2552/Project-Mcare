"""คลังเพลงในเครื่อง — วางไฟล์เพลงไว้ใน assets/music (เช่นเพลงฟรีจาก Mixkit/Pixabay Music)

ตั้งชื่อไฟล์/โฟลเดอร์ให้มีคำบอกอารมณ์ เช่น calm_piano.mp3, upbeat/electro_pop.mp3
ระบบจะเลือกเพลงที่ชื่อตรงกับ music prompt มากที่สุด และชอบเพลงที่ยาวพอ (ไม่ต้องวนลูป)
"""
from __future__ import annotations

import hashlib
import re
from pathlib import Path

from ...core import ffmpeg
from ...core.errors import ConfigError
from ...core.registry import register
from ..base import MusicProvider, MusicResult

EXTS = {".mp3", ".wav", ".m4a", ".ogg", ".flac", ".aac"}


def _words(s: str) -> set[str]:
    return {w for w in re.split(r"[^a-z0-9]+", s.lower()) if len(w) > 2}


@register("music", "local", label="คลังเพลงในเครื่อง (assets/music)")
class LocalMusic(MusicProvider):
    def compose(self, prompt: str, length_s: float, out_path: Path) -> MusicResult:
        d = Path(str(self.cfg.get("music.local_dir", "assets/music")))
        root = d if d.is_absolute() else Path(__file__).resolve().parents[3] / d
        files = [p for p in root.rglob("*") if p.suffix.lower() in EXTS and p.is_file()] if root.exists() else []
        if not files:
            raise ConfigError(f"ไม่พบไฟล์เพลงใน {root} — วางไฟล์ .mp3/.wav ไว้ที่นั่น หรือเปลี่ยนแหล่งเพลง")
        q = _words(prompt)
        tie = lambda p: hashlib.md5((prompt + str(p)).encode()).hexdigest()
        info = {p: ffmpeg.duration(p) for p in files}
        best = max(files, key=lambda p: (len(q & _words(str(p.relative_to(root)))),
                                         info[p] >= length_s, tie(p)))
        return MusicResult(best, info[best], {"picked": str(best.relative_to(root))})
