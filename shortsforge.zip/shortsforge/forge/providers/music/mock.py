"""เพลงจำลอง (คอร์ดซายน์) และตัวเลือก "ไม่ใส่เพลง" """
from __future__ import annotations

from pathlib import Path

from ...core import ffmpeg
from ...core.registry import register
from ..base import MusicProvider, MusicResult


@register("music", "mock", label="เดโม (เพลงจำลอง ไม่ใช้ API)")
class MockMusic(MusicProvider):
    def compose(self, prompt: str, length_s: float, out_path: Path) -> MusicResult:
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        L = f"{length_s:.3f}"
        ffmpeg.run([
            "-f", "lavfi", "-i", f"sine=f=220:d={L}:r=44100",
            "-f", "lavfi", "-i", f"sine=f=277.18:d={L}:r=44100",
            "-f", "lavfi", "-i", f"sine=f=329.63:d={L}:r=44100",
            "-filter_complex", "amix=inputs=3:normalize=0,volume=0.5,tremolo=f=2:d=0.35",
            "-c:a", "libmp3lame", "-b:a", "128k", out_path,
        ])
        return MusicResult(out_path, ffmpeg.duration(out_path), {"mock": True})


@register("music", "none", label="ไม่ใส่เพลง")
class NoMusic(MusicProvider):
    def compose(self, prompt: str, length_s: float, out_path: Path) -> MusicResult:  # pragma: no cover
        raise RuntimeError("provider 'none' ไม่สร้างเพลง — MusicStep ต้องข้ามก่อนเรียก")
