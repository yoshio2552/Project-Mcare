"""ตัวช่วยร่วมของ stock provider: เลือกไฟล์ที่เหมาะที่สุดจากหลายความละเอียดของคลิปเดียวกัน"""
from __future__ import annotations


def effective_width(w: int, h: int, target_ratio: float = 9 / 16) -> float:
    """ความกว้างจริงที่เหลือหลังครอปให้เป็นแนวตั้ง 9:16 (คลิปแนวนอนถูกครอปกลาง เหลือแค่ h*9/16)"""
    if w <= 0 or h <= 0:
        return 0.0
    return float(w) if h > w else h * target_ratio


def pick_best_file(files: list[dict], want_effective: float = 1000.0) -> dict | None:
    """files: [{"url","width","height"}]
    เลือกไฟล์ "เล็กที่สุดที่คมพอ" (effective width ≥ want) — ถ้าไม่มีที่คมพอ เอาไฟล์ที่คมที่สุด
    ช่วยไม่ให้โหลดไฟล์ 4K ใหญ่โดยไม่จำเป็น แต่ก็ไม่ได้ภาพแตกถ้ามีของดีกว่า"""
    ok = [f for f in files if f.get("url") and f.get("width") and f.get("height")]
    if not ok:
        return None
    good = [f for f in ok if effective_width(f["width"], f["height"]) >= want_effective]
    if good:
        return min(good, key=lambda f: f["width"] * f["height"])
    return max(ok, key=lambda f: effective_width(f["width"], f["height"]))
