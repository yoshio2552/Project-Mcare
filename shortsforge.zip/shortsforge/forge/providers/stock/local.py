"""คลังคลิปในเครื่อง — วางไฟล์ .mp4/.mov ไว้ใน assets/stock แล้วระบบค้นจาก "ชื่อไฟล์และชื่อโฟลเดอร์"

ใช้กับ Mixkit หรือแหล่งที่ไม่มี API: โหลดคลิปมาวางเองเป็นโฟลเดอร์ตามหมวด เช่น
    assets/stock/medical/doctor_hands_closeup.mp4
    assets/stock/city/night_traffic_timelapse.mp4
คำค้นภาษาอังกฤษของระบบจะจับคู่กับคำในชื่อไฟล์/โฟลเดอร์
"""
from __future__ import annotations

import re
from pathlib import Path

from ...core import ffmpeg
from ...core.registry import register
from ..base import Clip, StockProvider

EXTS = {".mp4", ".mov", ".m4v", ".webm", ".mkv"}
_probe_cache: dict[str, dict] = {}


def _words(s: str) -> set[str]:
    return {w for w in re.split(r"[^a-z0-9]+", s.lower()) if len(w) > 2}


@register("stock", "local", label="คลังในเครื่อง (assets/stock)")
class LocalStock(StockProvider):
    def _root(self) -> Path:
        d = Path(str(self.cfg.get("stock.local_dir", "assets/stock")))
        return d if d.is_absolute() else Path(__file__).resolve().parents[3] / d

    def search(self, query: str, *, per_page: int = 10) -> list[Clip]:
        root = self._root()
        if not root.exists():
            return []
        q = _words(query)
        if not q:
            return []
        scored: list[tuple[int, Path]] = []
        for p in root.rglob("*"):
            if p.suffix.lower() in EXTS and p.is_file():
                hit = len(q & _words(str(p.relative_to(root))))
                if hit:
                    scored.append((hit, p))
        scored.sort(key=lambda t: (-t[0], str(t[1])))
        clips = []
        for _, p in scored[:per_page]:
            info = _probe_cache.get(str(p)) or _probe_cache.setdefault(str(p), ffmpeg.probe(p))
            clips.append(Clip(provider="local", id=str(p.relative_to(root)), download_url=str(p),
                              local_path=str(p), duration=info["duration"], width=info["width"],
                              height=info["height"], credit="คลังส่วนตัว",
                              title=" ".join(re.split(r"[^A-Za-z0-9]+", str(p.relative_to(root).with_suffix(""))))))
        return clips

    def download(self, clip: Clip, dest: Path) -> Path:
        return Path(clip.local_path)
