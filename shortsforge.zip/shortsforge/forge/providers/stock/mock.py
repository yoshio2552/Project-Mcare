"""คลิปจำลอง (สร้างด้วย ffmpeg) — ไว้ทดสอบ pipeline และลองใช้หน้าโปรแกรมโดยไม่มี API key"""
from __future__ import annotations

import hashlib
from pathlib import Path

from ...core import ffmpeg
from ...core.registry import register
from ..base import Clip, StockProvider


def _hue(seed: str) -> tuple[str, str]:
    h = hashlib.md5(seed.encode()).hexdigest()
    return f"0x{h[:6]}", f"0x{h[6:12]}"


@register("stock", "mock", label="เดโม (คลิปจำลอง ไม่ใช้ API)")
class MockStock(StockProvider):
    def search(self, query: str, *, per_page: int = 10) -> list[Clip]:
        base = hashlib.md5(query.encode()).hexdigest()[:6]
        out = []
        for i in range(min(per_page, 6)):
            portrait = i % 3 != 2          # ปน แนวตั้ง/แนวนอน เพื่อทดสอบการครอป
            out.append(Clip(provider="mock", id=f"{base}-{i}", download_url=f"mock://{query}/{i}",
                            duration=4.0 + 2 * (i % 3), width=720 if portrait else 1280,
                            height=1280 if portrait else 720, credit="mock",
                            title=query if i % 2 == 0 else "generic background"))
        return out

    def download(self, clip: Clip, dest: Path) -> Path:
        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        c0, c1 = _hue(clip.id)
        speed = 0.01 + (int(clip.id[-1]) % 3) * 0.01
        ffmpeg.run(["-f", "lavfi", "-i",
                    f"gradients=s={clip.width}x{clip.height}:d={clip.duration}:r=30:c0={c0}:c1={c1}:speed={speed}",
                    "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p", "-an", dest])
        return dest
