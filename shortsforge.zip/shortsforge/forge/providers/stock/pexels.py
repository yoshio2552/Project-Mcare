"""Pexels Videos API — ฟรี มีตัวกรองแนวตั้งในตัว (ขีดจำกัดตามเอกสาร Pexels ราว 200 คำขอ/ชม.)"""
from __future__ import annotations

import re
from pathlib import Path

from ...core import http
from ...core.registry import register
from ..base import Clip, StockProvider
from ._util import pick_best_file

API = "https://api.pexels.com/videos/search"


def _title_from_url(url: str) -> str:
    """Pexels ไม่ส่งคำบรรยายมา แต่ URL มีชื่อคลิปอยู่ เช่น /video/woman-sleeping-in-bed-856973/ → woman sleeping in bed"""
    m = re.search(r"/video/([^/?#]+?)-\d+/?(?:[?#].*)?$", url or "")
    return m.group(1).replace("-", " ").strip() if m else ""


@register("stock", "pexels", label="Pexels", needs_keys=("pexels",))
class Pexels(StockProvider):
    def search(self, query: str, *, per_page: int = 10) -> list[Clip]:
        key = self.cfg.require_secret("pexels", "Pexels API key")
        r = http.request("GET", API, headers={"Authorization": key},
                         params={"query": query, "orientation": "portrait", "size": "medium",
                                 "per_page": min(80, max(1, per_page))}, timeout=30)
        clips: list[Clip] = []
        for v in r.json().get("videos", []):
            files = [{"url": f.get("link"), "width": f.get("width"), "height": f.get("height")}
                     for f in v.get("video_files", []) if f.get("file_type") == "video/mp4"]
            best = pick_best_file(files)
            if not best:
                continue
            user = (v.get("user") or {}).get("name", "")
            clips.append(Clip(
                provider="pexels", id=str(v["id"]), download_url=best["url"],
                preview_url=v.get("image", ""), page_url=v.get("url", ""),
                duration=float(v.get("duration") or 0), width=int(best["width"]), height=int(best["height"]),
                credit=f"Video by {user} on Pexels" if user else "Pexels",
                title=_title_from_url(v.get("url", "")),
            ))
        return clips

    def download(self, clip: Clip, dest: Path) -> Path:
        return http.download(clip.download_url, dest)
