"""Pixabay Videos API — ไม่มีตัวกรองแนวตั้ง ระบบจึงดึงมาแล้วให้ตัวจัดอันดับเลือกเองทีหลัง"""
from __future__ import annotations

from pathlib import Path

from ...core import http
from ...core.registry import register
from ..base import Clip, StockProvider
from ._util import pick_best_file

API = "https://pixabay.com/api/videos/"


@register("stock", "pixabay", label="Pixabay", needs_keys=("pixabay",))
class Pixabay(StockProvider):
    def search(self, query: str, *, per_page: int = 10) -> list[Clip]:
        key = self.cfg.require_secret("pixabay", "Pixabay API key")
        r = http.request("GET", API, params={"key": key, "q": query[:100], "video_type": "film",
                                             "safesearch": "true", "per_page": min(200, max(3, per_page))},
                         timeout=30)
        clips: list[Clip] = []
        for h in r.json().get("hits", []):
            vids = h.get("videos") or {}
            files = [{"url": v.get("url"), "width": v.get("width"), "height": v.get("height"),
                      "thumb": v.get("thumbnail", "")} for v in vids.values() if isinstance(v, dict)]
            best = pick_best_file(files)
            if not best:
                continue
            user = h.get("user", "")
            clips.append(Clip(
                provider="pixabay", id=str(h["id"]), download_url=best["url"],
                preview_url=best.get("thumb", ""), page_url=h.get("pageURL", ""),
                duration=float(h.get("duration") or 0), width=int(best["width"]), height=int(best["height"]),
                credit=f"Video by {user} on Pixabay" if user else "Pixabay",
                title=str(h.get("tags", "")),
            ))
        return clips

    def download(self, clip: Clip, dest: Path) -> Path:
        return http.download(clip.download_url, dest)
