"""Edge TTS — ฟรี ไม่ต้องใช้ key (ตัวสำรอง/ใช้ทดสอบ)"""
from __future__ import annotations

import asyncio
from pathlib import Path

from ...core import ffmpeg
from ...core.errors import ConfigError, ProviderError
from ...core.models import Word
from ...core.registry import register
from ...core.text import estimate_words, tokenize
from ..base import TTSProvider, TTSResult


@register("tts", "edge", label="Edge TTS (ฟรี)")
class EdgeTTS(TTSProvider):
    def fingerprint_parts(self) -> list:
        return [self.name, self.cfg["edge.voice"], self.cfg["tts.speed"]]

    def synthesize(self, text: str, out_path: Path, *, language: str) -> TTSResult:
        try:
            import edge_tts  # type: ignore
        except ImportError:
            raise ConfigError("ยังไม่ได้ติดตั้ง edge-tts — รัน: pip install edge-tts")
        rate = f"{int(round((float(self.cfg['tts.speed']) - 1.0) * 100)):+d}%"
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        boundaries: list[tuple[float, float, str]] = []

        async def go():
            com = edge_tts.Communicate(text, self.cfg["edge.voice"], rate=rate)
            with open(out_path, "wb") as f:
                async for chunk in com.stream():
                    if chunk["type"] == "audio":
                        f.write(chunk["data"])
                    elif chunk["type"] in ("WordBoundary", "SentenceBoundary"):
                        # offset/duration หน่วย 100 นาโนวินาที
                        boundaries.append((chunk["offset"] / 1e7, chunk["duration"] / 1e7, chunk.get("text", "")))

        try:
            asyncio.run(go())
        except Exception as e:
            raise ProviderError(f"Edge TTS ล้มเหลว: {type(e).__name__}: {e}")
        dur = ffmpeg.duration(out_path)

        words: list[Word] = []
        # ถ้ามี WordBoundary ละเอียดพอ ใช้เวลาจริง; ถ้าได้แค่ระดับประโยค ใช้ค่าประมาณจะนุ่มกว่า
        if len(boundaries) >= max(3, len(tokenize(text)) // 2):
            words = [Word(t, round(s, 3), round(s + d, 3)) for s, d, t in boundaries if t.strip()]
        if not words:
            words = estimate_words(text, dur)
        return TTSResult(out_path, dur, words, {"timing": "boundary" if len(words) == len(boundaries) else "estimated"})
