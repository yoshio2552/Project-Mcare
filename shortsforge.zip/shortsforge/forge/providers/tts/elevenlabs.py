"""ElevenLabs Text-to-Speech พร้อมเวลาระดับตัวอักษร (/with-timestamps)

หมายเหตุภาษาไทย: ตามเอกสาร ElevenLabs เฉพาะ eleven_v3 ที่รองรับไทย
(eleven_multilingual_v2 / eleven_flash_v2_5 ไม่มีไทย) จึงตั้ง eleven_v3 เป็นค่าเริ่มต้น
"""
from __future__ import annotations

import base64
from pathlib import Path

from ...core import ffmpeg, http
from ...core.errors import ProviderError
from ...core.registry import register
from ...core.text import estimate_words, words_from_char_alignment
from ..base import TTSProvider, TTSResult

BASE = "https://api.elevenlabs.io"


@register("tts", "elevenlabs", label="ElevenLabs", needs_keys=("elevenlabs",))
class ElevenLabsTTS(TTSProvider):
    def _headers(self) -> dict:
        return {"xi-api-key": self.cfg.require_secret("elevenlabs", "ElevenLabs API key"),
                "Content-Type": "application/json"}

    def fingerprint_parts(self) -> list:
        c = self.cfg
        return [self.name, c["elevenlabs.model"], c["elevenlabs.voice_id"], c["elevenlabs.stability"],
                c["elevenlabs.similarity"], c["tts.speed"]]

    def list_voices(self) -> list[tuple[str, str]]:
        r = http.request("GET", f"{BASE}/v1/voices", headers=self._headers(), timeout=30)
        out = []
        for v in r.json().get("voices", []):
            labels = v.get("labels") or {}
            extra = ", ".join(x for x in (labels.get("language"), labels.get("gender"), labels.get("accent")) if x)
            out.append((f"{v.get('name', '?')}" + (f" ({extra})" if extra else ""), v["voice_id"]))
        return sorted(out)

    def synthesize(self, text: str, out_path: Path, *, language: str) -> TTSResult:
        voice = str(self.cfg["elevenlabs.voice_id"]).strip()
        if not voice:
            from ...core.errors import ConfigError
            raise ConfigError("ยังไม่ได้เลือก Voice ID ของ ElevenLabs — แท็บ 'เสียง & เพลง' → โหลดรายชื่อเสียง")
        body = {
            "text": text,
            "model_id": self.cfg["elevenlabs.model"],
            "voice_settings": {
                "stability": float(self.cfg["elevenlabs.stability"]),
                "similarity_boost": float(self.cfg["elevenlabs.similarity"]),
                "speed": float(self.cfg["tts.speed"]),
            },
        }
        if language:
            body["language_code"] = language
        url = f"{BASE}/v1/text-to-speech/{voice}/with-timestamps?output_format=mp3_44100_128"
        try:
            r = http.request("POST", url, headers=self._headers(), json=body, timeout=180)
        except ProviderError as e:
            # บาง model/ภาษาอาจใช้ language_code ไม่ได้ → ลองใหม่โดยไม่ส่งฟิลด์นี้
            if "language" in str(e).lower() and "language_code" in body:
                body.pop("language_code")
                r = http.request("POST", url, headers=self._headers(), json=body, timeout=180)
            else:
                raise
        data = r.json()
        audio_b64 = data.get("audio_base64") or data.get("audio_base_64")
        if not audio_b64:
            raise ProviderError("ElevenLabs ไม่ส่งไฟล์เสียงกลับมา")
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_bytes(base64.b64decode(audio_b64))
        dur = ffmpeg.duration(out_path)

        al = data.get("alignment") or {}
        chars = al.get("characters") or []
        starts = al.get("character_start_times_seconds")
        ends = al.get("character_end_times_seconds")
        if starts is None and al.get("char_start_times_ms"):          # เผื่อรูปแบบมิลลิวินาที
            starts = [x / 1000 for x in al["char_start_times_ms"]]
            ends = [x / 1000 for x in al.get("char_end_times_ms", [])]
        if chars and starts and ends:
            words = words_from_char_alignment(text, chars, starts, ends)
            timing = "alignment"
        else:
            words = estimate_words(text, dur)
            timing = "estimated"
        return TTSResult(out_path, dur, words, {"timing": timing})
