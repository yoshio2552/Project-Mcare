"""เสียงจำลอง (โทนเสียงคล้ายพูดเป็นช่วงๆ) — ใช้ทดสอบระบบทั้งชุดโดยไม่เสียเครดิต"""
from __future__ import annotations

from pathlib import Path

from ...core import ffmpeg
from ...core.registry import register
from ...core.text import estimate_words, tokenize
from ..base import TTSProvider, TTSResult


@register("tts", "mock", label="เดโม (เสียงจำลอง ไม่ใช้ API)")
class MockTTS(TTSProvider):
    CPS = 12.0   # ตัวอักษร/วินาที ของเสียงจำลอง

    def fingerprint_parts(self) -> list:
        return [self.name, self.cfg["tts.speed"]]

    def synthesize(self, text: str, out_path: Path, *, language: str) -> TTSResult:
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        dur = max(1.2, len(text.replace(" ", "")) / (self.CPS * float(self.cfg["tts.speed"])) + 0.3)
        n_words = max(1, len(tokenize(text)))
        # โทนเสียง 160Hz สั่นแอมพลิจูดตามจังหวะคำ ให้ duck/มิกซ์ทดสอบได้เหมือนเสียงพูด
        rate = n_words / dur
        expr = f"sine=f=160:d={dur:.3f}:r=44100,tremolo=f={rate * 0.9 + 0.5:.2f}:d=0.9,volume=0.8"
        ffmpeg.run(["-f", "lavfi", "-i", expr, "-c:a", "libmp3lame", "-b:a", "96k", out_path])
        real = ffmpeg.duration(out_path)
        return TTSResult(out_path, real, estimate_words(text, real), {"timing": "estimated", "mock": True})
