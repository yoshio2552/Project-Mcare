"""import นี้ทำให้ registry สแกนและโหลด provider ทุกตัวตั้งแต่ตอนเริ่มโปรแกรม"""
from .core import registry

registry.discover()
