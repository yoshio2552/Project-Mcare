"""ภาพ AI ประจำช่อง: เติมสไตล์เดียวกันทุกภาพ → สร้างภาพ (แคช) → ทำให้เคลื่อนไหว → ได้ช็อตวิดีโอ

แคชตาม (ตัวสร้าง, คำบรรยาย, สไตล์, seed) — รันซ้ำ/เปลี่ยนจุดตัด ไม่สร้างภาพใหม่ ไม่เสียโควตา
อยากได้ภาพใหม่ของช่วงเดิม = เพิ่ม seed (ปุ่ม "สุ่มภาพใหม่")
"""
from __future__ import annotations

import hashlib
from pathlib import Path

from ..core.models import fingerprint
from ..providers.base import ImageProvider
from . import motion

STYLES = {
    "flat": "flat vector illustration, bold simple shapes, soft pastel palette, clean uncluttered background",
    "clay": "3D clay render, soft studio lighting, cute stylized characters, pastel colors, smooth matte materials",
    "watercolor": "loose watercolor illustration, visible paper texture, soft warm colors, gentle washes",
    "comic": "bold comic book illustration, thick clean outlines, halftone shading, vibrant colors",
    "cinematic": "cinematic photograph, dramatic soft lighting, shallow depth of field, 35mm film look",
}
PHOTOREAL = {"cinematic"}
SUFFIX = "vertical composition, main subject centered with space around it, no text, no letters, no logos, no watermark"


def style_text(cfg) -> str:
    st = str(cfg.get("image.style", "flat"))
    if st == "custom":
        return " ".join(str(cfg.get("image.style_custom", "")).split()) or STYLES["flat"]
    return STYLES.get(st, STYLES["flat"])


def is_photoreal(cfg) -> bool:
    return str(cfg.get("image.style", "flat")) in PHOTOREAL


def full_prompt(prompt: str, cfg) -> str:
    return f"{' '.join(prompt.split())}. Style: {style_text(cfg)}. {SUFFIX}."


def seed_for(beat: dict) -> int:
    base = f"{beat.get('image_prompt', '')}|{beat.get('text', '')}"
    return (int(hashlib.md5(base.encode()).hexdigest()[:8], 16) + 7919 * int(beat.get("seed", 0))) % 2_147_483_647


def image_path(provider: ImageProvider, prompt_full: str, seed: int, cache_dir: Path) -> Path:
    return Path(cache_dir) / f"img_{fingerprint(provider.fingerprint_parts(), prompt_full, seed)}.jpg"


def make_clip(provider: ImageProvider, beat: dict, cfg, cache_dir: Path, *, width: int, height: int, fps: int,
              frames: int, index: int, preset: str, crf: int) -> tuple[Path, Path]:
    """คืน (วิดีโอที่เคลื่อนไหวแล้ว, ไฟล์ภาพต้นฉบับ)"""
    prompt_full = full_prompt(beat["image_prompt"], cfg)
    seed = seed_for(beat)
    img = image_path(provider, prompt_full, seed, cache_dir)
    size = None
    if not (img.exists() and img.stat().st_size > 500):
        res = provider.generate(prompt_full, img, seed=seed)
        img, size = res.path, (res.width, res.height)
    mode = motion.pick_mode(str(cfg.get("image.motion", "auto")), index)
    video = motion.animate(img, Path(cache_dir) / "motion", width=width, height=height, fps=fps, frames=frames,
                           mode=mode, fit=str(cfg.get("image.fit", "auto")), src_size=size, preset=preset, crf=crf)
    return video, img
