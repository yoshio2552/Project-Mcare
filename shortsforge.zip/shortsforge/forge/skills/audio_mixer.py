"""ทักษะมิกซ์เสียง — ทำให้เพลงกับเสียงพากย์ "ฟังเป็นงานมืออาชีพ" ไม่เด๋อ

1. เสียงพากย์: ต่อทุกฉากตาม timeline ที่ปัดตามเฟรม + กรอง low-cut + คอมเพรสเบาๆ ให้ระดับเสียงนิ่ง
2. เพลง: ตัดให้พอดีความยาวคลิป (สั้นเกินก็วนด้วย crossfade ไม่ให้สะดุด) + fade in/out
3. Ducking แบบแม่นยำ: ใช้เวลาคำจริงจาก TTS สร้างเส้นลดเสียงเพลง — เพลง "ค่อยๆ หลบ" ก่อนพูด
   แล้วค่อยๆ กลับมาตอนเงียบ (ไม่ใช่คอมเพรสเซอร์ที่ตอบสนองช้ากว่าเสียง)
4. ปรับความดังรวมแบบ 2-pass loudnorm ให้ตรงเป้า LUFS (ค่าเริ่มต้น -14 ตามแพลตฟอร์มคลิปสั้น)
"""
from __future__ import annotations

import json
import math
import re
from pathlib import Path

from ..core import ffmpeg
from ..core.errors import FFmpegError
from .timing import Timeline

SR = 44100


# ------------------------------ เสียงพากย์ ------------------------------
def build_voice_track(tl: Timeline, out_wav: Path) -> None:
    """ต่อเสียงทุกฉากตามช่องเวลาของ timeline (ช่องว่างหน้า/หลังเติมเงียบ)"""
    args: list = []
    chains: list[str] = []
    labels: list[str] = []
    if tl.lead > 0:
        chains.append(f"anullsrc=r={SR}:cl=stereo,atrim=0:{tl.lead:.4f}[lead]")
        labels.append("[lead]")
    for i, item in enumerate(tl.items):
        args += ["-i", item.scene.audio_path]
        chains.append(f"[{i}:a]aresample={SR},aformat=channel_layouts=stereo,"
                      f"apad=whole_dur={item.a_dur:.4f},atrim=0:{item.a_dur:.4f}[a{i}]")
        labels.append(f"[a{i}]")
    if tl.tail > 0:
        chains.append(f"anullsrc=r={SR}:cl=stereo,atrim=0:{tl.tail:.4f}[tail]")
        labels.append("[tail]")
    graph = ";".join(chains) + f";{''.join(labels)}concat=n={len(labels)}:v=0:a=1," \
            "highpass=f=70,acompressor=threshold=0.14:ratio=2.5:attack=6:release=140:makeup=1.4[out]"
    _run_graph(args, graph, ["-map", "[out]", "-c:a", "pcm_s16le", "-ar", str(SR), out_wav], out_wav.parent)


# ------------------------------ เพลง ------------------------------
def build_music_bed(src: str | Path, total: float, out_wav: Path, fade_in: float, fade_out: float) -> None:
    dur = ffmpeg.duration(src)
    fade_out = min(fade_out, total / 2)
    fade_in = min(fade_in, total / 4)
    tail = (f"atrim=0:{total:.4f},afade=t=in:st=0:d={fade_in:.3f},"
            f"afade=t=out:st={max(0.0, total - fade_out):.3f}:d={fade_out:.3f}")
    base = ["aresample=%d" % SR, "aformat=channel_layouts=stereo"]
    if dur >= total + 0.05:
        graph = f"[0:a]{','.join(base)},{tail}[out]"
        args = ["-i", str(src)]
    else:
        # เพลงสั้นกว่าคลิป: ต่อซ้ำด้วย crossfade (รอยต่อไม่สะดุด)
        xf = max(0.3, min(2.0, dur / 4))
        n = max(2, math.ceil((total - xf) / max(0.5, dur - xf)) + 1)
        args = []
        for _ in range(n):
            args += ["-i", str(src)]
        parts = [f"[{i}:a]{','.join(base)}[m{i}]" for i in range(n)]
        cur = "[m0]"
        for i in range(1, n):
            nxt = f"[x{i}]"
            parts.append(f"{cur}[m{i}]acrossfade=d={xf:.3f}:c1=tri:c2=tri{nxt}")
            cur = nxt
        graph = ";".join(parts) + f";{cur}{tail}[out]"
    _run_graph(args, graph, ["-map", "[out]", "-c:a", "pcm_s16le", "-ar", str(SR), out_wav], out_wav.parent)


def speech_segments(tl: Timeline, merge_gap: float = 0.45) -> list[tuple[float, float]]:
    """ช่วงที่มีเสียงพูดบน timeline (รวมคำที่ห่างกันน้อยกว่า merge_gap เป็นช่วงเดียว)"""
    spans: list[tuple[float, float]] = []
    for item in tl.items:
        for w in item.scene.words:
            spans.append((item.a_start + w.start, item.a_start + max(w.end, w.start + 0.05)))
    spans.sort()
    merged: list[list[float]] = []
    for a, b in spans:
        if merged and a - merged[-1][1] <= merge_gap:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    return [(a, b) for a, b in merged]


def duck_expression(segments: list[tuple[float, float]], depth_db: float,
                    attack: float = 0.28, release: float = 0.55) -> str:
    """นิพจน์ volume ของ ffmpeg: 1 = ไม่ลด, 10^(-depth/20) = ลดเต็มที่ ขณะพูด
    ramp ลงเริ่ม 'ก่อน' คำแรก (attack) และ ramp ขึ้นหลังคำสุดท้าย (release)"""
    if not segments or depth_db <= 0:
        return "1"
    low = 10 ** (-depth_db / 20)
    terms = [f"clip(min((t-{a - attack:.3f})/{attack:.3f},({b + release:.3f}-t)/{release:.3f}),0,1)"
             for a, b in segments]
    env = terms[0]
    for t in terms[1:]:
        env = f"max({env},{t})"
    return f"1-(1-{low:.5f})*{env}"


def mix_and_master(voice_wav: Path, bed_wav: Path | None, tl: Timeline, cfg, out_wav: Path) -> dict:
    """มิกซ์เสียงพากย์ + เพลง (ducking) แล้ว master ความดัง คืนผลวัด loudness"""
    target = float(cfg["render.target_lufs"])
    if bed_wav is None:
        pre = "[0:a]anull[mix]"
        args = ["-i", str(voice_wav)]
    else:
        vol = float(cfg["music.volume_db"])
        duck = duck_expression(speech_segments(tl), float(cfg["music.duck_db"]))
        args = ["-i", str(voice_wav), "-i", str(bed_wav)]
        pre = (f"[1:a]volume={vol:.2f}dB,volume='{duck}':eval=frame[m];"
               "[0:a][m]amix=inputs=2:duration=first:normalize=0[mix]")
    # pass 1: วัดความดัง
    work = out_wav.parent
    first = _run_graph(args, pre + f";[mix]loudnorm=I={target}:TP=-1.5:LRA=11:print_format=json[o]",
                       ["-map", "[o]", "-f", "null", "-"], work, loglevel="info")
    m = re.search(r"\{[^{}]*\"input_i\"[^{}]*\}", first, re.S)
    stats: dict = {}
    if m:
        try:
            stats = json.loads(m.group(0))
        except json.JSONDecodeError:
            stats = {}
    if stats and all(k in stats for k in ("input_i", "input_tp", "input_lra", "input_thresh", "target_offset")) \
            and stats["input_i"] not in ("-inf", "inf"):
        ln = (f"loudnorm=I={target}:TP=-1.5:LRA=11:measured_I={stats['input_i']}:measured_TP={stats['input_tp']}:"
              f"measured_LRA={stats['input_lra']}:measured_thresh={stats['input_thresh']}:"
              f"offset={stats['target_offset']}:linear=true")
    else:                                   # วัดไม่ได้ (เช่นเสียงเงียบทั้งไฟล์) → ใช้โหมดไดนามิก
        ln = f"loudnorm=I={target}:TP=-1.5:LRA=11"
    _run_graph(args, pre + f";[mix]{ln},aresample={SR},alimiter=limit=0.89[o]",
               ["-map", "[o]", "-c:a", "pcm_s16le", "-ar", str(SR), out_wav], work)
    return {"measured_lufs": stats.get("input_i"), "target_lufs": target}


# ------------------------------ ภายใน ------------------------------
_GRAPH_FLAGS = [lambda f: ["-filter_complex_script", str(f)], lambda f: ["-/filter_complex", str(f)]]


def _run_graph(inputs: list, graph: str, out_args: list, work: Path, loglevel: str = "error") -> str:
    """เขียน filtergraph ลงไฟล์ (กันบรรทัดคำสั่งยาวเกิน/ปัญหา escape) แล้วรัน ffmpeg"""
    work = Path(work).resolve()
    work.mkdir(parents=True, exist_ok=True)
    script = work / f"_graph_{abs(hash(graph)) % 10**8}.txt"
    script.write_text(graph, encoding="utf-8")
    try:
        # ffmpeg ≤7 ใช้ -filter_complex_script, ffmpeg ≥7/8 ตัดออกแล้วใช้ -/filter_complex → ลองแบบเก่าก่อน ไม่ได้ค่อยสลับ
        for flag in _GRAPH_FLAGS[:]:
            try:
                return ffmpeg.run([*inputs, *flag(script), *out_args], loglevel=loglevel)
            except FFmpegError as ex:
                if "Unrecognized option" in str(ex) and len(_GRAPH_FLAGS) > 1:
                    _GRAPH_FLAGS.remove(flag)
                    continue
                raise
        raise FFmpegError("ffmpeg ไม่รองรับทั้ง -filter_complex_script และ -/filter_complex")
    finally:
        script.unlink(missing_ok=True)
