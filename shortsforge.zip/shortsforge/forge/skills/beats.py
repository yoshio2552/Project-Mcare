"""Beat = ช่วงคำพูดสั้นๆ ในฉาก + ภาพที่ควรเห็นตอนพูดช่วงนั้น

เดิมระบบแบ่งฉากเป็นช็อตยาวเท่าๆ กันแล้ววนใช้คำค้น → ภาพไม่ตรงกับสิ่งที่กำลังพูด
ตอนนี้: บทแต่ละฉากถูกแบ่งเป็น beat → หลังพากย์ได้เวลาของแต่ละคำ → ตัดเข้าช็อตใหม่ "ตรงคำแรก" ของ beat นั้น

กฎที่ทุกฟังก์ชันรักษาไว้: ข้อความของ beat ทุกตัวต่อกันแล้ว (ไม่นับช่องว่าง) = บทพากย์ของฉากเสมอ
ฟังก์ชันในไฟล์นี้ไม่เรียกเน็ต/AI — ทดสอบตรงๆ ได้
"""
from __future__ import annotations

from ..core.models import Scene, Word
from ..core.text import tokenize


def _ns(t: str) -> str:
    return "".join((t or "").split())


def _boundaries(text: str) -> list[int]:
    """ตำแหน่งที่ตัดข้อความได้ (index ในสตริงเดิม): ต้นวลีหลังช่องว่างก่อน แล้วค่อยต้นคำ"""
    out = {m for m in range(1, len(text)) if text[m - 1] == " " and text[m] != " "}
    for _, a, _ in tokenize(text):
        if a > 0:
            out.add(a)
    return sorted(out)


def split_text(text: str, weights: list[float]) -> list[str]:
    """ตัดข้อความเป็น len(weights) ชิ้นตามสัดส่วน โดยตัดที่ขอบวลี/คำเท่านั้น
    ข้อความสั้นจนตัดไม่พอ → ได้ชิ้นน้อยกว่าที่ขอ (ไม่สร้างชิ้นว่าง)"""
    text = " ".join((text or "").split())
    k = len(weights)
    if k <= 1 or not text:
        return [text] if text else []
    cands = _boundaries(text)
    # ตำแหน่ง → จำนวนตัวอักษร(ไม่นับช่องว่าง)ก่อนหน้า
    nsc = [0] * (len(text) + 1)
    for i, ch in enumerate(text):
        nsc[i + 1] = nsc[i] + (ch != " ")
    total, wsum = nsc[-1], float(sum(weights)) or 1.0
    cuts: list[int] = []
    acc = 0.0
    for w in weights[:-1]:
        acc += w
        target = total * acc / wsum
        prev = cuts[-1] if cuts else 0
        options = [c for c in cands if c > prev]
        if not options:
            break
        best = min(options, key=lambda c: abs(nsc[c] - target))
        cuts.append(best)
    pieces, prev = [], 0
    for c in cuts + [len(text)]:
        piece = text[prev:c].strip()
        if piece:
            pieces.append(piece)
        prev = c
    return pieces


def _new_beat(text: str, queries: list[str], visual: str = "", like: dict | None = None) -> dict:
    b = {"text": text, "visual": visual, "queries": [q for q in queries if q], "start_word": None, "kind": "stock"}
    if like and like.get("kind") == "graphic" and like.get("graphic"):      # แบ่งบทใหม่ → ภาพอธิบายของช่วงนั้นยังอยู่
        b["kind"], b["graphic"] = "graphic", like["graphic"]
    elif like and like.get("kind") == "aiimage" and like.get("image_prompt"):
        b["kind"], b["image_prompt"], b["seed"] = "aiimage", like["image_prompt"], like.get("seed", 0)
    return b


def ensure_beats(s: Scene, fallback_query: str = "") -> bool:
    """ทำให้ beats สอดคล้องกับบทพากย์ปัจจุบัน (เรียกซ้ำได้ ไม่เปลี่ยนอะไรถ้าตรงอยู่แล้ว) คืน True ถ้ามีการเปลี่ยน"""
    before = [dict(b) for b in s.beats]
    if not s.beats:
        kws = [k for k in s.keywords if k] or ([fallback_query] if fallback_query else [])
        n = max(1, len(kws))
        texts = split_text(s.narration, [1.0] * n)
        s.beats = [_new_beat(t, [kws[i]] if i < len(kws) else []) for i, t in enumerate(texts)] or \
            [_new_beat(s.narration, kws[:1])]
    elif _ns("".join(b.get("text", "") for b in s.beats)) != _ns(s.narration):
        # บทถูกแก้ → แบ่งใหม่ตามสัดส่วนเดิม เก็บคำค้น/ภาพของแต่ละ beat ไว้ตามลำดับ
        weights = [max(1, len(_ns(b.get("text", "")))) for b in s.beats]
        texts = split_text(s.narration, weights)
        olds = s.beats[: len(texts)] or s.beats[:1]
        s.beats = [_new_beat(t, list(o.get("queries") or []), o.get("visual", ""), o) for t, o in zip(texts, olds)] or \
            [_new_beat(s.narration, list(s.beats[0].get("queries") or []), s.beats[0].get("visual", ""), s.beats[0])]
    for b in s.beats:                    # ซ่อมข้อมูลเก่า/ข้อมูลจาก AI ที่ไม่ครบ
        b.setdefault("visual", "")
        b.setdefault("start_word", None)
        b.setdefault("kind", "stock")
        if (b["kind"] == "graphic" and not b.get("graphic")) or (b["kind"] == "aiimage" and not b.get("image_prompt")):
            b["kind"] = "stock"
        b["queries"] = [" ".join(str(q).split()) for q in (b.get("queries") or []) if str(q).strip()][:4]
        if not b["queries"] and fallback_query:
            b["queries"] = [fallback_query]
    s.keywords = [b["queries"][0] for b in s.beats if b["queries"]]
    return before != s.beats


def rebuild_from_keywords(s: Scene, keywords: list[str]) -> None:
    """ผู้ใช้พิมพ์คำค้นใหม่ (1 คำ = 1 ช่วงภาพ) → คำค้นใหม่แทนที่ของเดิม; จำนวนเปลี่ยน = แบ่งบทใหม่"""
    keywords = [" ".join(k.split()) for k in keywords if k and k.strip()]
    if not keywords:
        return
    if s.beats and len(s.beats) == len(keywords):
        for b, k in zip(s.beats, keywords):
            if (b.get("queries") or [""])[0] != k or b.get("kind") == "graphic":
                b["queries"], b["visual"], b["kind"] = [k], "", "stock"
    else:
        texts = split_text(s.narration, [1.0] * len(keywords))
        s.beats = [_new_beat(t, [keywords[i]]) for i, t in enumerate(texts)]
    s.keywords = [b["queries"][0] for b in s.beats if b["queries"]]


# ------------------------------------------------------------------ เวลา
def _word_char_starts(words: list[Word]) -> list[int]:
    out, acc = [], 0
    for w in words:
        out.append(acc)
        acc += len(_ns(w.text))
    return out


def beat_word_starts(s: Scene) -> list[int]:
    """ดัชนีคำที่ beat แต่ละตัวเริ่ม (beat แรก = 0) — ผู้ใช้กำหนดเองได้ด้วย start_word"""
    if not s.words or not s.beats:
        return [0] * len(s.beats)
    wc = _word_char_starts(s.words)
    total_w = wc[-1] + len(_ns(s.words[-1].text))
    total_b = sum(len(_ns(b.get("text", ""))) for b in s.beats) or 1
    scale = total_w / total_b
    out, acc = [], 0
    for i, b in enumerate(s.beats):
        if i == 0:
            out.append(0)
        else:
            target = acc * scale
            idx = min(range(len(wc)), key=lambda j: (abs(wc[j] - target), j))
            sw = b.get("start_word")
            if isinstance(sw, int) and 0 < sw < len(s.words):
                idx = sw
            out.append(max(idx, out[-1]))        # ห้ามย้อนหลัง beat ก่อนหน้า
        acc += len(_ns(b.get("text", "")))
    return out


def beat_of_word(s: Scene, w: int) -> int:
    starts = beat_word_starts(s)
    k = 0
    for i, st in enumerate(starts):
        if st <= w:
            k = i
    return k


def split_beat_at_word(s: Scene, w: int) -> int | None:
    """เพิ่มจุดตัดภาพที่คำที่ w → beat ที่ครอบคำนั้นถูกแบ่งเป็น 2 (ช่วงหลังใช้คำค้นเดิมไปก่อน)
    คืนดัชนี beat ใหม่ หรือ None ถ้าตัดไม่ได้"""
    if not s.words or not (0 < w < len(s.words)):
        return None
    starts = beat_word_starts(s)
    k = beat_of_word(s, w)
    if starts[k] == w:
        return None
    end_w = starts[k + 1] if k + 1 < len(starts) else len(s.words)
    b = s.beats[k]
    ratio = (w - starts[k]) / max(1, end_w - starts[k])
    parts = split_text(b["text"], [ratio, 1 - ratio]) if 0 < ratio < 1 else []
    if len(parts) != 2:
        # ข้อความสั้นมาก → ตัดตามคำจริงของเสียง
        first = "".join(x.text for x in s.words[starts[k]:w])
        if not first or not _ns(b["text"]).startswith(_ns(first)):
            return None
        n = len(_ns(first))
        cut, cnt = 0, 0
        while cut < len(b["text"]) and cnt < n:
            cnt += b["text"][cut] != " "
            cut += 1
        parts = [b["text"][:cut].strip(), b["text"][cut:].strip()]
        if not all(parts):
            return None
    b["text"] = parts[0]
    nb = _new_beat(parts[1], list(b.get("queries") or []), b.get("visual", ""))
    nb["start_word"] = w
    s.beats.insert(k + 1, nb)
    s.keywords = [x["queries"][0] for x in s.beats if x["queries"]]
    return k + 1


def merge_beat(s: Scene, k: int) -> bool:
    """ลบจุดตัดหน้า beat k (รวมเข้ากับ beat ก่อนหน้า ใช้ภาพของตัวก่อนหน้า)"""
    if not (0 < k < len(s.beats)):
        return False
    prev, cur = s.beats[k - 1], s.beats.pop(k)
    prev["text"] = (prev["text"] + " " + cur["text"]).strip()
    s.keywords = [x["queries"][0] for x in s.beats if x["queries"]]
    return True


def set_cut_word(s: Scene, k: int, w: int) -> bool:
    """เลื่อนจุดตัดเข้า beat k ไปที่คำที่ w (อยู่ระหว่าง beat ก่อน/หลังเท่านั้น)"""
    if not (0 < k < len(s.beats)) or not s.words:
        return False
    starts = beat_word_starts(s)
    lo = starts[k - 1] + 1
    hi = (starts[k + 1] - 1) if k + 1 < len(starts) else len(s.words) - 1
    if not (lo <= w <= hi):
        return False
    s.beats[k]["start_word"] = int(w)
    # ย้ายข้อความระหว่าง 2 beat ให้ตรงกับคำที่ได้ยินจริง (AI Editor/หน้าจอจะได้เห็นข้อความถูกช่วง)
    end = starts[k + 1] if k + 1 < len(starts) else len(s.words)
    ratio = (w - starts[k - 1]) / max(1, end - starts[k - 1])
    parts = split_text(s.beats[k - 1]["text"] + " " + s.beats[k]["text"], [ratio, 1 - ratio])
    if len(parts) == 2:
        s.beats[k - 1]["text"], s.beats[k]["text"] = parts
    return True
