"""ทักษะซับไตเติล: จัดกลุ่มคำตามจังหวะพูด → ไฟล์ ASS (ไฮไลต์คำตามเสียง) และ SRT สำหรับอัปโหลด"""
from __future__ import annotations

import re
from dataclasses import dataclass

from ..core.models import Word
from ..core.text import has_thai
from .timing import Timeline


@dataclass
class Chunk:
    words: list[Word]
    start: float
    end: float

    @property
    def text(self) -> str:
        return join_tokens([w.text for w in self.words])


_SENT_END = re.compile(r"[.!?…。]$")


def join_tokens(tokens: list[str]) -> str:
    """ไทยที่ตัดคำด้วย pythainlp ไม่ควรมีช่องว่างคั่นกลางคำ; วลีไทยที่คั่นด้วยช่องว่างให้คงช่องว่างไว้"""
    from ..core import text as t
    thai_words_mode = t._thai_tokenizer() is not None
    out = ""
    for tok in tokens:
        if not out:
            out = tok
        elif has_thai(tok) and thai_words_mode:
            out += tok
        else:
            out += " " + tok
    return out


def chunk_words(words: list[Word], max_chars: int) -> list[Chunk]:
    chunks: list[Chunk] = []
    cur: list[Word] = []
    for w in words:
        trial = join_tokens([x.text for x in cur] + [w.text])
        if cur and len(trial.replace(" ", "")) > max_chars:
            chunks.append(Chunk(cur, cur[0].start, cur[-1].end))
            cur = []
        cur.append(w)
        if _SENT_END.search(w.text):
            chunks.append(Chunk(cur, cur[0].start, cur[-1].end))
            cur = []
    if cur:
        chunks.append(Chunk(cur, cur[0].start, cur[-1].end))
    return chunks


def timeline_chunks(tl: Timeline, max_chars: int) -> list[Chunk]:
    """ทุกฉาก → chunk ที่เป็นเวลาบน timeline รวม (บวก offset ของฉาก) และปิดช่องว่างเล็กๆ กันซับกะพริบ"""
    out: list[Chunk] = []
    for item in tl.items:
        for c in chunk_words(item.scene.words, max_chars):
            ws = [Word(w.text, w.start + item.a_start, w.end + item.a_start) for w in c.words]
            out.append(Chunk(ws, ws[0].start, max(ws[-1].end, ws[0].start + 0.35)))
    for a, b in zip(out, out[1:]):
        if b.start - a.end < 0.30:             # ช่องว่างสั้น → ต่อเนื่อง ไม่ให้ซับดับแว้บ
            a.end = b.start
        a.end = min(a.end, b.start)
    return out


# ------------------------------ ASS ------------------------------
def _ass_color(hex_rgb: str, alpha: int = 0) -> str:
    h = hex_rgb.lstrip("#")
    if len(h) != 6:
        h = "FFFFFF"
    r, g, b = h[0:2], h[2:4], h[4:6]
    return f"&H{alpha:02X}{b}{g}{r}".upper()


def _ass_time(t: float) -> str:
    t = max(0.0, t)
    cs = int(round(t * 100))
    h, rem = divmod(cs, 360000)
    m, rem = divmod(rem, 6000)
    s, c = divmod(rem, 100)
    return f"{h}:{m:02d}:{s:02d}.{c:02d}"


def _esc(text: str) -> str:
    return text.replace("\\", "").replace("{", "(").replace("}", ")").replace("\n", " ")


def build_ass(tl: Timeline, cfg, width: int, height: int) -> str:
    size = int(cfg["captions.size"])
    base, hi = cfg["captions.color"], cfg["captions.highlight"]
    karaoke = bool(cfg["captions.karaoke"])
    # ใน ASS: Primary = สีของ "ส่วนที่พูดไปแล้ว", Secondary = สีของ "ส่วนที่ยังไม่พูด" (เมื่อใช้ \k)
    primary, secondary = (_ass_color(hi), _ass_color(base)) if karaoke else (_ass_color(base), _ass_color(base))
    scale = height / 1920.0
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {width}
PlayResY: {height}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,{cfg['captions.font']},{round(size * scale)},{primary},{secondary},&H00000000,&H96000000,-1,0,0,0,100,100,0,0,1,{round(int(cfg['captions.outline']) * scale)},{round(2 * scale)},2,{round(70 * scale)},{round(70 * scale)},{round(int(cfg['captions.margin_v']) * scale)},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    lines = []
    for c in timeline_chunks(tl, int(cfg["captions.chunk_chars"])):
        pop = r"{\fscx82\fscy82\t(0,120,\fscx100\fscy100)}" if cfg["captions.pop"] else ""
        if karaoke:
            parts = []
            for i, w in enumerate(c.words):
                nxt = c.words[i + 1].start if i + 1 < len(c.words) else c.end
                cs = max(1, int(round((nxt - w.start) * 100)))
                parts.append(f"{{\\k{cs}}}{_esc(w.text)}")
            sep = "" if (has_thai(c.text) and _no_space_mode()) else " "
            body = sep.join(parts)
        else:
            body = _esc(c.text)
        lines.append(f"Dialogue: 0,{_ass_time(c.start)},{_ass_time(c.end)},Cap,,0,0,0,,{pop}{body}")
    return header + "\n".join(lines) + "\n"


def _no_space_mode() -> bool:
    from ..core import text as t
    return t._thai_tokenizer() is not None


# ------------------------------ SRT ------------------------------
def _srt_time(t: float) -> str:
    ms = int(round(max(0.0, t) * 1000))
    h, rem = divmod(ms, 3_600_000)
    m, rem = divmod(rem, 60_000)
    s, ms = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def build_srt(tl: Timeline, cfg) -> str:
    out = []
    for i, c in enumerate(timeline_chunks(tl, int(cfg["captions.chunk_chars"])), 1):
        out.append(f"{i}\n{_srt_time(c.start)} --> {_srt_time(c.end)}\n{c.text}\n")
    return "\n".join(out)
