"""ทักษะ AI Editor — แปลง "คำสั่งภาษาคน" เป็นรายการ "ปฏิบัติการแก้ไข" ที่ตรวจสอบได้ แล้วค่อยลงมือ

หลักการ: AI ไม่เคยแตะไฟล์หรือโปรเจกต์โดยตรง
  1) AI เห็นสถานะโปรเจกต์ + จุดที่ผู้ใช้กำลังดูอยู่ (focus) → ตอบเป็น JSON ของ ops
  2) ระบบตรวจ ops ทีละตัวกับรายการที่อนุญาต (ตัวที่ผิดถูกปฏิเสธพร้อมเหตุผล ไม่ทำให้ทั้งชุดพัง)
  3) ผู้ใช้เห็นสรุปเป็นภาษาไทยก่อนกดยืนยัน → ระบบเก็บ snapshot ไว้ (undo ได้) แล้วค่อย apply
ปุ่มแก้ด้วยมือใน UI ก็เรียก apply_ops ตัวเดียวกัน จึงมีทางแก้เพียงทางเดียว = พังยาก
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from ..core.errors import EditError
from ..core.models import Project
from ..core.settings import coerce, field_of
from ..providers.base import LLMProvider
from . import beats as beatlib
from . import graphics as gx
from . import prompts
from .timing import count_chars

MAX_OPS = 20

# คีย์ตั้งค่าที่ AI/ผู้ใช้สั่งเปลี่ยนเฉพาะโปรเจกต์นี้ได้ → สเต็ปแรกที่ต้องทำใหม่
SETTING_IMPACT: dict[str, str] = {
    "tts.speed": "voice", "elevenlabs.stability": "voice", "elevenlabs.similarity": "voice",
    "max_shot_seconds": "visuals", "scene_pause": "visuals", "stock.judge": "visuals",
    "music.volume_db": "render", "music.duck_db": "render", "music.fade_in": "render",
    "music.fade_out": "render", "render.target_lufs": "render",
    "captions.enabled": "captions", "captions.size": "captions", "captions.color": "captions",
    "captions.highlight": "captions", "captions.margin_v": "captions", "captions.chunk_chars": "captions",
    "captions.karaoke": "captions", "captions.pop": "captions", "captions.outline": "captions",
    "captions.font": "captions",
}
ROLES = {"hook", "body", "cta"}


# ============================== โครงสร้างผลลัพธ์ ==============================
@dataclass
class EditPlan:
    instruction: str
    explanation: str = ""
    clarify: str = ""
    ops: list[dict] = field(default_factory=list)
    rejected: list[str] = field(default_factory=list)

    def describe(self, project: Project) -> list[str]:
        return [describe_op(project, op) for op in self.ops]


@dataclass
class ApplyResult:
    changed_steps: list[str] = field(default_factory=list)
    messages: list[str] = field(default_factory=list)
    regenerate_script: bool = False


# ============================== สถานะที่ส่งให้ AI ==============================
def state_for_llm(project: Project, cfg) -> dict:
    scenes = []
    for i, s in enumerate(project.scenes, 1):
        scenes.append({
            "n": i, "role": s.role, "narration": s.narration, "chars": count_chars(s.narration),
            "seconds": round(s.audio_duration, 1) if s.audio_duration else None,
            "note": s.note,
            "beats": [{"beat": k, "says": b.get("text", ""), "kind": b.get("kind", "stock"),
                       **({"graphic": {"template": b["graphic"]["template"], **b["graphic"]["data"]}}
                          if b.get("kind") == "graphic" and b.get("graphic") else
                          {"image_prompt": b.get("image_prompt", "")} if b.get("kind") == "aiimage" else
                          {"visual": b.get("visual", ""), "queries": b.get("queries", [])})}
                      for k, b in enumerate(s.beats, 1)] or None,
            "keywords": None if s.beats else s.keywords,
            "shots": [{"shot": j, "beat": sh.beat + 1, "query": sh.keyword,
                       "clip_title": (sh.clip or {}).get("title", ""), "ai_match_score": sh.score,
                       "pinned": sh.pinned, "seconds": round(sh.duration, 1)} for j, sh in enumerate(s.shots, 1)],
        })
    return {
        "title": project.title, "topic": project.topic, "language": project.language,
        "target_seconds": cfg["target_seconds"],
        "chars_per_second_measured": round(project.measured_cps, 1) if project.measured_cps else None,
        "scenes": scenes,
        "music_prompt": project.music.prompt,
        "settings": {k: cfg.get(k) for k in SETTING_IMPACT},
    }


# ============================== วางแผน (เรียก AI) ==============================
def plan_edit(llm: LLMProvider, project: Project, cfg, instruction: str, focus: dict | None = None) -> EditPlan:
    instruction = (instruction or "").strip()
    if not instruction:
        raise EditError("ยังไม่ได้พิมพ์คำสั่ง")
    if not project.scenes:
        raise EditError("ยังไม่มีบท — สร้างบทก่อน แล้วค่อยสั่งแก้")
    images_on = str(cfg.get("image.provider", "none")) not in ("", "none")
    prompt = prompts.render(
        "edit", graphic_catalog=gx.catalog(project.language), images_on="yes" if images_on else "no (do not use set_aiimage)",
        state_json=json.dumps(state_for_llm(project, cfg), ensure_ascii=False, indent=1),
        focus_json=json.dumps(focus or {}, ensure_ascii=False), instruction=instruction,
        setting_keys=", ".join(SETTING_IMPACT),
    )
    data = llm.generate_json(prompts.SYSTEM, prompt)
    if not isinstance(data, dict):
        raise EditError("AI ตอบกลับในรูปแบบที่อ่านไม่ได้ ลองสั่งใหม่อีกครั้ง")
    ops, rejected = validate_ops(data.get("ops") or [], project)
    return EditPlan(instruction, str(data.get("explanation", "")).strip(), str(data.get("clarify", "") or "").strip(),
                    ops, rejected)


# ============================== ตรวจสอบ ops ==============================
def _num(v: Any, lo: float, hi: float) -> float:
    x = float(v)
    if not (lo <= x <= hi):
        raise ValueError(f"ค่า {x} อยู่นอกช่วง {lo}–{hi}")
    return x


def validate_ops(raw_ops: list, project: Project) -> tuple[list[dict], list[str]]:
    """รับ ops จาก AI/ UI → คืน (ops ที่ใช้ได้ พร้อม scene_id), (เหตุผลที่ตัวไหนถูกปฏิเสธ)"""
    num2id = {i + 1: s.id for i, s in enumerate(project.scenes)}
    ids = set(num2id.values())
    ops: list[dict] = []
    rejected: list[str] = []

    def sid(op: dict, key: str = "scene") -> int:
        if op.get(key + "_id") is not None:
            v = int(op[key + "_id"])
            if v not in ids:
                raise ValueError(f"ไม่มีฉาก id {v}")
            return v
        n = int(op[key])
        if n not in num2id:
            raise ValueError(f"ไม่มีฉากที่ {n} (มี 1–{len(num2id)})")
        return num2id[n]

    def after_id(op: dict) -> int:       # 0 = ไว้หน้าสุด
        if op.get("after_id") is not None:
            return int(op["after_id"])
        n = int(op.get("after", 0))
        if n == 0:
            return 0
        if n not in num2id:
            raise ValueError(f"ไม่มีฉากที่ {n}")
        return num2id[n]

    def text(op: dict, key: str = "text", limit: int = 700) -> str:
        t = " ".join(str(op.get(key, "")).split())
        if not t:
            raise ValueError("ข้อความว่าง")
        return t[:limit]

    def kws(v: Any) -> list[str]:
        out = [" ".join(str(k).split()) for k in (v if isinstance(v, list) else [v]) if str(k).strip()]
        if not out:
            raise ValueError("ไม่มี keyword")
        return out[:6]

    for raw in raw_ops[:MAX_OPS]:
        if not isinstance(raw, dict):
            rejected.append(f"ข้ามรายการที่ไม่ใช่คำสั่ง: {raw!r}")
            continue
        name = raw.get("op")
        try:
            if name == "set_narration":
                op = {"op": name, "scene_id": sid(raw), "text": text(raw)}
            elif name == "set_keywords":
                op = {"op": name, "scene_id": sid(raw), "keywords": kws(raw.get("keywords"))}
            elif name == "swap_visual":
                shot = raw.get("shot")        # เก็บเป็นเลข 1-based ตลอด (validate ซ้ำกี่รอบก็ไม่เพี้ยน)
                if shot in (None, ""):
                    shot = None
                else:
                    shot = int(shot)
                    if shot < 1:
                        raise ValueError("เลขช็อตเริ่มที่ 1")
                op = {"op": name, "scene_id": sid(raw), "shot": shot}
            elif name == "set_visual":
                s_id = sid(raw)
                sc = project.scene(s_id)
                if raw.get("shot") not in (None, ""):
                    j = int(raw["shot"])
                    if not (1 <= j <= len(sc.shots)):
                        raise ValueError(f"ฉากนี้มี {len(sc.shots)} ช็อต")
                    beat = sc.shots[j - 1].beat + 1
                elif raw.get("beat") not in (None, ""):
                    beat = int(raw["beat"])
                else:
                    beat = 1 if len(sc.beats) <= 1 else None
                if beat is None or not (1 <= beat <= max(1, len(sc.beats))):
                    raise ValueError("ต้องระบุช็อตหรือช่วง (beat) ที่จะเปลี่ยนภาพ")
                qs = kws(raw.get("queries") or raw.get("keywords") or raw.get("query")) \
                    if (raw.get("queries") or raw.get("keywords") or raw.get("query")) else []
                vis = " ".join(str(raw.get("visual", "")).split())[:300]
                if not qs and not vis:
                    raise ValueError("ต้องมีคำค้นหรือคำบรรยายภาพใหม่")
                op = {"op": name, "scene_id": s_id, "beat": beat, "queries": qs[:4], "visual": vis}
            elif name == "set_graphic":
                s_id = sid(raw)
                sc = project.scene(s_id)
                if raw.get("shot") not in (None, ""):
                    j = int(raw["shot"])
                    if not (1 <= j <= len(sc.shots)):
                        raise ValueError(f"ฉากนี้มี {len(sc.shots)} ช็อต")
                    beat = sc.shots[j - 1].beat + 1
                else:
                    beat = int(raw.get("beat") or 1)
                if not (1 <= beat <= max(1, len(sc.beats))):
                    raise ValueError("ไม่มีช่วงนี้ในฉาก")
                tpl = str(raw.get("template") or "")
                fields = raw.get("fields") if isinstance(raw.get("fields"), dict) else \
                    {k: v for k, v in raw.items() if k not in ("op", "scene", "scene_id", "shot", "beat", "template")}
                data = gx.normalize(tpl, fields)
                if data is None:
                    raise ValueError(f"ข้อมูลภาพอธิบายไม่ครบสำหรับแบบ '{tpl}'")
                op = {"op": name, "scene_id": s_id, "beat": beat, "template": tpl, "fields": data}
            elif name == "set_aiimage":
                s_id = sid(raw)
                sc = project.scene(s_id)
                if raw.get("shot") not in (None, ""):
                    j = int(raw["shot"])
                    if not (1 <= j <= len(sc.shots)):
                        raise ValueError(f"ฉากนี้มี {len(sc.shots)} ช็อต")
                    beat = sc.shots[j - 1].beat + 1
                else:
                    beat = int(raw.get("beat") or 1)
                if not (1 <= beat <= max(1, len(sc.beats))):
                    raise ValueError("ไม่มีช่วงนี้ในฉาก")
                prompt = " ".join(str(raw.get("prompt") or raw.get("image_prompt") or "").split())[:600]
                reroll = bool(raw.get("reroll"))
                if not prompt and not reroll:
                    raise ValueError("ต้องมีคำบรรยายภาพ (อังกฤษ)")
                op = {"op": name, "scene_id": s_id, "beat": beat, "prompt": prompt, "reroll": reroll}
            elif name == "set_shot_start":
                s_id = sid(raw)
                j = int(raw["shot"])
                if not (1 <= j <= len(project.scene(s_id).shots)):
                    raise ValueError("ไม่มีช็อตนี้")
                op = {"op": name, "scene_id": s_id, "shot": j, "seconds": _num(raw.get("seconds"), 0, 600)}
            elif name in ("set_cut", "merge_beat"):
                s_id = sid(raw)
                k = int(raw["beat"])
                if not (2 <= k <= len(project.scene(s_id).beats)):
                    raise ValueError("ช่วงแรกของฉากย้าย/ลบจุดตัดไม่ได้")
                op = {"op": name, "scene_id": s_id, "beat": k}
                if name == "set_cut":
                    op["word"] = int(raw["word"])
            elif name == "split_beat":
                op = {"op": name, "scene_id": sid(raw), "word": int(raw["word"])}
            elif name == "set_note":
                op = {"op": name, "scene_id": sid(raw), "text": text(raw, limit=300)}
            elif name == "add_scene":
                role = raw.get("role") if raw.get("role") in ROLES else "body"
                op = {"op": name, "after_id": after_id(raw), "role": role, "narration": text(raw, "narration"),
                      "keywords": kws(raw.get("keywords") or [project.topic or "abstract background"])}
            elif name == "delete_scene":
                if len(project.scenes) <= 1:
                    raise ValueError("ลบไม่ได้ ต้องเหลืออย่างน้อย 1 ฉาก")
                op = {"op": name, "scene_id": sid(raw)}
            elif name == "move_scene":
                s_id, a_id = sid(raw), after_id(raw)
                if s_id == a_id:
                    raise ValueError("ย้ายไปหลังตัวเองไม่ได้")
                op = {"op": name, "scene_id": s_id, "after_id": a_id}
            elif name == "set_pause":
                op = {"op": name, "scene_id": sid(raw), "seconds": _num(raw.get("seconds"), 0, 3)}
            elif name == "set_music_prompt":
                op = {"op": name, "text": text(raw, limit=500)}
            elif name == "set_music_volume":
                op = {"op": name, "db": max(-40.0, min(-5.0, float(raw.get("db"))))}
            elif name == "set_setting":
                key = raw.get("key")
                if key not in SETTING_IMPACT:
                    raise ValueError(f"ไม่อนุญาตให้เปลี่ยนค่า '{key}' ด้วยคำสั่ง")
                op = {"op": name, "key": key, "value": coerce(field_of(key), raw.get("value"))}
            elif name == "regenerate_script":
                op = {"op": name, "instruction": " ".join(str(raw.get("instruction", "")).split())[:500]}
            elif name == "fit_duration":
                op = {"op": name, "seconds": _num(raw.get("seconds"), 10, 180)}
            else:
                raise ValueError(f"ไม่รู้จักคำสั่ง '{name}'")
        except (ValueError, TypeError, KeyError) as e:
            rejected.append(f"ข้าม {name or '?'}: {e}")
            continue
        ops.append(op)
    if len(raw_ops) > MAX_OPS:
        rejected.append(f"คำสั่งเยอะเกิน — ทำ {MAX_OPS} รายการแรก")
    return ops, rejected


# ============================== อธิบายเป็นภาษาไทย ==============================
def describe_op(project: Project, op: dict) -> str:
    def n(sid: int) -> str:
        try:
            return f"ฉาก {project.index_of(sid) + 1}"
        except KeyError:
            return f"ฉาก #{sid}"

    def clip(t: str, k: int = 60) -> str:
        return t if len(t) <= k else t[:k] + "…"

    o = op["op"]
    if o == "set_narration":
        return f"{n(op['scene_id'])}: เปลี่ยนบทพากย์เป็น «{clip(op['text'])}»"
    if o == "set_keywords":
        return f"{n(op['scene_id'])}: เปลี่ยนคำค้นภาพเป็น {', '.join(op['keywords'])}"
    if o == "swap_visual":
        which = "ทุกช็อต" if op.get("shot") is None else f"ช็อต {op['shot']}"
        return f"{n(op['scene_id'])}: เปลี่ยนคลิปภาพ ({which})"
    if o == "set_visual":
        what = f"«{clip(op['visual'], 70)}»" if op.get("visual") else ", ".join(op["queries"])
        return f"{n(op['scene_id'])} ช่วงที่ {op['beat']}: เปลี่ยนภาพเป็น {what}"
    if o == "set_graphic":
        first = next(iter(op["fields"].values()), "")
        return (f"{n(op['scene_id'])} ช่วงที่ {op['beat']}: ทำเป็นภาพอธิบาย “{gx.get(op['template']).label}” "
                f"«{clip(str(first), 40)}»")
    if o == "set_aiimage":
        what = f"«{clip(op['prompt'], 60)}»" if op["prompt"] else "แบบเดิม"
        return f"{n(op['scene_id'])} ช่วงที่ {op['beat']}: สร้างภาพ AI {what}" + (" (สุ่มใหม่)" if op["reroll"] else "")
    if o == "set_shot_start":
        return f"{n(op['scene_id'])} ช็อต {op['shot']}: ใช้คลิปตั้งแต่วินาทีที่ {op['seconds']:.1f}"
    if o == "set_cut":
        return f"{n(op['scene_id'])}: เลื่อนจุดตัดภาพช่วงที่ {op['beat']} ไปที่คำที่ {op['word'] + 1}"
    if o == "split_beat":
        return f"{n(op['scene_id'])}: เพิ่มจุดตัดภาพที่คำที่ {op['word'] + 1}"
    if o == "merge_beat":
        return f"{n(op['scene_id'])}: ลบจุดตัดหน้าช่วงที่ {op['beat']} (ใช้ภาพต่อเนื่อง)"
    if o == "set_note":
        return f"{n(op['scene_id'])}: บันทึกทิศทางภาพ «{clip(op['text'])}»"
    if o == "add_scene":
        pos = "ต้นเรื่อง" if not op["after_id"] else f"หลัง{n(op['after_id'])}"
        return f"เพิ่มฉากใหม่ที่{pos}: «{clip(op['narration'])}»"
    if o == "delete_scene":
        return f"ลบ{n(op['scene_id'])}"
    if o == "move_scene":
        pos = "ต้นเรื่อง" if not op["after_id"] else f"หลัง{n(op['after_id'])}"
        return f"ย้าย{n(op['scene_id'])}ไปไว้{pos}"
    if o == "set_pause":
        return f"{n(op['scene_id'])}: เว้นจังหวะหลังจบ {op['seconds']:.2f} วินาที"
    if o == "set_music_prompt":
        return f"สร้างเพลงใหม่: «{clip(op['text'], 80)}»"
    if o == "set_music_volume":
        return f"ปรับเสียงเพลงพื้นหลังเป็น {op['db']:.0f} dB"
    if o == "set_setting":
        try:
            label = field_of(op["key"]).label
        except KeyError:
            label = op["key"]
        return f"ตั้ง «{label}» = {op['value']}"
    if o == "regenerate_script":
        return "เขียนบททั้งเรื่องใหม่" + (f" ({clip(op['instruction'], 80)})" if op["instruction"] else "")
    if o == "fit_duration":
        return f"ปรับบทให้ยาวรวมประมาณ {op['seconds']:.0f} วินาที"
    return o


# ============================== ลงมือแก้ ==============================
def apply_ops(project: Project, ops: list[dict]) -> ApplyResult:
    """แก้โปรเจกต์ตาม ops ที่ผ่าน validate_ops แล้ว และทำเครื่องหมายสเต็ปที่ต้องทำใหม่
    ไม่เรียก AI/เน็ต ไม่แตะไฟล์ — เรียกได้เร็วและทดสอบง่าย"""
    res = ApplyResult()
    touched: set[str] = set()

    def mark(step: str) -> None:
        touched.add(step)

    for op in ops:
        o = op["op"]
        if o == "set_narration":
            s = project.scene(op["scene_id"])
            s.narration = op["text"]
            beatlib.ensure_beats(s, project.topic)
            mark("voice")
        elif o == "set_keywords":
            s = project.scene(op["scene_id"])
            beatlib.rebuild_from_keywords(s, list(op["keywords"]))
            for sh in s.shots:
                sh.pinned = False
            s.fp.pop("visual", None)
            mark("visuals")
        elif o == "set_visual":
            s = project.scene(op["scene_id"])
            beatlib.ensure_beats(s, project.topic)
            k = min(op["beat"], len(s.beats)) - 1
            b = s.beats[k]
            b["kind"] = "stock"                       # กลับมาใช้วิดีโอ (ถ้าเดิมเป็นภาพอธิบาย)
            if op["queries"]:
                b["queries"] = list(op["queries"])
            if op["visual"]:
                b["visual"] = op["visual"]
                if not op["queries"]:                 # มีแต่คำบรรยาย → ใช้คำบรรยายแบบสั้นเป็นคำค้นแรก
                    b["queries"] = [" ".join(op["visual"].split()[:5])] + list(b.get("queries") or [])[:2]
            for sh in s.shots:                        # คลิปเดิมของช่วงนี้ = "ไม่ตรง" → ไม่เอาอีก
                if sh.beat == k and sh.clip:
                    key = f"{sh.clip.get('provider')}:{sh.clip.get('id')}"
                    if key not in s.avoid:
                        s.avoid.append(key)
                    sh.pinned, sh.clip, sh.path = False, None, ""
            s.keywords = [x["queries"][0] for x in s.beats if x.get("queries")]
            s.fp.pop("visual", None)
            mark("visuals")
        elif o == "set_graphic":
            s = project.scene(op["scene_id"])
            beatlib.ensure_beats(s, project.topic)
            k = min(op["beat"], len(s.beats)) - 1
            s.beats[k]["kind"] = "graphic"
            s.beats[k]["graphic"] = {"template": op["template"], "data": dict(op["fields"])}
            for sh in s.shots:
                if sh.beat == k:
                    sh.pinned, sh.clip, sh.path = False, None, ""
            s.fp.pop("visual", None)
            mark("visuals")
        elif o == "set_aiimage":
            s = project.scene(op["scene_id"])
            beatlib.ensure_beats(s, project.topic)
            b = s.beats[min(op["beat"], len(s.beats)) - 1]
            if op["prompt"]:
                b["image_prompt"] = op["prompt"]
            if not b.get("image_prompt"):
                b["image_prompt"] = b.get("visual") or (b.get("queries") or [project.topic])[0]
            if op["reroll"]:
                b["seed"] = int(b.get("seed", 0)) + 1
            b["kind"] = "aiimage"
            s.fp.pop("visual", None)
            mark("visuals")
        elif o == "set_shot_start":
            s = project.scene(op["scene_id"])
            sh = s.shots[op["shot"] - 1]
            longest = float((sh.clip or {}).get("duration") or 0) - sh.duration
            sh.start = round(max(0.0, min(op["seconds"], longest if longest > 0 else 0.0)), 2)
            sh.start_locked = True
            mark("render")
        elif o == "set_cut":
            s = project.scene(op["scene_id"])
            if not beatlib.set_cut_word(s, op["beat"] - 1, op["word"]):
                res.messages.append("ย้ายจุดตัดไปตรงนั้นไม่ได้ (ต้องอยู่ระหว่างจุดตัดก่อนหน้าและถัดไป)")
            else:
                mark("visuals")
        elif o == "split_beat":
            s = project.scene(op["scene_id"])
            if beatlib.split_beat_at_word(s, op["word"]) is None:
                res.messages.append("เพิ่มจุดตัดตรงนั้นไม่ได้ (เป็นจุดตัดอยู่แล้ว หรือยังไม่มีเสียงพากย์)")
            else:
                mark("visuals")
        elif o == "merge_beat":
            s = project.scene(op["scene_id"])
            if beatlib.merge_beat(s, op["beat"] - 1):
                mark("visuals")
        elif o == "swap_visual":
            s = project.scene(op["scene_id"])
            targets = range(len(s.shots)) if op.get("shot") is None else [op["shot"] - 1]
            for i in targets:
                if 0 <= i < len(s.shots):
                    sh = s.shots[i]
                    if sh.clip:
                        key = f"{sh.clip.get('provider')}:{sh.clip.get('id')}"
                        if key not in s.avoid:
                            s.avoid.append(key)
                    sh.pinned, sh.clip, sh.path = False, None, ""
            s.fp.pop("visual", None)
            mark("visuals")
        elif o == "set_note":
            project.scene(op["scene_id"]).note = op["text"]
        elif o == "add_scene":
            new = project.new_scene(role=op["role"], narration=op["narration"], keywords=list(op["keywords"]))
            beatlib.ensure_beats(new, project.topic)
            idx = 0 if not op["after_id"] else project.index_of(op["after_id"]) + 1
            project.scenes.insert(idx, new)
            _fix_roles(project)
            mark("voice")
        elif o == "delete_scene":
            project.scenes.pop(project.index_of(op["scene_id"]))
            _fix_roles(project)
            mark("voice")
        elif o == "move_scene":
            s = project.scenes.pop(project.index_of(op["scene_id"]))
            idx = 0 if not op["after_id"] else project.index_of(op["after_id"]) + 1
            project.scenes.insert(idx, s)
            _fix_roles(project)
            mark("voice")
        elif o == "set_pause":
            project.scene(op["scene_id"]).pause = op["seconds"]
            mark("visuals")
        elif o == "set_music_prompt":
            project.music.prompt = op["text"]
            project.music.fp = ""
            mark("music")
        elif o == "set_music_volume":
            project.overrides["music.volume_db"] = op["db"]
            mark("render")
        elif o == "set_setting":
            project.overrides[op["key"]] = op["value"]
            mark(SETTING_IMPACT[op["key"]])
        elif o == "regenerate_script":
            project.outputs["script_extra"] = op["instruction"]
            res.regenerate_script = True
            mark("script")
        elif o == "fit_duration":
            project.overrides["target_seconds"] = op["seconds"]
            project.outputs["fit_pending"] = True
            mark("voice")
        else:
            res.messages.append(f"ข้ามคำสั่งที่ไม่รู้จัก: {o}")
    for step in sorted(touched):
        res.changed_steps += [s for s in project.invalidate(step, "ถูกแก้ไข — ต้องทำใหม่") if s not in res.changed_steps]
    project.revision += 1
    return res


def _fix_roles(project: Project) -> None:
    """หลังเพิ่ม/ลบ/ย้ายฉาก: ฉากแรก = hook, ฉากสุดท้าย = cta (ถ้ามีมากกว่า 1), ที่เหลือ = body"""
    n = len(project.scenes)
    for i, s in enumerate(project.scenes):
        s.role = "hook" if i == 0 else "cta" if i == n - 1 else "body"
