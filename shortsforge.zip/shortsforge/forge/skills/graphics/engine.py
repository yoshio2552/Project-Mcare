"""เครื่องวาดภาพอธิบาย (motion graphics) — วาดด้วย ASS/libass ที่ ffmpeg มีอยู่แล้ว ไม่ต้องติดตั้งอะไรเพิ่ม

ทำไมใช้ ASS: libass จัดรูปตัวอักษรไทยถูกต้อง (สระ/วรรณยุกต์ไม่ลอย) เหมือนซับที่ใช้อยู่ และมีคำสั่งแอนิเมชัน
(ขยาย/เลื่อน/จาง/เปลี่ยนสี) + วาดรูปทรงเวกเตอร์ได้ → ได้กราฟิกคมทุกความละเอียด เรนเดอร์เร็ว ผลลัพธ์เหมือนเดิมทุกครั้ง

พิกัดออกแบบที่ 1080×1920 เสมอ (libass ย่อ/ขยายให้ตามขนาดวิดีโอจริง)
โซนกราฟิกอยู่ช่วงบน–กลางจอ เว้นด้านล่างไว้ให้ซับและปุ่มของแอป
"""
from __future__ import annotations

import base64
import hashlib
import re
from dataclasses import dataclass, field
from pathlib import Path

from ...core import ffmpeg
from ...core.errors import FFmpegError
from ...core.models import fingerprint
from ...core.text import tokenize

ENGINE_VERSION = 1
W, H = 1080, 1920
ZONE_TOP, ZONE_BOTTOM = 280, 1250
GLYPH_EM = 0.47            # ความกว้างเฉลี่ยต่อตัวอักษร (เท่าของขนาดฟอนต์ ASS) ใช้กะการตัดบรรทัด/ย่อฟอนต์ — เผื่อฟอนต์ไทยที่กว้างอย่าง Tahoma

PALETTES: dict[str, dict] = {
    "midnight": dict(bg0="#0B1220", bg1="#22314A", text="#F8FAFC", muted="#94A3B8", accent="#FACC15",
                     good="#22C55E", bad="#F43F5E", card="#FFFFFF", card_a=0.08, ink="#0B1220"),
    "ocean": dict(bg0="#06283D", bg1="#0E7490", text="#F0F9FF", muted="#A5F3FC", accent="#FDE047",
                  good="#4ADE80", bad="#FB7185", card="#FFFFFF", card_a=0.10, ink="#06283D"),
    "sunset": dict(bg0="#2E0A4F", bg1="#B4235F", text="#FFF7ED", muted="#FBCFE8", accent="#FDBA74",
                   good="#86EFAC", bad="#FCA5A5", card="#FFFFFF", card_a=0.10, ink="#2E0A4F"),
    "forest": dict(bg0="#052E16", bg1="#1F6F43", text="#F0FDF4", muted="#BBF7D0", accent="#FDE68A",
                   good="#4ADE80", bad="#FCA5A5", card="#FFFFFF", card_a=0.09, ink="#052E16"),
    "paper": dict(bg0="#FAFAF7", bg1="#E7E2D9", text="#1C1917", muted="#57534E", accent="#2563EB",
                  good="#15803D", bad="#DC2626", card="#000000", card_a=0.05, ink="#FAFAF7"),
}
PALETTE_LABELS = [("อัตโนมัติ (สลับตามโปรเจกต์)", "auto"), ("กลางคืน น้ำเงินเข้ม + เหลือง", "midnight"),
                  ("มหาสมุทร ฟ้าอมเขียว", "ocean"), ("พระอาทิตย์ตก ม่วงชมพู", "sunset"),
                  ("ป่า เขียวเข้ม", "forest"), ("กระดาษ สว่าง อ่านง่าย", "paper")]


def palette_for(name: str, seed: str = "") -> dict:
    if name in PALETTES:
        return PALETTES[name]
    keys = sorted(PALETTES)
    return PALETTES[keys[int(hashlib.md5(seed.encode()).hexdigest(), 16) % len(keys)]]


# ------------------------------------------------------------------ ตัวอักษรไทย
_COMBINING = re.compile(r"[ัิ-ฺ็-๎]")
_NO_BREAK_BEFORE = set("ะาำๅๆฯ") | {c for c in map(chr, range(0x0E31, 0x0E4F)) if _COMBINING.match(c)}
_LEADING = set("เแโใไ")        # เ แ โ ใ ไ — ต้องอยู่กับพยัญชนะตัวถัดไป


def units(s: str) -> int:
    """ความยาวที่ "มองเห็น" — สระบน/ล่างและวรรณยุกต์ไม่กินที่ในแนวนอน"""
    return len(_COMBINING.sub("", s))


def _hard_split(tok: str, max_u: int) -> list[str]:
    """ตัดคำที่ยาวเกินบรรทัด: ห้ามแยกสระ/วรรณยุกต์ออกจากพยัญชนะ ห้ามตัดหลังสระหน้า (เ แ โ ใ ไ)"""
    out, cur = [], ""
    for i, ch in enumerate(tok):
        if cur and units(cur) >= max_u and ch not in _NO_BREAK_BEFORE and cur[-1] not in _LEADING:
            # ถอยไปตัดหน้าสระหน้าตัวล่าสุดถ้าอยู่ใกล้ๆ จะดูเป็นพยางค์มากกว่า
            j = max((k for k, c in enumerate(cur) if c in _LEADING and k > 0), default=-1)
            if j > 0 and units(cur[j:]) <= 3:
                out.append(cur[:j])
                cur = cur[j:]
            else:
                out.append(cur)
                cur = ""
        cur += ch
    if cur:
        out.append(cur)
    return out


def wrap(text: str, max_u: int) -> list[str]:
    """ตัดบรรทัดแบบไม่ทำให้ภาษาไทยพัง: ตัดที่ช่องว่าง/ขอบคำก่อน (ใช้ pythainlp ถ้ามี) ยาวเกินจริงๆ ค่อยตัดในคำ"""
    text = " ".join((text or "").split())
    if not text:
        return []
    pieces: list[tuple[str, str]] = []          # (ตัวคั่นก่อนหน้า, คำ)
    prev = 0
    for tok, a, b in tokenize(text):
        pieces.append((text[prev:a], tok))
        prev = b
    lines: list[str] = []
    cur = ""
    for sep, tok in pieces:
        for part_i, part in enumerate(_hard_split(tok, max_u) if units(tok) > max_u else [tok]):
            glue = sep if part_i == 0 else ""
            cand = (cur + glue + part) if cur else part
            if cur and units(cand) > max_u:
                lines.append(cur.rstrip())
                cur = part
            else:
                cur = cand
    if cur:
        lines.append(cur.rstrip())
    return lines


def fit(text: str, box_w: float, max_lines: int, fs_max: int, fs_min: int) -> tuple[int, list[str]]:
    """หาฟอนต์ใหญ่สุดที่ข้อความลงกล่องได้ภายในจำนวนบรรทัดที่กำหนด"""
    fs = fs_max
    while True:
        max_u = max(4, int(box_w / (fs * GLYPH_EM)))
        lines = wrap(text, max_u)
        if len(lines) <= max_lines or fs <= fs_min:
            return fs, lines[:max_lines] if fs > fs_min else lines
        fs = max(fs_min, int(fs * 0.92))


def est_width(line: str, fs: int) -> float:
    return units(line) * fs * GLYPH_EM


# ------------------------------------------------------------------ ASS
def _c(hexcol: str) -> str:
    h = hexcol.lstrip("#")
    return f"&H{h[4:6]}{h[2:4]}{h[0:2]}&".upper()


def _a(opacity: float) -> str:
    return f"&H{int(round((1 - max(0.0, min(1.0, opacity))) * 255)):02X}&"


def _t(ms: float) -> str:
    cs = int(round(max(0.0, ms) / 10))
    h, cs = divmod(cs, 360000)
    m, cs = divmod(cs, 6000)
    s, cs = divmod(cs, 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def _esc(s: str) -> str:
    return s.replace("\\", "＼").replace("{", "(").replace("}", ")")


def rrect(w: float, h: float, r: float) -> str:
    """สี่เหลี่ยมมุมมน (พิกัดในกล่อง 0..w, 0..h)"""
    r = max(0.0, min(r, w / 2, h / 2))
    k = r * 0.4477
    return (f"m {r:.1f} 0 l {w - r:.1f} 0 b {w - k:.1f} 0 {w:.1f} {k:.1f} {w:.1f} {r:.1f} "
            f"l {w:.1f} {h - r:.1f} b {w:.1f} {h - k:.1f} {w - k:.1f} {h:.1f} {w - r:.1f} {h:.1f} "
            f"l {r:.1f} {h:.1f} b {k:.1f} {h:.1f} 0 {h - k:.1f} 0 {h - r:.1f} "
            f"l 0 {r:.1f} b 0 {k:.1f} {k:.1f} 0 {r:.1f} 0")


def circle(d: float) -> str:
    return rrect(d, d, d / 2)


def check_icon(s: float) -> str:
    p = [(8, 52), (22, 38), (40, 56), (78, 18), (92, 32), (40, 84)]
    return "m " + " l ".join(f"{x * s / 100:.1f} {y * s / 100:.1f}" for x, y in p)


def cross_icon(s: float) -> str:
    p = [(20, 8), (50, 38), (80, 8), (92, 20), (62, 50), (92, 80), (80, 92), (50, 62), (20, 92), (8, 80), (38, 50), (8, 20)]
    return "m " + " l ".join(f"{x * s / 100:.1f} {y * s / 100:.1f}" for x, y in p)


@dataclass
class G:
    """ตัวช่วยประกอบฉากกราฟิก — template เรียกเมธอดพวกนี้ ไม่ต้องรู้รูปแบบ ASS"""
    dur: float                       # มิลลิวินาที
    pal: dict
    font: str
    lang: str = "th"
    events: list[str] = field(default_factory=list)

    def _push(self, layer: int, t0: float, t1: float | None, tags: str, body: str) -> None:
        end = self.dur + 500 if t1 is None else t1
        self.events.append(f"Dialogue: {layer},{_t(t0)},{_t(end)},G,,0,0,0,,{{{tags}}}{body}")

    @staticmethod
    def _anim(anim: str | None, x: float, y: float, op: float, scale_from: int = 70) -> str:
        if anim == "pop":
            return (f"\\pos({x:.0f},{y:.0f})\\fscx{scale_from}\\fscy{scale_from}\\alpha&HFF&"
                    f"\\t(0,170,\\fscx106\\fscy106\\alpha{_a(op)})\\t(170,260,\\fscx100\\fscy100)")
        if anim == "slide":
            return f"\\move({x:.0f},{y + 60:.0f},{x:.0f},{y:.0f},0,280)\\alpha&HFF&\\t(0,220,\\alpha{_a(op)})"
        if anim == "slide_left":
            return f"\\move({x + 80:.0f},{y:.0f},{x:.0f},{y:.0f},0,280)\\alpha&HFF&\\t(0,220,\\alpha{_a(op)})"
        if anim == "fade":
            return f"\\pos({x:.0f},{y:.0f})\\alpha&HFF&\\t(0,300,\\alpha{_a(op)})"
        return f"\\pos({x:.0f},{y:.0f})\\alpha{_a(op)}"

    def text(self, x: float, y: float, lines: list[str] | str, fs: int, color: str, *, t0: float = 0,
             t1: float | None = None, an: int = 5, bold: bool = True, anim: str | None = "pop", op: float = 1.0,
             dim_at: float | None = None, layer: int = 3, extra: str = "", raw: bool = False) -> None:
        items = [lines] if isinstance(lines, str) else lines
        body = "\\N".join(s if raw else _esc(s) for s in items)
        tags = (f"\\an{an}\\fn{self.font}\\fs{fs}\\b{1 if bold else 0}\\c{_c(color)}\\bord0\\shad0\\q2"
                f"{self._anim(anim, x, y, op)}{extra}")
        if dim_at is not None:
            rel = max(0.0, dim_at - t0)
            tags += f"\\t({rel:.0f},{rel + 250:.0f},\\alpha{_a(op * 0.35)})"
        self._push(layer, t0, t1, tags, body)

    def shape(self, x: float, y: float, path: str, color: str, *, t0: float = 0, t1: float | None = None,
              an: int = 5, anim: str | None = "pop", op: float = 1.0, blur: float = 0, layer: int = 1,
              dim_at: float | None = None, extra: str = "") -> None:
        tags = (f"\\an{an}\\bord0\\shad0\\c{_c(color)}\\blur{blur:g}"
                f"{self._anim(anim, x, y, op)}{extra}\\p1")
        if dim_at is not None:
            rel = max(0.0, dim_at - t0)
            tags = tags.replace("\\p1", f"\\t({rel:.0f},{rel + 250:.0f},\\alpha{_a(op * 0.35)})\\p1")
        self._push(layer, t0, t1, tags, path)

    def grow(self, x: float, y: float, w: float, h: float, color: str, *, t0: float, dur: float = 550,
             r: float = 0, from_center: bool = False, op: float = 1.0, layer: int = 2) -> None:
        """แท่ง/เส้นที่ยืดออก (กราฟแท่ง, เส้นขีดใต้)"""
        an = 5 if from_center else 4
        tags = (f"\\an{an}\\bord0\\shad0\\c{_c(color)}\\alpha{_a(op)}\\pos({x:.0f},{y:.0f})"
                f"\\fscx0\\t(0,{dur:.0f},0.6,\\fscx100)\\p1")
        self._push(layer, t0, None, tags, rrect(w, h, r))

    def card(self, cx: float, cy: float, w: float, h: float, *, color: str | None = None, op: float | None = None,
             t0: float = 0, dim_at: float | None = None, anim: str | None = "pop") -> None:
        self.shape(cx, cy + 10, rrect(w, h, 36), "#000000", t0=t0, op=0.22, blur=18, layer=0, anim=anim, dim_at=dim_at)
        self.shape(cx, cy, rrect(w, h, 36), color or self.pal["card"], t0=t0,
                   op=self.pal["card_a"] if op is None else op, layer=1, anim=anim, dim_at=dim_at)

    def pill(self, cx: float, cy: float, label: str, bg: str, fg: str, *, fs: int = 44, t0: float = 0,
             dim_at: float | None = None) -> float:
        w = est_width(label, fs) + fs * 1.4
        self.shape(cx, cy, rrect(w, fs * 1.6, fs * 0.8), bg, t0=t0, layer=2, dim_at=dim_at)
        self.text(cx, cy, label, fs, fg, t0=t0, layer=3, dim_at=dim_at)
        return w

    def backdrop(self) -> None:
        """วงแสงนุ่มๆ ลอยช้าๆ ด้านหลัง — ให้พื้นไม่นิ่งตาย"""
        d = self.dur + 500
        for i, (x0, y0, x1, y1, size, col) in enumerate([
                (180, 420, 260, 360, 640, self.pal["accent"]), (920, 1500, 840, 1560, 760, self.pal["text"])]):
            tags = (f"\\an5\\bord0\\shad0\\c{_c(col)}\\alpha{_a(0.07 if i == 0 else 0.05)}\\blur60"
                    f"\\move({x0},{y0},{x1},{y1},0,{d:.0f})\\p1")
            self._push(0, 0, None, tags, circle(size))

    def to_ass(self) -> str:
        head = ("[Script Info]\nScriptType: v4.00+\nPlayResX: 1080\nPlayResY: 1920\nWrapStyle: 2\n"
                "ScaledBorderAndShadow: yes\nYCbCr Matrix: TV.709\n\n[V4+ Styles]\n"
                "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, "
                "Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, "
                "Alignment, MarginL, MarginR, MarginV, Encoding\n"
                f"Style: G,{self.font},64,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,0,0,5,0,0,0,1\n\n"
                "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n")
        return head + "\n".join(self.events) + "\n"


# ------------------------------------------------------------------ เรนเดอร์
def _esc_filter(p: str) -> str:
    return p.replace("\\", "/").replace(":", r"\:").replace("'", r"\'")


def render(template: str, data: dict, out_dir: Path, *, width: int, height: int, fps: int, frames: int,
           palette: dict, font: str, lang: str, fonts_dir: Path | None = None, preset: str = "veryfast",
           crf: int = 20) -> Path:
    """เรนเดอร์กราฟิกเป็น mp4 ยาวเท่าจำนวนเฟรมพอดี — แคชตามข้อมูลทั้งหมด (แก้ข้อความ = ไฟล์ใหม่)"""
    from .templates import get
    tpl = get(template)
    fp = fingerprint(ENGINE_VERSION, template, data, width, height, fps, frames, palette, font, lang)
    out_dir = Path(out_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"g_{template}_{fp}.mp4"
    if out.exists() and out.stat().st_size > 1024:
        return out
    dur_ms = frames / fps * 1000
    g = G(dur_ms, palette, font, lang)
    g.backdrop()
    tpl.build(g, data)
    work = out_dir / "work"
    work.mkdir(parents=True, exist_ok=True)
    ass = work / f"g_{fp}.ass"
    ass.write_text(g.to_ass(), encoding="utf-8")
    vf = f"ass=filename='{ass.name}'"
    if fonts_dir and Path(fonts_dir).exists():
        vf += f":fontsdir='{_esc_filter(str(Path(fonts_dir).resolve()))}'"
    secs = frames / fps + 0.5
    b0, b1 = palette["bg0"].lstrip("#"), palette["bg1"].lstrip("#")
    sources = [f"gradients=s={width}x{height}:c0=0x{b0}:c1=0x{b1}:x0=0:y0=0:x1={width}:y1={height}"
               f":speed=0.006:d={secs:.2f}:r={fps}",
               f"color=c=0x{b0}:s={width}x{height}:r={fps}:d={secs:.2f}"]      # ffmpeg รุ่นเก่าไม่มี gradients
    tmp = out.with_suffix(".tmp.mp4")
    last: Exception | None = None
    for src in sources:
        try:
            ffmpeg.run(["-f", "lavfi", "-i", src, "-vf", vf, "-frames:v", str(frames), "-c:v", "libx264",
                        "-preset", preset, "-crf", str(crf), "-pix_fmt", "yuv420p", "-r", str(fps), tmp],
                       cwd=work, timeout=300)
            break
        except FFmpegError as e:
            last = e
    else:
        raise last or FFmpegError("เรนเดอร์กราฟิกไม่สำเร็จ")
    tmp.replace(out)
    ass.unlink(missing_ok=True)
    return out


def thumbnail_data_uri(video: str | Path, at: float = 0.75, width: int = 144) -> str:
    """ภาพนิ่งเล็กๆ ของกราฟิก (ฝังในหน้าเว็บได้เลย ไม่ต้องเสิร์ฟไฟล์)"""
    video = Path(video)
    jpg = video.with_suffix(f".{width}.jpg")
    if not jpg.exists():
        try:
            dur = ffmpeg.duration(video)
            ffmpeg.run(["-ss", f"{dur * at:.2f}", "-i", video, "-frames:v", "1", "-vf", f"scale={width}:-2",
                        "-q:v", "5", jpg], timeout=60)
        except FFmpegError:
            return ""
    return "data:image/jpeg;base64," + base64.b64encode(jpg.read_bytes()).decode()
