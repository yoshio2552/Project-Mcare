"""แบบภาพอธิบาย — 1 ฟังก์ชัน = 1 แบบ (ตัวต่อ LEGO)

เพิ่มแบบใหม่: เขียนฟังก์ชันวาด แล้วใส่ @template(...) ระบุชื่อ, ใช้เมื่อไร (ให้ AI อ่าน), ช่องข้อมูล, ตัวอย่าง
→ AI เห็นแบบใหม่ในพรอมต์เขียนบท, หน้าตัวตัดต่อมีให้เลือก, ระบบตรวจข้อมูลให้เอง ไม่ต้องแก้ไฟล์อื่น
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Callable

from .engine import G, ZONE_BOTTOM, ZONE_TOP, check_icon, circle, cross_icon, est_width, fit


@dataclass
class F:
    name: str
    label: str                     # ไว้โชว์ในหน้าแก้ข้อความ
    kind: str = "text"             # text | list | bars
    max_len: int = 60
    required: bool = True
    min_items: int = 2
    max_items: int = 5


@dataclass
class Template:
    name: str
    label: str
    when: str                      # อธิบายให้ AI รู้ว่าใช้กับประโยคแบบไหน (อังกฤษ)
    fields: list[F]
    example: dict
    build: Callable[[G, dict], None] = field(repr=False, default=lambda g, d: None)


REGISTRY: dict[str, Template] = {}


def template(name: str, label: str, when: str, fields: list[F], example: dict):
    def deco(fn):
        kinds = [f.kind for f in fields]
        if any(k != "text" for k in kinds[:-1]):
            raise ValueError(f"แบบ {name}: ช่องแบบรายการต้องอยู่ท้ายสุด (แก้เป็นบรรทัดได้ถูก)")
        REGISTRY[name] = Template(name, label, when, fields, example, fn)
        return fn
    return deco


def get(name: str) -> Template:
    if name not in REGISTRY:
        raise KeyError(f"ไม่มีแบบภาพ '{name}'")
    return REGISTRY[name]


def choices() -> list[tuple[str, str]]:
    return [(t.label, t.name) for t in REGISTRY.values()]


# ------------------------------------------------------------------ ตรวจ/แปลงข้อมูล
def _clean(v, n: int) -> str:
    s = " ".join(str(v or "").split()).strip(" \"'")
    return s[:n].rstrip()


def _num(v) -> float | None:
    m = re.search(r"-?\d+(?:[.,]\d+)?", str(v or "").replace(",", ""))
    return float(m.group(0)) if m else None


def normalize(name: str, data: dict | None) -> dict | None:
    """ข้อมูลจาก AI/ผู้ใช้ → ข้อมูลที่ปลอดภัยสำหรับวาด (ตัดยาว/ทิ้งช่องเกิน) หรือ None ถ้าใช้ไม่ได้"""
    if name not in REGISTRY or not isinstance(data, dict):
        return None
    out: dict = {}
    for f in REGISTRY[name].fields:
        v = data.get(f.name)
        if f.kind == "text":
            s = _clean(v, f.max_len)
            if s:
                out[f.name] = s
            elif f.required:
                return None
        elif f.kind == "list":
            items = [_clean(x, f.max_len) for x in (v if isinstance(v, list) else [])]
            items = [x for x in items if x][: f.max_items]
            if len(items) < f.min_items:
                if f.required:
                    return None
                continue
            out[f.name] = items
        elif f.kind == "bars":
            bars = []
            for b in v if isinstance(v, list) else []:
                lab = _clean((b or {}).get("label") if isinstance(b, dict) else "", f.max_len)
                val = _num((b or {}).get("value") if isinstance(b, dict) else None)
                if lab and val is not None and val >= 0:
                    bars.append({"label": lab, "value": val})
            bars = bars[: f.max_items]
            if len(bars) < f.min_items:
                return None
            out[f.name] = bars
    return out


def to_lines(name: str, data: dict) -> str:
    """ข้อมูล → ข้อความหลายบรรทัด (ให้คนแก้ง่ายในช่องเดียว)"""
    lines: list[str] = []
    for f in REGISTRY[name].fields:
        v = data.get(f.name)
        if f.kind == "text":
            lines.append(v or "")
        elif f.kind == "list":
            lines += list(v or [])
        elif f.kind == "bars":
            lines += [f"{b['label']}: {b['value']:g}" for b in v or []]
    while lines and not lines[-1]:
        lines.pop()
    return "\n".join(lines)


def from_lines(name: str, text: str) -> dict | None:
    """ข้อความหลายบรรทัด → ข้อมูล (ช่องข้อความเรียงตามลำดับ, ช่องรายการกินบรรทัดที่เหลือ)"""
    rows = [r.strip() for r in (text or "").splitlines()]
    flds = REGISTRY[name].fields
    data: dict = {}
    i = 0
    for f in flds:
        if f.kind == "text":
            data[f.name] = rows[i] if i < len(rows) else ""
            i += 1
        elif f.kind == "list":
            data[f.name] = [r for r in rows[i:] if r]
            i = len(rows)
        elif f.kind == "bars":
            bars = []
            for r in rows[i:]:
                if ":" in r:
                    lab, val = r.rsplit(":", 1)
                    bars.append({"label": lab.strip(), "value": val.strip()})
            data[f.name] = bars
            i = len(rows)
    return normalize(name, data)


def lines_help(name: str) -> str:
    parts = []
    for f in REGISTRY[name].fields:
        tag = "" if f.required else " (ไม่ใส่ก็ได้)"
        if f.kind == "list":
            parts.append(f"บรรทัดที่เหลือ = {f.label} ทีละบรรทัด")
        elif f.kind == "bars":
            parts.append(f"บรรทัดที่เหลือ = {f.label} รูปแบบ ชื่อ: ตัวเลข")
        else:
            parts.append(f"{f.label}{tag}")
    return " · ".join(f"{i + 1}) {p}" if not p.startswith("บรรทัด") else p for i, p in enumerate(parts))


def catalog(lang: str = "th") -> str:
    """รายการแบบภาพสำหรับใส่ในพรอมต์ของ AI"""
    return "\n".join(f'- "{t.name}": {t.when}. fields: {json.dumps(t.example, ensure_ascii=False)}'
                     for t in REGISTRY.values())


def _lab(g: G, th: str, en: str) -> str:
    return th if g.lang == "th" else en


# ------------------------------------------------------------------ แบบภาพ
@template("big_number", "ตัวเลขใหญ่",
          "a striking statistic, percentage, count, amount of time or money that is SPOKEN in this beat",
          [F("value", "ตัวเลข เช่น 70% หรือ 8 ชม.", max_len=14), F("label", "คำอธิบายตัวเลข"),
           F("sub", "บรรทัดเล็กด้านล่าง เช่น ที่มา", required=False)],
          {"value": "70%", "label": "ของคนทำงานนอนไม่ถึง 6 ชั่วโมง", "sub": ""})
def big_number(g: G, d: dict) -> None:
    val = d["value"]
    fs, lines = fit(val, 900, 1, 390, 156)
    y = 620
    m = re.match(r"^(\D*?)(\d+(?:[.,]\d+)?)(.*)$", val)
    if m and len(m.group(2)) <= 7:
        pre, num, post = m.groups()
        target = float(num.replace(",", ""))
        dec = len(num.split(".")[1]) if "." in num else 0
        steps = 14
        for i in range(steps + 1):                 # นับขึ้นจาก 0 → ค่าจริง (เร่งแล้วชะลอ)
            t = i / steps
            v = target * (1 - (1 - t) ** 3)
            s = f"{pre}{v:,.{dec}f}{post}" if "," in num else f"{pre}{v:.{dec}f}{post}"
            t0 = 60 + i * 50
            t1 = None if i == steps else 60 + (i + 1) * 50
            g.text(540, y, s, fs, g.pal["accent"], t0=t0, t1=t1, anim="pop" if i == 0 else None)
    else:
        g.text(540, y, lines, fs, g.pal["accent"], t0=60)
    uw = min(est_width(val, fs) * 0.8, 640)
    g.grow(540, y + fs * 0.58, uw, 14, g.pal["accent"], t0=520, r=7, from_center=True, op=0.9)
    lfs, llines = fit(d["label"], 900, 3, 109, 65)
    ly = y + fs * 0.58 + 60 + len(llines) * lfs * 0.6
    g.text(540, ly, llines, lfs, g.pal["text"], t0=480, anim="slide")
    if d.get("sub"):
        sfs, sl = fit(d["sub"], 860, 2, 55, 42)
        g.text(540, min(ZONE_BOTTOM - 40, ly + len(llines) * lfs * 0.6 + 70 + sfs), sl, sfs, g.pal["muted"],
               t0=900, anim="fade", bold=False)


@template("myth_fact", "ความเชื่อ vs ความจริง",
          "the beat corrects a common belief or mistake (what people think vs what is true)",
          [F("myth", "สิ่งที่คนเชื่อ"), F("fact", "ความจริง")],
          {"myth": "นอนชดเชยวันหยุดได้", "fact": "ชดเชยไม่ได้ทั้งหมด ร่างกายยังล้า"})
def myth_fact(g: G, d: dict) -> None:
    t_fact = max(700.0, g.dur * 0.42)
    for (cy, key, col, tag, icon, t0) in [
            (530, "myth", g.pal["bad"], _lab(g, "ความเชื่อ", "MYTH"), cross_icon, 0.0),
            (1000, "fact", g.pal["good"], _lab(g, "ความจริง", "FACT"), check_icon, t_fact)]:
        dim = t_fact if key == "myth" else None
        g.card(540, cy, 900, 400, t0=t0, dim_at=dim,
               color=col if key == "fact" else None, op=0.16 if key == "fact" else None)
        g.pill(250, cy - 130, tag, col, "#FFFFFF", fs=62, t0=t0 + 80, dim_at=dim)
        g.shape(890, cy - 130, circle(96), col, t0=t0 + 160, layer=2, dim_at=dim)
        g.shape(890, cy - 130, icon(52), "#FFFFFF", t0=t0 + 200, layer=3, dim_at=dim)
        fs, lines = fit(d[key], 800, 3, 86, 55)
        g.text(540, cy + 40, lines, fs, g.pal["text"], t0=t0 + 140, anim="slide", dim_at=dim)
    g.grow(140, 570, 800, 10, g.pal["bad"], t0=t_fact - 40, r=5, op=0.85, layer=4)   # ขีดฆ่าความเชื่อ


@template("steps", "ขั้นตอน / รายการ",
          "the beat lists tips, steps, reasons or ingredients (2-5 short items)",
          [F("title", "หัวข้อ"), F("items", "รายการ", kind="list", max_len=40)],
          {"title": "3 วิธีหลับไวขึ้น", "items": ["ปิดจอก่อนนอน 1 ชม.", "ห้องมืดและเย็น", "ตื่นเวลาเดิมทุกวัน"]})
def steps(g: G, d: dict) -> None:
    tfs, tl = fit(d["title"], 900, 2, 99, 65)
    g.text(540, ZONE_TOP + 90, tl, tfs, g.pal["accent"], t0=0)
    items = d["items"]
    n = len(items)
    top = ZONE_TOP + 90 + len(tl) * tfs * 0.6 + 90
    row = min(180.0, (ZONE_BOTTOM - top) / n)
    span = max(600.0, g.dur - 900)
    for i, it in enumerate(items):
        t0 = 250 + i * span / n
        cy = top + row * i + row / 2
        g.shape(150, cy, circle(100), g.pal["accent"], t0=t0, layer=2)
        g.text(150, cy, str(i + 1), 66, g.pal["ink"], t0=t0 + 40)
        fs, lines = fit(it, 760, 2, 90, 56)
        g.text(232, cy, lines, fs, g.pal["text"], t0=t0 + 60, an=4, anim="slide_left")


@template("compare", "เปรียบเทียบ 2 ฝั่ง",
          "the beat compares two things: before/after, wrong/right, A vs B (left = worse or before, right = better or after)",
          [F("left_title", "หัวข้อฝั่งซ้าย", max_len=18), F("left", "ข้อความฝั่งซ้าย", max_len=70),
           F("right_title", "หัวข้อฝั่งขวา", max_len=18), F("right", "ข้อความฝั่งขวา", max_len=70)],
          {"left_title": "นอนดึก", "left": "ง่วงทั้งวัน สมาธิสั้น", "right_title": "นอนตรงเวลา", "right": "ตื่นสดชื่น โฟกัสดี"})
def compare(g: G, d: dict) -> None:
    t2 = max(600.0, g.dur * 0.38)
    for (cx, side, col, t0) in [(285, "left", g.pal["bad"], 0.0), (795, "right", g.pal["good"], t2)]:
        g.card(cx, 770, 450, 640, t0=t0, color=col, op=0.14)
        tfs, tl = fit(d[f"{side}_title"], 380, 1, 65, 44)
        g.pill(cx, 520, tl[0] if tl else "", col, "#FFFFFF", fs=tfs, t0=t0 + 80)
        fs, lines = fit(d[side], 380, 5, 84, 50)
        g.text(cx, 800, lines, fs, g.pal["text"], t0=t0 + 150, anim="slide")
    g.shape(540, 770, circle(118), g.pal["accent"], t0=t2 - 120, layer=4)
    g.text(540, 770, "VS", 60, g.pal["ink"], t0=t2 - 80, layer=5)


@template("headline", "ข้อความใหญ่ (ประโยคเด็ด)",
          "a punchline, bold claim, warning or the key takeaway; put 1-2 words to highlight in emphasis",
          [F("text", "ข้อความ", max_len=70), F("emphasis", "คำที่เน้นสี (ต้องอยู่ในข้อความ)", required=False, max_len=24)],
          {"text": "นอนน้อย ทำให้อ้วนง่ายขึ้น", "emphasis": "อ้วนง่าย"})
def headline(g: G, d: dict) -> None:
    fs, lines = fit(d["text"], 920, 4, 156, 83)
    emph = d.get("emphasis", "")
    total_h = len(lines) * fs * 1.15
    y0 = (ZONE_TOP + ZONE_BOTTOM) / 2 - total_h / 2 + fs * 0.55
    g.grow(540, y0 - fs * 0.9, 120, 14, g.pal["accent"], t0=0, r=7, from_center=True, dur=350)
    for i, ln in enumerate(lines):
        if emph and emph in ln:
            a, b = ln.split(emph, 1)
            from .engine import _c, _esc
            body = f"{_esc(a)}{{\\c{_c(g.pal['accent'])}}}{_esc(emph)}{{\\c{_c(g.pal['text'])}}}{_esc(b)}"
            g.text(540, y0 + i * fs * 1.15, [body], fs, g.pal["text"], t0=120 + i * 230, anim="slide", raw=True)
        else:
            g.text(540, y0 + i * fs * 1.15, ln, fs, g.pal["text"], t0=120 + i * 230, anim="slide")


@template("bar_chart", "กราฟแท่ง",
          "the beat compares 2-5 numbers that are spoken (amounts, percentages, hours)",
          [F("title", "หัวข้อกราฟ"), F("unit", "หน่วย เช่น % หรือ ชม. (ว่างได้)", required=False, max_len=8),
           F("bars", "แท่งกราฟ", kind="bars", max_len=24)],
          {"title": "ชั่วโมงนอนที่แนะนำ", "unit": "ชม.", "bars": [{"label": "วัยรุ่น", "value": 9},
                                                                 {"label": "ผู้ใหญ่", "value": 8}, {"label": "ผู้สูงอายุ", "value": 7}]})
def bar_chart(g: G, d: dict) -> None:
    tfs, tl = fit(d["title"], 900, 2, 91, 60)
    g.text(540, ZONE_TOP + 80, tl, tfs, g.pal["text"], t0=0)
    bars = d["bars"]
    top = ZONE_TOP + 80 + len(tl) * tfs * 0.6 + 70
    row = min(200.0, (ZONE_BOTTOM - top) / len(bars))
    mx = max(b["value"] for b in bars) or 1
    unit = d.get("unit", "")
    for i, b in enumerate(bars):
        t0 = 250 + i * 160
        y = top + row * i
        g.text(90, y + 28, b["label"], 60, g.pal["muted"], t0=t0, an=4, anim="fade")
        w = max(24.0, 680 * b["value"] / mx)
        col = g.pal["accent"] if b["value"] == mx else g.pal["text"]
        g.grow(90, y + 100, w, 60, col, t0=t0 + 80, r=12, op=1.0 if b["value"] == mx else 0.55, dur=650)
        sep = "" if (not unit or unit.startswith("%")) else " "
        g.text(90 + w + 24, y + 104, f"{b['value']:g}{sep}{unit}", 66, g.pal["text"], t0=t0 + 650, an=4, anim="fade")


@template("question", "คำถามชวนทาย",
          "the beat asks the viewer a question or quiz before revealing the answer in the next beat",
          [F("question", "คำถาม", max_len=70), F("options", "ตัวเลือก (ไม่ใส่ก็ได้)", kind="list", required=False,
                                                 max_len=36, min_items=2, max_items=3)],
          {"question": "นอนกี่ชั่วโมง ถึงจะพอ?", "options": ["5 ชั่วโมง", "7-9 ชั่วโมง", "10 ชั่วโมง"]})
def question(g: G, d: dict) -> None:
    g.pill(300, ZONE_TOP + 70, _lab(g, "ทายก่อน!", "QUIZ"), g.pal["accent"], g.pal["ink"], fs=58, t0=0)
    fs, lines = fit(d["question"], 900, 3, 101, 65)
    qy = ZONE_TOP + 200 + len(lines) * fs * 0.55
    g.text(540, qy, lines, fs, g.pal["text"], t0=120, anim="slide")
    opts = d.get("options") or []
    y = qy + len(lines) * fs * 0.6 + 110
    for i, o in enumerate(opts):
        t0 = 450 + i * 220
        cy = y + i * 150
        g.card(540, cy, 900, 124, t0=t0, anim="slide_left")
        g.shape(150, cy, circle(80), g.pal["accent"], t0=t0 + 40, layer=2)
        g.text(150, cy, "ABC"[i], 56, g.pal["ink"], t0=t0 + 60)
        ofs, ol = fit(o, 720, 1, 80, 50)
        g.text(222, cy, ol, ofs, g.pal["text"], t0=t0 + 80, an=4, anim="slide_left")
    if g.dur >= 2200:                                  # นับถอยหลัง 3-2-1 มุมขวาบน
        seg = (g.dur - 300) / 3
        g.shape(900, ZONE_TOP + 70, circle(124), g.pal["text"], t0=0, op=0.12, layer=1)
        for k in range(3):
            g.text(900, ZONE_TOP + 70, str(3 - k), 80, g.pal["accent"], t0=150 + k * seg, t1=150 + (k + 1) * seg)
