"""ทำให้ภาพนิ่งเคลื่อนไหว (Ken Burns): ซูมเข้า/ออก หรือแพนช้าๆ — ภาพ AI จะได้ไม่ดูเป็นสไลด์

fit:
  cover = เต็มจอ (ตัดขอบที่เกิน) — เหมาะกับภาพแนวตั้ง
  frame = ภาพเต็มใบอยู่ช่วงบน พื้นหลังเป็นภาพเดียวกันแบบเบลอ — เหมาะกับภาพสี่เหลี่ยมจัตุรัส (ไม่เสียส่วนสำคัญ)
  auto  = ดูจากสัดส่วนภาพเอง
"""
from __future__ import annotations

from pathlib import Path

from ..core import ffmpeg
from ..core.models import fingerprint

MODES = ("zoom_in", "zoom_out", "pan_left", "pan_right")
ZOOM = 0.10            # ซูม 10% ตลอดช็อต — พอให้รู้สึกเคลื่อน ไม่เวียนหัว
FRAME_TOP = 270        # ตำแหน่งภาพในโหมด frame (พิกัด 1920) เว้นด้านล่างให้ซับ


def pick_mode(setting: str, index: int) -> str:
    if setting in MODES:
        return setting
    return MODES[index % len(MODES)]                 # auto: สลับกันไปให้ไม่ซ้ำจังหวะ


def _ev(n: int) -> int:
    return n + (n % 2)


def _motion(mode: str, w: int, h: int, last: int) -> str:
    """filter ที่รับภาพขนาดพอดี w×h (หรือใหญ่กว่า) แล้วออกมาเป็น w×h ที่ขยับแล้ว"""
    if mode == "zoom_in":
        return (f"scale=w='trunc({w}*(1+{ZOOM}*n/{last})/2)*2':h=-2:eval=frame:flags=bicubic,"
                f"crop={w}:{h}")
    if mode == "zoom_out":
        return (f"scale=w='trunc({w}*(1+{ZOOM}*(1-n/{last}))/2)*2':h=-2:eval=frame:flags=bicubic,"
                f"crop={w}:{h}")
    big = _ev(int(w * (1 + ZOOM * 1.4)))
    x = f"(in_w-{w})*n/{last}" if mode == "pan_left" else f"(in_w-{w})*(1-n/{last})"
    return f"scale={big}:-2:flags=lanczos,crop={w}:{h}:x='{x}':y='(in_h-{h})/2'"


def animate(image: str | Path, out_dir: Path, *, width: int, height: int, fps: int, frames: int,
            mode: str = "zoom_in", fit: str = "auto", src_size: tuple[int, int] | None = None,
            preset: str = "veryfast", crf: int = 20) -> Path:
    image = Path(image).resolve()
    out_dir = Path(out_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    if src_size is None:
        info = ffmpeg.probe(image)
        src_size = (int(info["width"]), int(info["height"]))
    sw, sh = src_size
    if fit == "auto":
        fit = "cover" if sh / max(1, sw) >= 1.3 else "frame"
    fp = fingerprint(str(image), image.stat().st_size, width, height, fps, frames, mode, fit, ZOOM)
    out = out_dir / f"kb_{fp}.mp4"
    if out.exists() and out.stat().st_size > 1024:
        return out
    last = max(1, frames - 1)
    if fit == "cover":
        graph = (f"[0:v]scale={width}:{height}:force_original_aspect_ratio=increase:flags=lanczos,"
                 f"crop={width}:{height},{_motion(mode, width, height, last)},setsar=1,format=yuv420p[v]")
    else:
        fw = width
        fh = _ev(int(round(width * sh / max(1, sw))))
        fh = min(fh, _ev(int(height * 0.62)))
        top = int(round(FRAME_TOP * height / 1920))
        graph = (f"[0:v]split[a][b];"
                 f"[a]scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height},"
                 f"boxblur=28:2,eq=brightness=-0.10:saturation=1.1[bg];"
                 f"[b]scale={fw}:{fh}:force_original_aspect_ratio=increase:flags=lanczos,crop={fw}:{fh},"
                 f"{_motion(mode, fw, fh, last)}[fg];"
                 f"[bg][fg]overlay=0:{top}:shortest=1,setsar=1,format=yuv420p[v]")
    tmp = out.with_suffix(".tmp.mp4")
    ffmpeg.run(["-loop", "1", "-framerate", str(fps), "-t", f"{frames / fps + 0.5:.2f}", "-i", image,
                "-filter_complex", graph, "-map", "[v]", "-frames:v", str(frames), "-r", str(fps),
                "-c:v", "libx264", "-preset", preset, "-crf", str(crf), "-pix_fmt", "yuv420p", tmp], timeout=300)
    tmp.replace(out)
    return out
