"""โหลดพรอมต์จากไฟล์ .md ในโฟลเดอร์ forge/prompts — ปรับสไตล์การเขียนบทได้โดยไม่ต้องแตะโค้ด"""
from __future__ import annotations

from pathlib import Path
from string import Template

DIR = Path(__file__).resolve().parent.parent / "prompts"
# ผู้ใช้วางไฟล์ชื่อเดียวกันไว้ที่ data/prompts/ เพื่อ override พรอมต์ได้ (ไม่ต้องแก้ใน forge/)
USER_DIR: Path | None = None

SYSTEM = (
    "You are a precise assistant inside a video production tool. "
    "Follow the requested output format exactly. When asked for JSON, return only valid JSON."
)


def render(name: str, **values) -> str:
    for base in (USER_DIR, DIR):
        if base and (base / f"{name}.md").exists():
            text = (base / f"{name}.md").read_text(encoding="utf-8")
            return Template(text).safe_substitute(**{k: str(v) for k, v in values.items()})
    raise FileNotFoundError(f"ไม่พบพรอมต์ {name}.md")
