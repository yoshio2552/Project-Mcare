"""ทักษะเขียนบท: สร้างบททั้งเรื่อง + ปรับความยาวบทให้พอดีเป้าหลังวัดเสียงจริง"""
from __future__ import annotations

import json
import re

from ..core.errors import ProviderError
from ..core.models import Project, Scene
from ..providers.base import LLMProvider
from . import prompts
from . import graphics as gx
from .beats import ensure_beats
from .timing import build_timeline, char_budgets, count_chars, cps_for

LANG_NAMES = {"th": "Thai", "en": "English"}
KW_PER_SCENE = 3
BEAT_SECONDS = 2.6          # ความยาวพูดต่อ 1 beat (= 1 ภาพ) โดยประมาณ
GRAPHIC_SHARE = {"few": 0.2, "balanced": 0.4, "many": 0.6}
IMAGE_SHARE = {"few": 0.15, "balanced": 0.3, "many": 0.5}


def images_enabled(cfg) -> bool:
    return str(cfg.get("image.provider", "none")) not in ("", "none")


def _clean_keywords(raw, used: set[str], fallback: str) -> list[str]:
    out: list[str] = []
    for k in (raw if isinstance(raw, list) else [raw]):
        k = re.sub(r"\s+", " ", str(k or "")).strip(" .,\"'")
        if k and k.lower() not in used:
            used.add(k.lower())
            out.append(k)
    if not out:
        out = [fallback]
    return out


def _parse_beats(raw, used: set[str]) -> list[dict]:
    out: list[dict] = []
    for b in raw if isinstance(raw, list) else []:
        if not isinstance(b, dict):
            continue
        say = re.sub(r"\s+", " ", str(b.get("say") or b.get("text") or "")).strip()
        if not say:
            continue
        qs: list[str] = []
        for q in b.get("queries") or b.get("keywords") or []:
            q = re.sub(r"\s+", " ", str(q or "")).strip(" .,\"'")
            if q and q.lower() not in (x.lower() for x in qs):
                qs.append(q)
        if qs and qs[0].lower() in used and len(qs) > 1:      # คำค้นแรกซ้ำกับ beat อื่น → ดันตัวถัดไปขึ้นมา
            qs = qs[1:] + qs[:1]
        if qs:
            used.add(qs[0].lower())
        beat = {"text": say, "visual": " ".join(str(b.get("visual", "")).split())[:300],
                "queries": qs[:4], "start_word": None, "kind": "stock"}
        kind = str(b.get("kind", "")).lower()
        g = parse_graphic(b.get("graphic")) if kind == "graphic" else None
        if g:
            beat["kind"], beat["graphic"] = "graphic", g
        elif kind == "aiimage" and str(b.get("image_prompt", "")).strip():
            beat["kind"] = "aiimage"
            beat["image_prompt"] = " ".join(str(b["image_prompt"]).split())[:600]
        out.append(beat)
    return out


def parse_graphic(raw) -> dict | None:
    """{"template": "...", ฟิลด์...} หรือ {"template": "...", "fields": {...}} → {"template", "data"} ที่ตรวจแล้ว"""
    if not isinstance(raw, dict):
        return None
    name = str(raw.get("template") or raw.get("type") or "").strip()
    fields = raw.get("fields") if isinstance(raw.get("fields"), dict) else {k: v for k, v in raw.items()
                                                                              if k not in ("template", "type")}
    data = gx.normalize(name, fields)
    return {"template": name, "data": data} if data else None


def enforce_graphics(project: Project, cfg) -> int:
    """คุมจังหวะภาพอธิบาย: ไม่เกินสัดส่วนที่ตั้ง (+เผื่อ), ไม่ติดกันเกิน 2 ช่วง, แบบเดียวกันห้ามติดกัน
    ช่วงที่เกิน → กลับเป็นวิดีโอ (มีคำค้นสำรองอยู่แล้ว) คืนจำนวนที่ถูกเปลี่ยน"""
    beats = [b for s in project.scenes for b in s.beats]
    changed_img = _enforce_images(beats, cfg)
    if not cfg.get("graphics.enabled", True):
        n = sum(1 for b in beats if b.get("kind") == "graphic")
        for b in beats:
            if b.get("kind") == "graphic":
                b["kind"] = "stock"
        return n + changed_img
    cap = max(1, round(len(beats) * (GRAPHIC_SHARE.get(str(cfg.get("graphics.share")), 0.4) + 0.15)))
    used, run, last_t, changed = 0, 0, None, 0
    for b in beats:
        if b.get("kind") == "graphic" and b.get("graphic"):
            t = b["graphic"]["template"]
            if used >= cap or run >= 2 or t == last_t or not b.get("queries"):
                if b.get("queries"):
                    b["kind"] = "stock"
                    changed += 1
                    run, last_t = 0, None
                    continue
            used += 1
            run += 1
            last_t = t
        elif b.get("kind") != "aiimage":
            b["kind"] = "stock"
            run, last_t = 0, None
        else:
            run, last_t = 0, None
    return changed + changed_img


def _enforce_images(beats: list[dict], cfg) -> int:
    """ภาพ AI: ไม่เกินสัดส่วน (+เผื่อ) และไม่ติดกันเกิน 2 ช่วง; ปิดอยู่ → กลับเป็นวิดีโอทั้งหมด"""
    on = images_enabled(cfg)
    cap = max(1, round(len(beats) * (IMAGE_SHARE.get(str(cfg.get("image.share")), 0.15) + 0.15)))
    used = run = changed = 0
    for b in beats:
        if b.get("kind") == "aiimage":
            if not on or not b.get("image_prompt") or ((used >= cap or run >= 2) and b.get("queries")):
                b["kind"] = "stock"
                changed += 1
                run = 0
                continue
            used += 1
            run += 1
        else:
            run = 0
    return changed


def build_prompt(project: Project, cfg, extra: str = "") -> str:
    n = int(cfg["scene_count"])
    secs = float(cfg["target_seconds"])
    budgets = char_budgets(project, secs, n)
    cps = cps_for(project)
    desc = "; ".join(f"scene {i + 1} ≈ {b} chars in {max(1, round(b / cps / BEAT_SECONDS))} beats"
                     for i, b in enumerate(budgets))
    if cfg.get("graphics.enabled", True):
        share = GRAPHIC_SHARE.get(str(cfg.get("graphics.share")), 0.4)
        graphics = (
            "Visual planner — each beat is either real footage (\"kind\": \"stock\") or an animated explainer graphic "
            "(\"kind\": \"graphic\") that the studio draws itself:\n"
            f"- Aim for about {round(share * 100)}% graphic beats. Use a graphic when the phrase is a number/statistic, a myth "
            "vs fact, a list of tips, a comparison, a question to the viewer, or the key punchline. Use stock for concrete "
            "people, places, objects and actions.\n"
            "- Never more than 2 graphic beats in a row, never the same template twice in a row. The hook's first beat should "
            "usually be strong footage or a headline/question graphic.\n"
            "- Graphic text is SHORT (it reinforces the phrase, never the whole sentence), in the narration language. "
            "Numbers shown must be exactly the numbers spoken in that beat — never invent statistics.\n"
            "- Still give visual + queries for graphic beats (used as a fallback).\n"
            "Templates (\"graphic\": {\"template\": name, ...fields}):\n" + gx.catalog(project.language))
    else:
        graphics = "Every beat is real footage: use \"kind\": \"stock\"."
    if images_enabled(cfg):
        ishare = IMAGE_SHARE.get(str(cfg.get("image.share")), 0.15)
        graphics += (
            "\nAI illustrations — a beat can also be \"kind\": \"aiimage\": an image generated in the channel's fixed art "
            f"style. Use it for about {round(ishare * 100)}% of beats: abstract ideas, metaphors, feelings, what happens inside "
            "the body or mind, or scenes stock footage cannot show. Give \"image_prompt\": ONE English sentence: subject + "
            "action + setting + mood (do NOT describe the art style — the studio adds it). Never ask for text, letters, "
            "logos, brands or real/famous people. Never more than 2 aiimage beats in a row. Still give visual + queries.")
    return prompts.render(
        "script", topic=project.topic, graphics=graphics, language_name=LANG_NAMES.get(project.language, project.language),
        scene_count=n, target_seconds=int(secs), total_chars=sum(budgets), budgets=desc,
        kw_per_scene=KW_PER_SCENE, extra=(f"Extra direction from the user: {extra}" if extra else ""),
    )


def write_script(llm: LLMProvider, project: Project, cfg, extra: str = "") -> list[str]:
    """เขียนบททั้งเรื่องแล้วใส่ลง project (แทนที่ฉากเดิมทั้งหมด) คืนรายการคำเตือน"""
    data = llm.generate_json(prompts.SYSTEM, build_prompt(project, cfg, extra))
    raw_scenes = data.get("scenes") if isinstance(data, dict) else data
    if not isinstance(raw_scenes, list) or not raw_scenes:
        raise ProviderError("AI ไม่ได้ส่งรายการฉากกลับมา")
    warnings: list[str] = []
    want = int(cfg["scene_count"])
    if len(raw_scenes) > want:        # เกินจำนวนที่ขอ: เก็บ hook + cta + ฉากกลางตามลำดับ
        mid = raw_scenes[1:-1][: max(0, want - 2)]
        raw_scenes = [raw_scenes[0], *mid, raw_scenes[-1]] if want >= 2 else raw_scenes[:1]
        warnings.append(f"AI เขียนเกินที่ขอ ตัดเหลือ {len(raw_scenes)} ฉาก")
    elif len(raw_scenes) < want:
        warnings.append(f"AI เขียนมา {len(raw_scenes)} ฉาก (ขอ {want}) — สั่งแก้ในแท็บ AI Editor เพื่อเพิ่มฉากได้")

    used: set[str] = set()
    scenes: list[Scene] = []
    n = len(raw_scenes)
    for i, r in enumerate(raw_scenes):
        r = r if isinstance(r, dict) else {}
        role = "hook" if i == 0 else "cta" if i == n - 1 and n > 1 else "body"
        beats = _parse_beats(r.get("beats"), used)
        if beats:
            text = " ".join(b["text"] for b in beats)
        else:                                       # AI ตอบแบบเก่า (narration + keywords) ก็ยังใช้ได้
            text = re.sub(r"\s+", " ", str(r.get("narration", ""))).strip()
        if not text:
            raise ProviderError(f"ฉากที่ {i + 1} ไม่มีบทพากย์")
        kws = [b["queries"][0] for b in beats] if beats else \
            _clean_keywords(r.get("keywords") or r.get("search_keyword"), used, project.topic)
        sc = project.new_scene(role=role, narration=text, keywords=kws, note=str(r.get("note", "")), beats=beats)
        ensure_beats(sc, project.topic)
        scenes.append(sc)
    project.scenes = scenes
    changed = enforce_graphics(project, cfg)
    if changed:
        warnings.append(f"ปรับภาพอธิบาย {changed} ช่วงกลับเป็นวิดีโอ (คุมจังหวะไม่ให้ซ้ำ/ติดกันเกิน)")
    if isinstance(data, dict):
        project.title = str(data.get("title") or project.title or project.topic)[:120]
        if data.get("music_prompt") and not project.music.prompt:
            project.music.prompt = str(data["music_prompt"]).strip()
    return warnings


def fit_duration(llm: LLMProvider, project: Project, cfg, target_seconds: float) -> list[int]:
    """ย่อ/ขยายบทของฉากต่างๆ ให้ความยาวรวมใกล้เป้า โดยอ้างอิงจากความยาวเสียงจริงที่วัดได้
    คืนรายการ scene id ที่บทเปลี่ยน"""
    tl = build_timeline(project, cfg)
    current = tl.speech_total
    if current <= 0 or not project.scenes:
        return []
    ratio = target_seconds / current
    scenes = []
    for s in project.scenes:
        c = count_chars(s.narration)
        scenes.append({"id": s.id, "role": s.role, "narration": s.narration,
                       "current_chars": c, "target_chars": max(8, round(c * ratio))})
    prompt = prompts.render(
        "fit", language_name=LANG_NAMES.get(project.language, project.language),
        current_seconds=f"{current:.1f}", target_seconds=f"{target_seconds:.1f}",
        scenes_json=json.dumps(scenes, ensure_ascii=False, indent=1),
    )
    data = llm.generate_json(prompts.SYSTEM, prompt)
    rows = data.get("scenes") if isinstance(data, dict) else data
    changed: list[int] = []
    for row in rows or []:
        try:
            s = project.scene(int(row["id"]))
        except (KeyError, ValueError, TypeError):
            continue
        new = re.sub(r"\s+", " ", str(row.get("narration", ""))).strip()
        if new and new != s.narration:
            s.narration = new
            ensure_beats(s, project.topic)          # แบ่ง beat ใหม่ตามสัดส่วนเดิม คงภาพ/คำค้นของแต่ละช่วงไว้
            changed.append(s.id)
    return changed
