"""Timeline กลางของคลิป — ทุกอย่าง (เสียง, ภาพ, ซับ, เพลง) อ้างอิงเวลาจากที่นี่ที่เดียว

ทุกจุดตัดถูกปัดให้ลงบน "เฟรม" พอดี เสียงกับภาพจึงไม่ค่อยๆ เหลื่อมกันเมื่อฉากเยอะ
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from ..core.models import Project, Scene

DEFAULT_CPS = {"th": 12.0, "en": 15.0}      # ตัวอักษร(ไม่นับช่องว่าง)/วินาที ก่อนวัดจากเสียงจริง
MIN_SHOT_SECONDS = 1.2
MIN_BEAT_SECONDS = 0.9      # ช็อตที่ตัดตามคำพูดสั้นได้ถึงเท่านี้ (สั้นกว่านี้ตาไม่ทัน → รวมกับช็อตก่อนหน้า)
ANTICIPATE = 0.05           # ตัดภาพก่อนคำแรกเล็กน้อย ให้ภาพ "มาพร้อม" เสียง (ตาเร็วกว่าหู)


def count_chars(text: str) -> int:
    return len("".join(text.split()))


def cps_for(project: Project) -> float:
    return project.measured_cps or DEFAULT_CPS.get(project.language, 13.0)


def char_budgets(project: Project, total_seconds: float, n: int) -> list[int]:
    """งบจำนวนตัวอักษรต่อฉาก: hook สั้นกระชับ, CTA ยาวหน่อย, ที่เหลือเฉลี่ย"""
    total = total_seconds * cps_for(project)
    if n == 1:
        return [round(total)]
    if n == 2:
        w = [0.45, 0.55]
    else:
        w = [0.16] + [(1 - 0.16 - 0.22) / (n - 2)] * (n - 2) + [0.22]
    return [max(12, round(total * x)) for x in w]


@dataclass
class Item:
    scene: Scene
    a_start: float        # เวลาเริ่มเสียงพากย์/ซับ ของฉากนี้ (วินาที)
    a_dur: float          # ความยาวช่องเสียงของฉาก (เสียง + เว้นจังหวะ)
    v_frames: int         # จำนวนเฟรมภาพของฉาก (ฉากแรกรวม lead-in, ฉากท้ายรวม tail)


@dataclass
class Timeline:
    fps: int
    items: list[Item] = field(default_factory=list)
    lead: float = 0.0
    tail: float = 0.0
    total_frames: int = 0

    @property
    def total(self) -> float:
        return self.total_frames / self.fps

    @property
    def speech_total(self) -> float:
        """ความยาวส่วนพากย์ล้วน (ไม่รวม lead/tail) — ใช้เทียบกับเป้าหมายของผู้ใช้"""
        return sum(i.a_dur for i in self.items)


def build_timeline(project: Project, cfg) -> Timeline:
    fps = int(cfg["fps"])
    lead_f = int(round(float(cfg["music.lead_in"]) * fps)) if cfg["music.provider"] != "none" else 0
    tail_f = int(round(float(cfg["music.tail"]) * fps))
    tl = Timeline(fps=fps, lead=lead_f / fps, tail=tail_f / fps)
    cum = lead_f
    n = len(project.scenes)
    for i, s in enumerate(project.scenes):
        pause = s.pause if s.pause is not None else float(cfg["scene_pause"])
        if i == n - 1:
            pause = max(pause, 0.0)
        slot_f = max(int(round(1.0 * fps)), math.ceil((s.audio_duration + pause) * fps))
        v_f = slot_f + (lead_f if i == 0 else 0) + (tail_f if i == n - 1 else 0)
        tl.items.append(Item(s, cum / fps, slot_f / fps, v_f))
        cum += slot_f
    tl.total_frames = cum + tail_f
    return tl


def plan_shots(frames: int, fps: int, max_shot_seconds: float) -> list[int]:
    """แบ่งฉากเป็นช็อต (หน่วยเฟรม) ความยาวใกล้เคียงกัน ไม่เกิน max_shot และไม่สั้นเกินไป"""
    secs = frames / fps
    n = max(1, round(secs / max_shot_seconds))
    n = max(1, min(n, int(secs // MIN_SHOT_SECONDS) or 1))
    base, extra = divmod(frames, n)
    return [base + (1 if i < extra else 0) for i in range(n)]


# ====================================================================== ช็อตตามจังหวะคำพูด
@dataclass
class ShotPlan:
    start_f: int          # เฟรมเริ่ม (นับจากต้นภาพของฉาก)
    frames: int
    beat: int             # เล่า beat ที่เท่าไร
    part: int             # beat ยาวถูกแบ่ง → ชิ้นที่เท่าไร
    first_word: int       # คำแรกที่ได้ยินในช็อตนี้ (-1 = ไม่มีข้อมูลคำ)


def scene_lead(tl: Timeline, index: int) -> float:
    """ภาพของฉากแรกเริ่มก่อนเสียงพูด (lead-in) — ฉากอื่นภาพกับเสียงเริ่มพร้อมกัน"""
    return tl.lead if index == 0 else 0.0


def plan_scene(item: Item, tl: Timeline, index: int, max_shot_seconds: float) -> list[ShotPlan]:
    """แบ่งภาพของฉากเป็นช็อต: ตัดเข้าช็อตใหม่ตรงคำแรกของแต่ละ beat, beat ที่ยาวเกินแบ่งย่อยที่ช่องว่างระหว่างคำ
    ทั้ง visuals และ render เรียกฟังก์ชันนี้ → ได้แผนเดียวกันเสมอ"""
    from .beats import beat_word_starts

    s, fps, total = item.scene, tl.fps, item.v_frames
    lead = scene_lead(tl, index)
    min_f = max(1, int(round(MIN_BEAT_SECONDS * fps)))
    words = s.words or []
    w_frames = [int(round((lead + w.start - ANTICIPATE) * fps)) for w in words]

    # 1) จุดเริ่มของแต่ละ beat (เฟรม)
    nb = max(1, len(s.beats))
    if nb == 1:
        starts = [(0, 0, 0)]
    elif words:
        ws = beat_word_starts(s)
        starts = [(0 if k == 0 else w_frames[ws[k]], k, ws[k]) for k in range(nb)]
    else:                                  # ยังไม่มีเวลาคำ → แบ่งตามสัดส่วนตัวอักษร
        lens = [max(1, count_chars(b.get("text", ""))) for b in s.beats]
        acc, starts = 0, []
        speech_f = int(round((lead + s.audio_duration) * fps)) or total
        for k, n in enumerate(lens):
            starts.append((0 if k == 0 else int(round(lead * fps + (speech_f - lead * fps) * acc / sum(lens))), k, -1))
            acc += n
    # 2) เรียง + ตัด beat ที่สั้นเกิน (ภาพของมันรวมไปกับช็อตก่อนหน้า)
    segs: list[list[int]] = []          # [start, beat, word]
    for st, k, w in starts:
        st = max(0, min(total, st))
        if segs and st - segs[-1][0] < min_f:
            continue
        segs.append([st, k, w])
    while len(segs) > 1 and total - segs[-1][0] < min_f:
        segs.pop()
    if not segs:
        segs = [[0, 0, 0 if words else -1]]
    segs[0][0] = 0
    # 3) แบ่ง beat ที่ยาวเกิน ณ ช่องว่างระหว่างคำที่ใกล้จุดแบ่งที่สุด
    max_f = max(min_f * 2, int(round(max_shot_seconds * fps)))
    plans: list[ShotPlan] = []
    for i, (st, k, w) in enumerate(segs):
        end = segs[i + 1][0] if i + 1 < len(segs) else total
        length = end - st
        is_graphic = k < len(s.beats) and s.beats[k].get("kind") in ("graphic", "aiimage")
        n = 1 if (length <= max_f * 1.3 or is_graphic) else math.ceil(length / max_f)   # ภาพอธิบายเล่นต่อเนื่อง ไม่แบ่ง
        cuts = [st]
        for j in range(1, n):
            target = st + length * j / n
            near = [(abs(f - target), f, wi) for wi, f in enumerate(w_frames)
                    if cuts[-1] + min_f <= f <= end - min_f and abs(f - target) <= 0.6 * fps]
            f = min(near)[1] if near else int(round(target))
            if f - cuts[-1] >= min_f and end - f >= min_f:
                cuts.append(f)
        for j, c in enumerate(cuts):
            e = cuts[j + 1] if j + 1 < len(cuts) else end
            fw = w if j == 0 else next((wi for wi, f in enumerate(w_frames) if f >= c), -1)
            plans.append(ShotPlan(c, e - c, k, j, fw))
    return plans


def shot_text(s: Scene, plan: list[ShotPlan], i: int) -> str:
    """ข้อความที่ได้ยินระหว่างช็อตที่ i (ไว้โชว์ในตัวตัดต่อ)"""
    if not s.words:
        return ""
    a = max(0, plan[i].first_word)
    nxt = [p.first_word for p in plan[i + 1:] if p.first_word > a]
    b = nxt[0] if nxt else len(s.words)
    return " ".join(w.text for w in s.words[a:b]) if a < b else ""
