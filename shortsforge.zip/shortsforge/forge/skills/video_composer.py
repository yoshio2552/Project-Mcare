"""ทักษะประกอบวิดีโอ: ปรับแต่ละช็อตเป็น 9:16 เท่ากันหมด (มีแคช) → ต่อกัน + เผาซับ + ใส่เสียงในรอบเข้ารหัสเดียว"""
from __future__ import annotations

import hashlib
from pathlib import Path

from ..core import ffmpeg
from ..core.errors import FFmpegError


def _sig(path: str) -> str:
    p = Path(path)
    st = p.stat()
    return f"{p.resolve()}|{st.st_size}|{int(st.st_mtime)}"


def render_shot(src: str, start: float, frames: int, out_dir: Path, *, width: int, height: int,
                fps: int, crf: int, preset: str) -> Path:
    """ครอปกลางให้เต็มกรอบแนวตั้ง, ล็อก fps, ตัดตามจำนวนเฟรมเป๊ะๆ — แคชด้วยลายนิ้วมือของอินพุต"""
    key = hashlib.sha1(f"{_sig(src)}|{start}|{frames}|{width}x{height}|{fps}|{crf}|{preset}".encode()).hexdigest()[:16]
    out = out_dir / f"shot_{key}.mp4"
    if out.exists() and out.stat().st_size > 1024:
        return out
    vf = (f"scale={width}:{height}:force_original_aspect_ratio=increase:flags=lanczos,"
          f"crop={width}:{height},setsar=1,fps={fps},format=yuv420p")
    tmp = out.with_suffix(".tmp.mp4")
    # -stream_loop -1: ถ้าคลิปต้นทางสั้นกว่าช็อต ให้วนต่อแทนที่จะค้างเฟรมสุดท้าย
    ffmpeg.run(["-stream_loop", "-1", "-ss", f"{start:.3f}", "-i", src, "-an", "-vf", vf,
                "-frames:v", str(frames), "-c:v", "libx264", "-preset", preset, "-crf", str(crf),
                "-pix_fmt", "yuv420p", "-r", str(fps), "-movflags", "+faststart", tmp])
    tmp.replace(out)
    return out


def _esc_filter_value(p: str) -> str:
    return p.replace("\\", "/").replace(":", r"\:").replace("'", r"\'")


def render_final(shots: list[Path], audio_wav: Path, out: Path, *, work: Path, total_frames: int, fps: int,
                 crf: int, preset: str, ass: Path | None = None, fonts_dir: Path | None = None) -> None:
    """ต่อช็อตทั้งหมด (stream copy ตอนต่อ) + เผาซับ + เสียง → mp4 ไฟล์เดียว"""
    work = Path(work).resolve()
    out = Path(out).resolve()
    work.mkdir(parents=True, exist_ok=True)
    listing = work / "shots.txt"
    listing.write_text("".join(f"file '{str(s.resolve()).replace(chr(39), chr(39) + chr(92) + chr(39) + chr(39))}'\n"
                               for s in shots), encoding="utf-8")
    cmd: list = ["-f", "concat", "-safe", "0", "-i", listing.name, "-i", str(audio_wav.resolve())]
    vf = []
    if ass is not None:
        a = f"ass=filename='{_esc_filter_value(ass.name)}'"
        if fonts_dir and Path(fonts_dir).exists():
            a += f":fontsdir='{_esc_filter_value(str(Path(fonts_dir).resolve()))}'"
        vf.append(a)
        if ass.parent.resolve() != work.resolve():
            raise FFmpegError("ไฟล์ซับต้องอยู่ในโฟลเดอร์ทำงานเดียวกับ shots.txt")
    if vf:
        cmd += ["-vf", ",".join(vf)]
    tmp = out.with_suffix(".tmp.mp4")
    cmd += ["-map", "0:v:0", "-map", "1:a:0", "-frames:v", str(total_frames),
            "-c:v", "libx264", "-preset", preset, "-crf", str(crf), "-pix_fmt", "yuv420p", "-r", str(fps),
            "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-shortest", "-movflags", "+faststart", tmp]
    ffmpeg.run(cmd, cwd=work, timeout=1800)
    tmp.replace(out)


def render_preview(shots: list[Path], audio: Path, out: Path, *, work: Path, lead: float, total_frames: int,
                   fps: int, crf: int, preset: str) -> None:
    """พรีวิวฉากเดียว: ต่อช็อต + เสียงพากย์ของฉาก (เลื่อนตาม lead) — ไม่ใส่ซับ/เพลง เพื่อความเร็ว"""
    work = Path(work).resolve()
    out = Path(out).resolve()
    work.mkdir(parents=True, exist_ok=True)
    listing = work / f"preview_{out.stem}.txt"
    listing.write_text("".join(f"file '{str(s.resolve()).replace(chr(39), chr(39) + chr(92) + chr(39) + chr(39))}'\n"
                               for s in shots), encoding="utf-8")
    ms = int(round(lead * 1000))
    af = (f"adelay={ms}:all=1," if ms > 0 else "") + "apad"
    tmp = out.with_suffix(".tmp.mp4")
    ffmpeg.run(["-f", "concat", "-safe", "0", "-i", listing.name, "-i", str(Path(audio).resolve()),
                "-map", "0:v:0", "-map", "1:a:0", "-af", af, "-frames:v", str(total_frames),
                "-t", f"{total_frames / fps:.3f}", "-c:v", "libx264", "-preset", preset, "-crf", str(crf),
                "-pix_fmt", "yuv420p", "-r", str(fps), "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", tmp],
               cwd=work, timeout=600)
    tmp.replace(out)
