"""ทักษะ "ตาของบรรณาธิการ": ให้ AI ดูภาพตัวอย่างคลิป (หรืออ่านชื่อ/แท็ก) เทียบกับประโยคที่กำลังพูด แล้วให้คะแนน 0–10

ทำไมต้องมี: คลังฟรีอย่าง Pexels/Pixabay ค้นด้วยคำแล้วได้ผลกว้างมาก อันดับแรกมักไม่ตรงความหมาย
ระบบจึงค้นมาหลายตัว → ให้ AI ตัดสินจากภาพจริง → เลือกตัวที่ตรงที่สุด

ทนทาน: AI ล่ม/ไม่มีรูป → คืนผลเท่าที่มี ระบบจะตกไปใช้คะแนนจากการเทียบคำแทน (ไม่ทำให้สเต็ปพัง)
ประหยัด: ผลตัดสินถูกแคชตาม (คลิป, ประโยค) — รันซ้ำไม่เสียโควตา AI
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

from ..core import ffmpeg, http
from ..core.errors import ForgeError
from ..providers.base import Clip, LLMProvider
from . import prompts

THUMB_WIDTH = 320
_STOP = {"the", "and", "with", "for", "from", "into", "onto", "over", "under", "near", "very", "some", "this", "that",
         "video", "stock", "footage", "shot", "clip", "background", "of", "on", "in", "at", "a", "an", "to", "is"}


def mode_for(cfg, llm: LLMProvider | None) -> str:
    m = str(cfg.get("stock.judge", "auto"))
    if m == "off" or llm is None:
        return "off"
    if m in ("auto", "vision"):
        return "vision" if llm.supports_vision else "text"
    return "text"


# ------------------------------------------------------------------ คะแนนจากการเทียบคำ (ไม่ใช้ AI)
def _words(t: str) -> set[str]:
    out = set()
    for w in re.split(r"[^a-z0-9]+", (t or "").lower()):
        if len(w) > 2 and w not in _STOP:
            out.add(w[:-1] if w.endswith("s") and len(w) > 4 else w)
    return out


def text_relevance(clip: Clip, query: str, visual: str = "") -> float:
    """0..1 — คำในชื่อ/แท็กของคลิปตรงกับคำค้น/ภาพที่ต้องการแค่ไหน"""
    want = _words(query) | _words(visual)
    have = _words(clip.title)
    if not want or not have:
        return 0.0
    return len(want & have) / len(want)


# ------------------------------------------------------------------ รูปตัวอย่าง
def _safe(key: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", key)[:120]


def thumbnail(clip: Clip, thumbs_dir: Path) -> bytes | None:
    """ภาพนิ่งขนาดเล็กของคลิป: โหลดภาพตัวอย่างจากแหล่ง หรือดึงเฟรมจากไฟล์ในเครื่อง — ไม่ได้ก็คืน None"""
    thumbs_dir.mkdir(parents=True, exist_ok=True)
    small = thumbs_dir / f"{_safe(clip.key)}_{THUMB_WIDTH}.jpg"
    if small.exists() and small.stat().st_size > 500:
        return small.read_bytes()
    src: Path | None = None
    try:
        if clip.local_path and Path(clip.local_path).exists():
            at = max(0.0, clip.duration * 0.4)
            ffmpeg.run(["-ss", f"{at:.2f}", "-i", clip.local_path, "-frames:v", "1",
                        "-vf", f"scale={THUMB_WIDTH}:-2", "-q:v", "4", small], timeout=60)
            return small.read_bytes() if small.exists() else None
        if not clip.preview_url.startswith(("http://", "https://")):
            return None
        src = thumbs_dir / f"{_safe(clip.key)}_src.jpg"
        if not src.exists():
            http.download(clip.preview_url, src, timeout=30)
        try:
            ffmpeg.run(["-i", src, "-frames:v", "1", "-vf", f"scale={THUMB_WIDTH}:-2", "-q:v", "4", small], timeout=60)
        except ForgeError:
            return src.read_bytes() if src.stat().st_size < 400_000 else None
        return small.read_bytes()
    except ForgeError:
        return None


# ------------------------------------------------------------------ ตัดสิน
def _cache_file(cache_dir: Path, mode: str, clip: Clip, beat_text: str, visual: str) -> Path:
    h = hashlib.sha1(f"{mode}|{clip.key}|{beat_text}|{visual}".encode()).hexdigest()[:20]
    return cache_dir / f"judge_{h}.json"


MAX_IMAGES_PER_CALL = 36     # ส่งรูปเยอะเกินในครั้งเดียว AI จะเริ่มสับสน — แบ่งเป็นหลายคำขอ


def judge(llm: LLMProvider, mode: str, clips: list[Clip], *, topic: str, language_name: str, scene_text: str,
          beat_text: str, visual: str, cache_dir: Path, thumbs_dir: Path, warn=lambda m: None) -> dict[str, tuple[float, str]]:
    """ตัดสินคลิปของช็อตเดียว — คืน {clip.key: (คะแนน 0–10, เหตุผล)}"""
    return judge_many(llm, mode, [(beat_text, visual, clips)], topic=topic, language_name=language_name,
                      scene_text=scene_text, cache_dir=cache_dir, thumbs_dir=thumbs_dir, warn=warn)[0]


def judge_many(llm: LLMProvider, mode: str, groups: list[tuple[str, str, list[Clip]]], *, topic: str,
               language_name: str, scene_text: str, cache_dir: Path, thumbs_dir: Path,
               warn=lambda m: None) -> list[dict[str, tuple[float, str]]]:
    """ตัดสินหลายช็อตในคำขอเดียว (ประหยัดโควตาฟรี: 1 คำขอต่อฉาก แทน 1 คำขอต่อช็อต)
    groups = [(ประโยคที่ได้ยิน, ภาพที่ต้องการ, คลิปตัวเลือก)] → คืน list ของ {clip.key: (คะแนน, เหตุผล)} ตามลำดับ group"""
    out: list[dict[str, tuple[float, str]]] = [{} for _ in groups]
    if mode == "off" or not groups:
        return out
    cache_dir.mkdir(parents=True, exist_ok=True)
    todo: list[tuple[int, Clip]] = []
    for gi, (beat_text, visual, clips) in enumerate(groups):
        for c in clips:
            f = _cache_file(cache_dir, mode, c, beat_text, visual)
            if f.exists():
                try:
                    d = json.loads(f.read_text(encoding="utf-8"))
                    out[gi][c.key] = (float(d["score"]), str(d.get("why", "")))
                    continue
                except (ValueError, KeyError, TypeError):
                    pass
            todo.append((gi, c))
    # แบ่งเป็นก้อน: ช็อตเดียวกันอยู่ก้อนเดียวกันเสมอ
    chunks: list[list[tuple[int, Clip]]] = []
    cur: list[tuple[int, Clip]] = []
    for gi in sorted({g for g, _ in todo}):
        items = [(g, c) for g, c in todo if g == gi]
        if cur and len(cur) + len(items) > MAX_IMAGES_PER_CALL:
            chunks.append(cur)
            cur = []
        cur += items
    if cur:
        chunks.append(cur)
    for chunk in chunks:
        images: list[bytes] = []
        ids: dict[str, tuple[int, Clip]] = {}
        blocks: list[str] = []
        letters = {}
        for gi, c in chunk:
            if gi not in letters:
                letters[gi] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"[len(letters) % 26]
                beat_text, visual, _ = groups[gi]
                blocks.append(f"SHOT {letters[gi]} — viewer hears: \"{beat_text}\" — intended picture: "
                              f"{visual or '(not specified — infer from the phrase)'}")
            n = sum(1 for k in ids if k.startswith(letters[gi])) + 1
            cid = f"{letters[gi]}{n}"
            img = thumbnail(c, thumbs_dir) if mode == "vision" else None
            tag = ""
            if img:
                images.append(img)
                tag = f"[image {len(images)}] "
            blocks.append(f"  {cid}. {tag}title/tags: {c.title or '(no title)'} · {c.duration:.0f}s · "
                          f"{'portrait' if c.portrait else 'landscape'}")
            ids[cid] = (gi, c)
        prompt = prompts.render("judge", topic=topic, language_name=language_name, scene_text=scene_text,
                                groups="\n".join(blocks))
        try:
            data = llm.generate_json(prompts.SYSTEM, prompt, images=images or None)
        except ForgeError as e:
            warn(f"AI ตรวจภาพไม่สำเร็จ ({e}) — ใช้การเทียบคำแทน")
            continue
        rows = data.get("scores") if isinstance(data, dict) else data
        for r in rows or []:
            try:
                gi, c = ids[str(r.get("id") or r.get("n")).strip().upper()]
                sc = max(0.0, min(10.0, float(r.get("score"))))
            except (ValueError, TypeError, KeyError, AttributeError):
                continue
            why = " ".join(str(r.get("why", "")).split())[:120]
            out[gi][c.key] = (sc, why)
            beat_text, visual, _ = groups[gi]
            _cache_file(cache_dir, mode, c, beat_text, visual).write_text(
                json.dumps({"score": sc, "why": why}, ensure_ascii=False), encoding="utf-8")
    return out
