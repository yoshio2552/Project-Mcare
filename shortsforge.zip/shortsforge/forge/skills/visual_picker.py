"""ทักษะเลือกคลิปภาพ: รวมผลจากทุกแหล่ง → ให้คะแนน → เลือกที่ดีที่สุดโดยไม่ซ้ำ"""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path

from ..core.errors import ConfigError, ForgeError
from ..core.registry import create, entries
from ..providers.base import Clip, StockProvider
from ..providers.stock._util import effective_width

CACHE_TTL = 24 * 3600


def usable_providers(cfg) -> tuple[list[StockProvider], list[str]]:
    """provider ที่เปิดใช้และพร้อมใช้งานตามลำดับ + ข้อความอธิบายตัวที่ข้ามไป"""
    ready: list[StockProvider] = []
    skipped: list[str] = []
    meta = {e.name: e for e in entries("stock")}
    for name in cfg["stock.providers"]:
        e = meta.get(name)
        if not e:
            skipped.append(f"{name}: ไม่มี provider นี้")
            continue
        missing = [k for k in e.needs_keys if not cfg.secret(k)]
        if missing:
            skipped.append(f"{e.label}: ยังไม่ได้ใส่ API key")
            continue
        ready.append(create("stock", name, cfg))
    return ready, skipped


def search_all(providers: list[StockProvider], query: str, per_page: int, cache_dir: Path,
               warn=lambda m: None) -> list[Clip]:
    """ค้นทุกแหล่ง (แคช 24 ชม. กันเปลือง rate limit) แล้วสลับผลลัพธ์ระหว่างแหล่งให้หลากหลาย"""
    per_provider: list[list[Clip]] = []
    for prov in providers:
        key = hashlib.sha1(f"{prov.name}|{query}|{per_page}".encode()).hexdigest()[:16]
        f = cache_dir / f"search_{key}.json"
        clips: list[Clip] | None = None
        if f.exists() and time.time() - f.stat().st_mtime < CACHE_TTL and prov.name != "local":
            try:
                clips = [Clip.from_dict(d) for d in json.loads(f.read_text(encoding="utf-8"))]
            except (json.JSONDecodeError, TypeError):
                clips = None
        if clips is None:
            try:
                clips = prov.search(query, per_page=per_page)
            except ForgeError as e:
                warn(f"{prov.name}: ค้น '{query}' ไม่สำเร็จ — {e}")
                clips = []
            else:
                if prov.name != "local":
                    f.write_text(json.dumps([c.to_dict() for c in clips], ensure_ascii=False), encoding="utf-8")
        per_provider.append(clips)
    merged: list[Clip] = []
    for i in range(max((len(x) for x in per_provider), default=0)):
        for lst in per_provider:
            if i < len(lst):
                merged.append(lst[i])
    return merged


def score(clip: Clip, need_seconds: float, cfg, used: dict[str, int], seed: str) -> float:
    eff = effective_width(clip.width, clip.height)
    s = 0.0
    s += 3.0 if clip.portrait else (0.6 if clip.width == clip.height else 0.0)
    s += min(eff, 1080.0) / 1080.0 * 2.0                       # คมกว่า = ดีกว่า (สูงสุด 2 คะแนน)
    if clip.duration >= need_seconds:
        s += 2.0
    elif clip.duration > 0:
        s += 2.0 * clip.duration / need_seconds - 1.0           # สั้นกว่าที่ต้องการ → โดนหัก
    if clip.duration and clip.duration < 1.5:
        s -= 3.0
    s -= 4.0 * used.get(clip.key, 0)                            # ใช้ซ้ำในคลิปนี้ → โดนหักหนัก
    names = list(cfg["stock.providers"])
    if clip.provider in names:
        s += 0.3 * (len(names) - names.index(clip.provider))   # ตามลำดับความสำคัญที่ผู้ใช้ตั้ง
    s += int(hashlib.md5((seed + clip.key).encode()).hexdigest()[:4], 16) / 65535 * 0.4   # สุ่มเล็กน้อยแต่คงที่
    return s


def rank(clips: list[Clip], need_seconds: float, cfg, used: dict[str, int], seed: str) -> list[Clip]:
    min_eff = float(cfg["stock.min_width"])
    ok = [c for c in clips if effective_width(c.width, c.height) >= min_eff or c.provider == "mock"]
    pool = ok or clips          # ถ้าไม่มีคลิปคมพอเลย ยอมใช้เท่าที่มีดีกว่าไม่มีภาพ
    seen: set[str] = set()
    uniq = [c for c in pool if not (c.key in seen or seen.add(c.key))]
    return sorted(uniq, key=lambda c: -score(c, need_seconds, cfg, used, seed))


def pick_start(clip: Clip, need_seconds: float, seed: str) -> float:
    """เริ่มตัดจากวินาทีไหนของคลิปต้นทาง — เลี่ยง 0.3 วินาทีแรก (มักเป็นช่วงปรับโฟกัส/เฟด) แบบคงที่ซ้ำได้"""
    slack = clip.duration - need_seconds
    if slack <= 0.4:
        return 0.0
    frac = int(hashlib.md5((seed + clip.key).encode()).hexdigest()[4:8], 16) / 65535
    return round(min(0.3 + frac * (slack - 0.3), slack), 2)


def require_providers(cfg) -> tuple[list[StockProvider], list[str]]:
    ready, skipped = usable_providers(cfg)
    if not ready:
        raise ConfigError("ไม่มีแหล่งภาพที่ใช้ได้ — ใส่ Pexels/Pixabay API key ในแท็บตั้งค่า "
                          "หรือวางคลิปไว้ใน assets/stock (" + "; ".join(skipped) + ")")
    return ready, skipped
