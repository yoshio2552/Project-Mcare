"""สเต็ปของ pipeline — เพิ่มสเต็ปใหม่ (เช่น thumbnail) = สร้างคลาส Step แล้วเพิ่มใน DEFAULT_STEPS
และประกาศตำแหน่ง/การพึ่งพาใน core/models.py (STEP_ORDER, DEPENDS)"""
from ..core.pipeline import Pipeline
from .captions import CaptionsStep
from .music import MusicStep
from .render import RenderStep
from .script import ScriptStep
from .visuals import VisualsStep
from .voice import VoiceStep

DEFAULT_STEPS = [ScriptStep, VoiceStep, VisualsStep, MusicStep, CaptionsStep, RenderStep]


def default_pipeline() -> Pipeline:
    return Pipeline([cls() for cls in DEFAULT_STEPS])
