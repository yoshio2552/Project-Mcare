"""สเต็ป 5: ซับไตเติล — สร้าง ASS (เผาลงวิดีโอ) และ SRT (ไว้อัปโหลดแยก)"""
from __future__ import annotations

from ..core.pipeline import Context, Step
from ..skills import captions
from ..skills.timing import build_timeline


class CaptionsStep(Step):
    name = "captions"
    config_keys = ("captions.enabled", "captions.font", "captions.size", "captions.color", "captions.highlight",
                   "captions.outline", "captions.margin_v", "captions.chunk_chars", "captions.karaoke",
                   "captions.pop", "resolution", "scene_pause", "music.lead_in", "music.tail", "music.provider", "fps")

    def run(self, ctx: Context) -> str:
        p, cfg = ctx.project, ctx.cfg
        if not cfg["captions.enabled"]:
            p.outputs.pop("ass", None)
            p.outputs.pop("srt", None)
            return "ปิดซับไตเติล"
        tl = build_timeline(p, cfg)
        w, h = (int(x) for x in str(cfg["resolution"]).split("x"))
        d = ctx.dir("renders")
        ass = d / "subs.ass"
        srt = d / "subs.srt"
        ass.write_text(captions.build_ass(tl, cfg, w, h), encoding="utf-8")
        srt.write_text(captions.build_srt(tl, cfg), encoding="utf-8")
        p.outputs["ass"], p.outputs["srt"] = str(ass), str(srt)
        n = len(captions.timeline_chunks(tl, int(cfg["captions.chunk_chars"])))
        return f"{n} บรรทัดซับ"
