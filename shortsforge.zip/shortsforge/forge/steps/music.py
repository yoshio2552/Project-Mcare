"""สเต็ป 4: เพลงประกอบ — สร้าง "ครั้งเดียวให้ยาวเผื่อ" เพื่อไม่เสียเครดิตทุกครั้งที่แก้บทนิดหน่อย"""
from __future__ import annotations

import math
from pathlib import Path

from ..core.models import MusicTrack, fingerprint
from ..core.pipeline import Context, Step
from ..skills.timing import build_timeline

HEADROOM = 4.0     # วินาทีเผื่อ — แก้บทให้ยาวขึ้นเล็กน้อยก็ยังใช้เพลงเดิมได้


def default_prompt(project) -> str:
    return (f"Modern, warm instrumental background music for a short vertical video about "
            f"\"{project.topic}\". Steady mid tempo, light percussion, no vocals.")


class MusicStep(Step):
    name = "music"
    config_keys = ("music.provider", "music.lead_in", "music.tail", "scene_pause", "fps")

    def run(self, ctx: Context) -> str:
        p, cfg = ctx.project, ctx.cfg
        provider_name = cfg["music.provider"]
        if provider_name == "none":
            p.music = MusicTrack(prompt=p.music.prompt)
            return "ไม่ใส่เพลง"
        tl = build_timeline(p, cfg)
        need = tl.total
        prompt = p.music.prompt.strip() or default_prompt(p)
        fp = fingerprint(provider_name, prompt)
        m = p.music
        if m.fp == fp and m.path and Path(m.path).exists() and m.duration >= need - 0.25:
            return f"ใช้เพลงเดิม ({m.duration:.0f} วินาที)"
        length = max(10.0, math.ceil((need + HEADROOM) / 5.0) * 5.0)
        ctx.emit("music", "running", "กำลังสร้าง/เลือกเพลง…", 0.3)
        prov = ctx.provider("music")
        out = ctx.dir("music") / f"music_{fp}_{int(length)}.mp3"
        res = prov.compose(prompt, length, out)
        p.music = MusicTrack(prompt=prompt, path=str(res.path), duration=res.duration,
                             provider=provider_name, fp=fp, meta=res.meta)
        return f"ได้เพลง {res.duration:.0f} วินาที ({provider_name})"
