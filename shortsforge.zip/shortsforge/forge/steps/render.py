"""สเต็ป 6: เรนเดอร์ — ช็อตที่ไม่เปลี่ยนมาจากแคช ทำให้แก้เล็กน้อยแล้วเรนเดอร์ซ้ำเร็วมาก"""
from __future__ import annotations

import shutil
from pathlib import Path

from ..core import ffmpeg
from ..core.errors import ForgeError
from ..core.models import fingerprint
from ..core.pipeline import Context, Step
from ..skills import audio_mixer, video_composer
from ..skills import beats as beatlib
from ..skills.timing import build_timeline, plan_scene

FONTS_DIR = Path(__file__).resolve().parents[2] / "assets" / "fonts"


class RenderStep(Step):
    name = "render"
    config_keys = ("music.volume_db", "music.duck_db", "music.fade_in", "music.fade_out", "render.target_lufs",
                   "render.crf", "render.preset", "resolution", "fps", "captions.enabled", "music.provider")

    def run(self, ctx: Context) -> str:
        ffmpeg.require_ffmpeg()
        p, cfg = ctx.project, ctx.cfg
        tl = build_timeline(p, cfg)
        w, h = (int(x) for x in str(cfg["resolution"]).split("x"))
        fps, crf, preset = tl.fps, int(cfg["render.crf"]), str(cfg["render.preset"])
        shot_cache = ctx.store.cache_dir("shots")
        work = ctx.dir("renders") / "work"
        work.mkdir(parents=True, exist_ok=True)

        # ---- 1) ช็อตภาพ ----
        shots: list[Path] = []
        total_shots = sum(len(i.scene.shots) for i in tl.items)
        done = 0
        for si, item in enumerate(tl.items):
            s = item.scene
            beatlib.ensure_beats(s, p.topic)
            frames = [x.frames for x in plan_scene(item, tl, si, float(cfg["max_shot_seconds"]))]
            if len(s.shots) != len(frames) or any(not sh.path or not Path(sh.path).exists() for sh in s.shots):
                raise ForgeError(f"ภาพของฉาก {p.index_of(s.id) + 1} ยังไม่ตรงกับจุดตัดล่าสุด — ทำสเต็ป 'หาภาพ' ก่อน")
            for sh, nfr in zip(s.shots, frames):
                ctx.cancel.check()
                ctx.emit("render", "running", f"เข้ารหัสช็อต {done + 1}/{total_shots}", 0.05 + 0.5 * done / total_shots)
                sh.duration = nfr / fps
                shots.append(video_composer.render_shot(sh.path, sh.start, nfr, shot_cache, width=w, height=h,
                                                        fps=fps, crf=crf, preset=preset))
                done += 1

        # ---- 2) เสียง ----
        ctx.emit("render", "running", "มิกซ์เสียงพากย์ + เพลง", 0.6)
        voice = work / "voice.wav"
        audio_mixer.build_voice_track(tl, voice)
        bed = None
        if cfg["music.provider"] != "none" and p.music.path and Path(p.music.path).exists():
            bed = work / "bed.wav"
            audio_mixer.build_music_bed(p.music.path, tl.total, bed, float(cfg["music.fade_in"]),
                                        float(cfg["music.fade_out"]))
        master = work / "master.wav"
        stats = audio_mixer.mix_and_master(voice, bed, tl, cfg, master)

        # ---- 3) ประกอบ ----
        ctx.emit("render", "running", "ประกอบวิดีโอ + เผาซับ", 0.75)
        ass_src = p.outputs.get("ass") if cfg["captions.enabled"] else None
        ass = None
        if ass_src and Path(ass_src).exists():
            ass = work / "subs.ass"
            shutil.copyfile(ass_src, ass)
        fp = fingerprint([str(s) for s in shots], p.music.fp, cfg["music.volume_db"], cfg["music.duck_db"],
                         cfg["render.target_lufs"], ass and Path(ass).read_text(encoding="utf-8"),
                         [(i.scene.audio_path, i.a_start) for i in tl.items])
        out = ctx.dir("renders") / f"final_{fp}.mp4"
        if not out.exists():
            video_composer.render_final(shots, master, out, work=work, total_frames=tl.total_frames, fps=fps,
                                        crf=crf, preset=preset, ass=ass, fonts_dir=FONTS_DIR)
        info = ffmpeg.probe(out)
        p.outputs["video"] = str(out)
        p.outputs["credits"] = self._credits(p)
        (ctx.dir("renders") / "credits.txt").write_text(p.outputs["credits"], encoding="utf-8")
        lufs = stats.get("measured_lufs")
        return (f"{info['width']}×{info['height']} {info['duration']:.1f} วินาที"
                + (f" — ความดังก่อน master {float(lufs):.1f} LUFS → {stats['target_lufs']}" if lufs else ""))

    @staticmethod
    def _credits(p) -> str:
        seen: dict[str, str] = {}
        for s in p.scenes:
            for sh in s.shots:
                c = sh.clip or {}
                if c.get("credit") and c.get("provider") != "mock":
                    key = c["credit"] if c.get("provider") == "aiimage" else f"{c['provider']}:{c['id']}"
                    seen[key] = f"{c['credit']} — {c.get('page_url', '')}".strip(" —")
        return "\n".join(sorted(set(seen.values())))
