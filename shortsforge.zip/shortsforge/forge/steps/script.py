"""สเต็ป 1: เขียนบท"""
from __future__ import annotations

from ..core.errors import ConfigError
from ..core.pipeline import Context, Step
from ..skills import script_writer


class ScriptStep(Step):
    name = "script"

    def run(self, ctx: Context) -> str:
        p = ctx.project
        if not p.topic.strip():
            raise ConfigError("ยังไม่ได้ใส่หัวข้อคลิป")
        llm = ctx.provider("llm")
        extra = p.outputs.pop("script_extra", "")
        ctx.emit("script", "running", "กำลังให้ AI เขียนบท…", 0.2)
        warnings = script_writer.write_script(llm, p, ctx.cfg, extra)
        p.outputs["fit_pending"] = True          # หลังวัดเสียงจริงครั้งแรก ให้ปรับความยาวบทให้พอดีเป้า 1 รอบ
        # บทใหม่ทั้งชุด → ผลลัพธ์ที่เคยสร้างไว้ล้าสมัยทั้งหมด
        p.invalidate("voice", "บทถูกเขียนใหม่")
        msg = f"ได้ {len(p.scenes)} ฉาก"
        if warnings:
            msg += " — " + "; ".join(warnings)
        return msg
