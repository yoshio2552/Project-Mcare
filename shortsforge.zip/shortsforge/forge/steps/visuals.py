"""สเต็ป 3: หาภาพ — ตัดช็อตตามจังหวะคำพูด แล้วหาคลิปที่ "ตรงกับประโยคที่กำลังพูด" ในแต่ละช็อต

ต่อ 1 beat (ช่วงพูดสั้นๆ):
  1) ค้นด้วยคำค้นเจาะจงก่อน ได้น้อยค่อยถอยไปคำที่กว้างขึ้น (ค้นจากทุกแหล่งที่เปิด)
  2) คัดตามคุณภาพ (แนวตั้ง/ความคม/ความยาว/ไม่ซ้ำ) เหลือตัวท็อป
  3) ให้ AI ดูภาพตัวอย่าง (หรืออ่านชื่อ/แท็ก) เทียบกับประโยคนั้น ให้คะแนน 0–10 — ถ้าไม่มีตัวไหนตรงเลย ค้นคำที่เหลือเพิ่ม
  4) เลือกตัวที่ได้คะแนนรวมสูงสุด โหลดไม่ได้ก็ไล่ตัวถัดไป
ช็อตที่ผู้ใช้ปักหมุด/ช็อตเดิมที่คำค้นไม่เปลี่ยน → ใช้คลิปเดิม (แค่ปรับความยาว) ไม่ค้นใหม่ ไม่เสียโควตา
"""
from __future__ import annotations

from pathlib import Path

from ..core.errors import ForgeError
from ..core.models import Scene, Shot, fingerprint
from ..core.pipeline import Context, Step
from ..providers.base import Clip
from ..providers.stock._util import effective_width
from ..skills import aiimage as aiimg
from ..skills import beats as beatlib
from ..skills import graphics as gx
from ..skills import visual_judge as vj
from ..skills import visual_picker as vp
from ..skills.script_writer import LANG_NAMES
from ..skills.timing import ShotPlan, build_timeline, plan_scene

GOOD_ENOUGH = 6.0          # คะแนน AI ที่ถือว่า "ตรงพอ" ไม่ต้องค้นคำที่กว้างกว่าเพิ่ม


def clip_path(ctx: Context, clip: Clip) -> Path:
    return ctx.store.cache_dir("clips") / f"{clip.provider}_{clip.id.replace('/', '_').replace(chr(92), '_')}.mp4"


def fetch_clip(ctx: Context, providers_by_name: dict, clip: Clip) -> str:
    """ดาวน์โหลดคลิป (ถ้ายังไม่มีในแคช) คืน path"""
    prov = providers_by_name.get(clip.provider)
    if prov is None:
        from ..core import registry
        prov = registry.create("stock", clip.provider, ctx.cfg)
    if clip.provider == "local":
        return str(prov.download(clip, Path()))
    dest = clip_path(ctx, clip)
    if dest.exists() and dest.stat().st_size > 1024:
        return str(dest)
    return str(prov.download(clip, dest))


def start_for(clip: Clip, dur: float, seed: str, prev: Shot | None) -> float:
    """จุดเริ่มในคลิปต้นทาง: คลิปเดิม → คงจุดเดิมไว้ถ้ายังพอ (ผู้ใช้เลื่อนเองไว้ = บีบให้อยู่ในช่วงที่ใช้ได้), คลิปใหม่ → ระบบเลือก"""
    same = prev is not None and (prev.clip or {}).get("id") == clip.id and (prev.clip or {}).get("provider") == clip.provider
    room = max(0.0, clip.duration - dur)
    if same and prev.start_locked:
        return round(max(0.0, min(prev.start, room)), 2)
    if same and prev.start <= room:
        return prev.start
    return vp.pick_start(clip, dur, seed)


class VisualsStep(Step):
    name = "visuals"
    config_keys = ("stock.providers", "stock.min_width", "stock.candidates", "max_shot_seconds", "scene_pause",
                   "fps", "music.lead_in", "music.tail", "music.provider", "stock.judge", "stock.judge_top",
                   "graphics.enabled", "graphics.palette", "graphics.font", "resolution", "captions.font",
                   "image.provider", "image.style", "image.style_custom", "image.motion", "image.fit",
                   "cloudflare.image_model", "cloudflare.steps", "gemini.image_model")

    def run(self, ctx: Context) -> str:
        p, cfg = ctx.project, ctx.cfg
        providers, skipped = vp.require_providers(cfg)
        warns: list[str] = []
        llm, mode = None, "off"
        if cfg.get("stock.judge", "auto") != "off":
            try:
                llm = ctx.provider("llm")
                llm.light = True                    # ตรวจภาพเรียกบ่อย → ใช้รุ่น Lite (โควตาฟรีเยอะกว่า)
                mode = vj.mode_for(cfg, llm)
            except ForgeError as e:
                warns.append(f"ไม่ได้ให้ AI ตรวจภาพ ({e})")
        env = {
            "providers": providers, "by_name": {pr.name: pr for pr in providers}, "llm": llm, "mode": mode,
            "search": ctx.store.cache_dir("search"), "judge": ctx.store.cache_dir("judge"),
            "thumbs": ctx.store.cache_dir("thumbs"), "warns": warns,
        }
        tl = build_timeline(p, cfg)
        used: dict[str, int] = {}
        for s in p.scenes:                      # คลิปที่ผู้ใช้ปักหมุดไว้ นับเป็น "ใช้แล้ว" ก่อนเริ่ม
            for sh in s.shots:
                if sh.pinned and sh.clip:
                    k = f"{sh.clip['provider']}:{sh.clip['id']}"
                    used[k] = used.get(k, 0) + 1
        redone = 0
        n = len(tl.items)
        for si, item in enumerate(tl.items):
            ctx.cancel.check()
            s = item.scene
            beatlib.ensure_beats(s, p.topic)
            plans = plan_scene(item, tl, si, float(cfg["max_shot_seconds"]))
            fp = fingerprint([(b["queries"], b.get("kind"), b.get("graphic"), b.get("image_prompt"), b.get("seed"))
                              for b in s.beats],
                             [(x.frames, x.beat, x.part) for x in plans],
                             list(cfg["stock.providers"]), cfg["stock.min_width"], s.avoid, mode,
                             cfg.get("stock.judge_top"),
                             [((sh.clip or {}).get("id"), sh.start) for sh in s.shots if sh.pinned or sh.start_locked])
            if s.fp.get("visual") == fp and len(s.shots) == len(plans) and all(
                    sh.path and Path(sh.path).exists() for sh in s.shots):
                for sh in s.shots:
                    if sh.clip and not sh.pinned:
                        k = f"{sh.clip['provider']}:{sh.clip['id']}"
                        used[k] = used.get(k, 0) + 1
                continue
            ctx.emit("visuals", "running", f"ฉาก {si + 1}/{n}: จัดภาพ {len(plans)} ช็อตตามจังหวะคำพูด", si / n, s.id)
            self._build_scene(ctx, env, s, si, n, plans, tl.fps, used)
            s.fp["visual"] = fp
            redone += 1
            ctx.save()
        judge_note = {"vision": "AI ดูภาพตัวอย่าง", "text": "AI อ่านชื่อ/แท็กคลิป", "off": "ไม่ใช้ AI ตรวจ"}[mode]
        msg = f"จัดภาพใหม่ {redone}/{n} ฉาก ({judge_note})"
        if skipped:
            msg += " — ข้าม: " + "; ".join(skipped)
        if warns:
            msg += " — " + "; ".join(list(dict.fromkeys(warns))[:3])
        return msg

    # ------------------------------------------------------------------ ฉาก
    def _build_scene(self, ctx: Context, env: dict, s: Scene, si: int, n: int, plans: list[ShotPlan], fps: int,
                     used: dict) -> None:
        p = ctx.project
        old = {(sh.beat, sh.part): sh for sh in s.shots}
        by_kw: dict[tuple[str, int], list[Shot]] = {}     # หลังเพิ่ม/ลบจุดตัด ลำดับ beat เลื่อน → จับคู่ด้วยคำค้นแทน
        for sh in s.shots:
            by_kw.setdefault((sh.keyword, sh.part), []).append(sh)
        taken: set[int] = set()
        new_shots: list[Shot | None] = []
        pending: list[tuple[int, ShotPlan, Shot | None]] = []     # ช็อตที่ต้องหาคลิปใหม่: (ตำแหน่ง, แผน, ช็อตเดิม)
        # ---- รอบ 1: ช็อตที่ใช้ของเดิม/ภาพอธิบายได้ ทำเลย ที่เหลือจดไว้ ----
        for i, pl in enumerate(plans):
            ctx.cancel.check()
            dur = pl.frames / fps
            beat = s.beats[pl.beat] if pl.beat < len(s.beats) else {}
            queries = list(beat.get("queries") or s.keywords or [p.topic])
            if beat.get("kind") == "graphic" and beat.get("graphic") and ctx.cfg.get("graphics.enabled", True):
                try:
                    new_shots.append(self._graphic_shot(ctx, beat["graphic"], pl, dur))
                    continue
                except (ForgeError, KeyError) as e:          # วาดไม่ได้ (เช่นฟอนต์หาย) → ใช้วิดีโอแทน ไม่ให้ทั้งสเต็ปพัง
                    env["warns"].append(f"ภาพอธิบายฉาก {si + 1} วาดไม่สำเร็จ ใช้วิดีโอแทน ({e})")
            if beat.get("kind") == "aiimage" and beat.get("image_prompt") and aiimg_ok(ctx):
                try:
                    ctx.emit("visuals", "running", f"ฉาก {si + 1}/{n}: สร้างภาพ AI “{beat['image_prompt'][:40]}”",
                             si / n, s.id)
                    new_shots.append(self._aiimage_shot(ctx, beat, pl, dur, i))
                    continue
                except (ForgeError, KeyError) as e:          # โควตาหมด/บริการล่ม → ใช้วิดีโอแทน
                    env["warns"].append(f"ภาพ AI ฉาก {si + 1} ไม่สำเร็จ ใช้วิดีโอแทน ({e})")
            prev = old.get((pl.beat, pl.part))
            if prev is None or id(prev) in taken or prev.keyword != queries[0]:
                alt = next((x for x in by_kw.get((queries[0], pl.part), []) if id(x) not in taken), None)
                prev = alt if alt is not None else (None if prev is not None and prev.pinned else prev)
            seed = f"{p.id}{s.id}{pl.beat}{pl.part}"
            if prev and id(prev) not in taken and prev.clip and prev.path and Path(prev.path).exists() \
                    and prev.clip.get("provider") not in ("graphic", "aiimage"):
                key = f"{prev.clip['provider']}:{prev.clip['id']}"
                if prev.pinned or (prev.keyword == queries[0] and key not in s.avoid):
                    taken.add(id(prev))
                    clip = Clip.from_dict(prev.clip)          # คลิปเดิมยังใช้ได้ → แค่ปรับความยาว/จุดเริ่ม
                    new_shots.append(Shot(prev.keyword, prev.clip, prev.path, start_for(clip, dur, seed, prev), dur,
                                          prev.pinned, pl.beat, pl.part, prev.start_locked, prev.score, prev.why))
                    if not prev.pinned:
                        used[key] = used.get(key, 0) + 1
                    continue
            pending.append((len(new_shots), pl, prev))
            new_shots.append(None)
        if not pending:
            s.shots = [x for x in new_shots if x is not None]
            return
        # ---- รอบ 2: ค้นทุก beat ที่ต้องใช้ แล้วให้ AI ตรวจทั้งฉากในคำขอเดียว ----
        searches: dict[int, _BeatSearch] = {}
        for _, pl, _ in pending:
            if pl.beat not in searches:
                beat = s.beats[pl.beat] if pl.beat < len(s.beats) else {}
                queries = list(beat.get("queries") or s.keywords or [p.topic])
                ctx.emit("visuals", "running", f"ฉาก {si + 1}/{n}: ค้น “{queries[0]}”", si / n, s.id)
                bs = _BeatSearch(ctx, env, s, beat, queries, pl.frames / fps, f"{p.id}{s.id}{pl.beat}")
                bs.initial()
                searches[pl.beat] = bs
        if env["mode"] != "off":
            self._judge_round(ctx, env, s, si, n, list(searches.values()), used)
            weak = [b for b in searches.values() if b.best() < GOOD_ENOUGH and b.more()]
            if weak:                                  # ไม่มีตัวไหนตรงพอ → ค้นคำที่กว้างกว่าแล้วตรวจอีกรอบ (รวมคำขอเดียว)
                for b in weak:
                    b.more_search()
                self._judge_round(ctx, env, s, si, n, weak, used)
        # ---- รอบ 3: เลือกตามลำดับช็อต (ไม่ซ้ำคลิปกัน) ----
        for pos, pl, prev in pending:
            dur = pl.frames / fps
            bs = searches[pl.beat]
            pool = bs.rows(used)
            order = [x for x in pool if x[0].key not in s.avoid and not used.get(x[0].key)] + \
                [x for x in pool if x[0].key not in s.avoid and used.get(x[0].key)] + \
                [x for x in pool if x[0].key in s.avoid]
            chosen, path = None, ""
            for c, total, ai, why in order[:5]:              # โหลดไม่สำเร็จก็ลองตัวถัดไป
                try:
                    path = fetch_clip(ctx, env["by_name"], c)
                    chosen = (c, ai, why)
                    break
                except ForgeError as e:
                    env["warns"].append(f"โหลด {c.key} ไม่สำเร็จ: {e}")
            if chosen is None:
                raise ForgeError(f"โหลดคลิปของ “{bs.queries[0]}” ไม่สำเร็จเลย ลองใหม่อีกครั้ง")
            c, ai, why = chosen
            used[c.key] = used.get(c.key, 0) + 1
            seed = f"{p.id}{s.id}{pl.beat}{pl.part}"
            new_shots[pos] = Shot(bs.queries[0], c.to_dict(), path, start_for(c, dur, seed, prev), dur, False,
                                  pl.beat, pl.part, False, ai, why)
        s.shots = [x for x in new_shots if x is not None]
        chosen_keys = {f"{sh.clip['provider']}:{sh.clip['id']}" for sh in s.shots if sh.clip}
        cands: dict[str, dict] = {}
        for bs in searches.values():
            for c, total, ai, why in bs.rows(used):
                if c.key not in chosen_keys and c.key not in cands:
                    cands[c.key] = {**c.to_dict(), "ai_score": ai, "ai_why": why, "rank": round(total, 2)}
        s.candidates = sorted(cands.values(), key=lambda d: -d["rank"])[:24]

    @staticmethod
    def _judge_round(ctx: Context, env: dict, s: Scene, si: int, n: int, items: list["_BeatSearch"], used: dict) -> None:
        groups, owners = [], []
        for b in items:
            top = b.to_judge(used)
            if top:
                groups.append((b.beat.get("text", s.narration), b.beat.get("visual", ""), top))
                owners.append(b)
        if not groups:
            return
        total = sum(len(g[2]) for g in groups)
        ctx.emit("visuals", "running", f"ฉาก {si + 1}/{n}: AI กำลังดูคลิป {total} ตัว ({len(groups)} ช็อต ในคำขอเดียว)",
                 si / n, s.id)
        p = ctx.project
        res = vj.judge_many(env["llm"], env["mode"], groups, topic=p.topic,
                            language_name=LANG_NAMES.get(p.language, p.language), scene_text=s.narration,
                            cache_dir=env["judge"], thumbs_dir=env["thumbs"], warn=env["warns"].append)
        for b, v in zip(owners, res):
            b.verdicts.update(v)

    # ------------------------------------------------------------------ ภาพ AI
    @staticmethod
    def _aiimage_shot(ctx: Context, beat: dict, pl: ShotPlan, dur: float, index: int) -> Shot:
        cfg = ctx.cfg
        w, h = (int(x) for x in str(cfg["resolution"]).split("x"))
        prov = ctx.provider("image")
        video, img = aiimg.make_clip(prov, beat, cfg, ctx.store.cache_dir("aiimages"), width=w, height=h,
                                     fps=int(cfg["fps"]), frames=pl.frames, index=index,
                                     preset=str(cfg["render.preset"]), crf=int(cfg["render.crf"]))
        clip = {"provider": "aiimage", "id": img.stem, "download_url": "", "title": beat["image_prompt"][:80],
                "duration": round(dur + 0.001, 3), "width": w, "height": h, "credit": prov.credit,
                "image": str(img)}
        return Shot("aiimage", clip, str(video), 0.0, dur, False, pl.beat, pl.part, False, None, "")

    # ------------------------------------------------------------------ ภาพอธิบาย
    @staticmethod
    def _graphic_shot(ctx: Context, graphic: dict, pl: ShotPlan, dur: float) -> Shot:
        from .render import FONTS_DIR
        cfg, p = ctx.cfg, ctx.project
        w, h = (int(x) for x in str(cfg["resolution"]).split("x"))
        name = graphic["template"]
        path = gx.render(name, graphic["data"], ctx.store.cache_dir("graphics"), width=w, height=h,
                         fps=int(cfg["fps"]), frames=pl.frames, palette=gx.palette_for(str(cfg.get("graphics.palette", "auto")), p.id),
                         font=str(cfg.get("graphics.font") or cfg["captions.font"]), lang=p.language, fonts_dir=FONTS_DIR,
                         preset=str(cfg["render.preset"]), crf=int(cfg["render.crf"]))
        clip = {"provider": "graphic", "id": path.stem, "download_url": "", "title": gx.get(name).label,
                "duration": round(dur + 0.001, 3), "width": w, "height": h, "template": name}
        return Shot(f"graphic:{name}", clip, str(path), 0.0, dur, False, pl.beat, pl.part, False, None, "")



def aiimg_ok(ctx: Context) -> bool:
    return str(ctx.cfg.get("image.provider", "none")) not in ("", "none")


class _BeatSearch:
    """ผลค้นของ 1 beat: ค้นคำเจาะจงก่อน ได้น้อยค่อยถอยกว้าง + เก็บคะแนนจาก AI"""

    def __init__(self, ctx: Context, env: dict, s: Scene, beat: dict, queries: list[str], dur: float, seed: str):
        self.ctx, self.env, self.s, self.beat, self.queries, self.dur, self.seed = ctx, env, s, beat, queries, dur, seed
        self.found: dict[str, tuple[Clip, int]] = {}
        self.searched = 0
        self.verdicts: dict[str, tuple[float, str]] = {}
        cfg = ctx.cfg
        self.per_page = int(cfg["stock.candidates"])
        self.top = int(cfg.get("stock.judge_top", 6))
        self.min_w = float(cfg["stock.min_width"])

    def _search(self, q: str, qi: int) -> None:
        for c in vp.search_all(self.env["providers"], q, self.per_page, self.env["search"], warn=self.env["warns"].append):
            self.found.setdefault(c.key, (c, qi))

    def usable(self) -> int:
        return sum(1 for c, _ in self.found.values() if c.key not in self.s.avoid and
                   (effective_width(c.width, c.height) >= self.min_w or c.provider == "mock"))

    def initial(self) -> None:
        while self.searched < len(self.queries) and (self.searched == 0 or self.usable() < self.top):
            self._search(self.queries[self.searched], self.searched)
            self.searched += 1
        if not self.found:
            topic = self.ctx.project.topic
            self._search(topic, len(self.queries))
            self.env["warns"].append(f"“{self.queries[0]}” ไม่มีผลค้นหา ใช้ภาพจากหัวข้อหลักแทน")
        if not self.found:
            raise ForgeError(f"หาคลิปไม่เจอสำหรับ “{self.queries[0]}” เลย — แก้คำค้นของฉากนี้ หรือเพิ่มแหล่งภาพ")

    def more(self) -> bool:
        return self.searched < len(self.queries)

    def more_search(self) -> None:
        while self.more():
            self._search(self.queries[self.searched], self.searched)
            self.searched += 1

    def best(self) -> float:
        return max((v[0] for v in self.verdicts.values()), default=0.0)

    def to_judge(self, used: dict) -> list[Clip]:
        cfg = self.ctx.cfg
        return [c for c in vp.rank([c for c, _ in self.found.values()], self.dur, cfg, used, self.seed)
                if c.key not in self.s.avoid and c.key not in self.verdicts][: self.top]

    def rows(self, used: dict) -> list[tuple[Clip, float, float | None, str]]:
        """[(คลิป, คะแนนรวม, คะแนน AI, เหตุผล)] เรียงจากดีสุด"""
        cfg = self.ctx.cfg
        visual = self.beat.get("visual", "")
        out = []
        for c in vp.rank([c for c, _ in self.found.values()], self.dur, cfg, used, self.seed):
            qi = self.found[c.key][1]
            tech = vp.score(c, self.dur, cfg, used, self.seed)
            if c.key in self.verdicts:
                ai, why = self.verdicts[c.key]
                rel = ai * 1.2                                  # ความตรงบริบทสำคัญกว่าความคม/ความยาว
            else:
                ai, why = None, ""
                rel = vj.text_relevance(c, self.queries[min(qi, len(self.queries) - 1)], visual) * 5.0
                if self.verdicts:                               # ตัวอื่นผ่านการตรวจแล้ว ตัวที่ไม่ได้ตรวจเสี่ยงกว่า
                    rel -= 1.0
            prior = max(0, 2 - qi) * 0.5                        # มาจากคำค้นที่เจาะจงกว่า = น่าจะตรงกว่า
            out.append((c, tech + rel + prior, ai, why))
        out.sort(key=lambda r: -r[1])
        return out
