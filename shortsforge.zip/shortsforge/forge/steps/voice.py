"""สเต็ป 2: เสียงพากย์ — ฉากที่บท/ค่าเสียงไม่เปลี่ยนจะไม่ถูกพากย์ซ้ำ (ไม่เสียเครดิต)"""
from __future__ import annotations

from pathlib import Path

from ..core.errors import ForgeError
from ..core.models import Scene, Word, fingerprint
from ..core.pipeline import Context, Step
from ..skills import script_writer
from ..skills.timing import build_timeline, count_chars

TOLERANCE_LOW, TOLERANCE_HIGH = 0.90, 1.12     # ยาวรวมอยู่ในช่วง 90%–112% ของเป้า ถือว่าพอดี


class VoiceStep(Step):
    name = "voice"
    config_keys = ("tts.provider", "tts.speed", "elevenlabs.model", "elevenlabs.voice_id", "elevenlabs.stability",
                   "elevenlabs.similarity", "edge.voice")

    def run(self, ctx: Context) -> str:
        p = ctx.project
        if not p.scenes:
            raise ForgeError("ยังไม่มีบท — ทำสเต็ปเขียนบทก่อน")
        tts = ctx.provider("tts")
        made = self._synthesize_all(ctx, tts)
        self._measure(ctx)
        note = ""
        if p.outputs.pop("fit_pending", False) and ctx.cfg.get("auto_fit", True):
            note = self._auto_fit(ctx, tts)
        tl = build_timeline(p, ctx.cfg)
        return f"พากย์ใหม่ {made}/{len(p.scenes)} ฉาก — ยาวรวม {tl.speech_total:.1f} วินาที{note}"

    # ---------------------------------------------------------------
    def _synthesize_all(self, ctx: Context, tts) -> int:
        p = ctx.project
        made = 0
        audio_dir = ctx.dir("audio")
        n = len(p.scenes)
        for i, s in enumerate(p.scenes):
            ctx.cancel.check()
            if not s.narration.strip():
                raise ForgeError(f"ฉากที่ {i + 1} ไม่มีบทพากย์ — พิมพ์บทหรือลบฉากนี้")
            fp = fingerprint(s.narration, p.language, tts.fingerprint_parts())
            path = audio_dir / f"s{s.id}_{fp}.mp3"
            if s.fp.get("voice") == fp and path.exists() and s.words:
                s.audio_path = str(path)          # (undo อาจชี้กลับมาที่ไฟล์เก่า)
                continue
            if path.exists() and s.fp.get("voice") != fp and self._load_sidecar(s, path, fp):
                continue                          # ไฟล์เสียงนี้เคยสร้างไว้ (เช่นหลัง undo) → ใช้ซ้ำ ไม่เรียก API
            ctx.emit("voice", "running", f"พากย์ฉาก {i + 1}/{n}", i / n, s.id)
            res = tts.synthesize(s.narration, path, language=p.language)
            s.audio_path, s.audio_duration, s.words = str(res.path), res.duration, res.words
            s.fp["voice"] = fp
            self._save_sidecar(path, s)
            made += 1
            ctx.save()
        return made

    @staticmethod
    def _save_sidecar(path: Path, s: Scene) -> None:
        import json
        side = path.with_suffix(".json")
        side.write_text(json.dumps({"duration": s.audio_duration,
                                    "words": [{"text": w.text, "start": w.start, "end": w.end} for w in s.words]},
                                   ensure_ascii=False), encoding="utf-8")

    @staticmethod
    def _load_sidecar(s: Scene, path: Path, fp: str) -> bool:
        import json
        side = path.with_suffix(".json")
        if not (path.exists() and side.exists()):
            return False
        try:
            d = json.loads(side.read_text(encoding="utf-8"))
            s.audio_path, s.audio_duration = str(path), float(d["duration"])
            s.words = [Word(**w) for w in d["words"]]
        except (ValueError, KeyError, TypeError):
            return False
        s.fp["voice"] = fp
        return True

    @staticmethod
    def _measure(ctx: Context) -> None:
        """วัดอัตราพูดจริง (ตัวอักษร/วินาที) เพื่อให้การคำนวณความยาวบทแม่นขึ้นเรื่อยๆ"""
        p = ctx.project
        chars = sum(count_chars(s.narration) for s in p.scenes)
        secs = sum(s.audio_duration for s in p.scenes)
        if secs > 0 and chars > 0:
            p.measured_cps = round(chars / secs, 2)

    def _auto_fit(self, ctx: Context, tts) -> str:
        p, cfg = ctx.project, ctx.cfg
        target = float(cfg["target_seconds"])
        tl = build_timeline(p, cfg)
        cur = tl.speech_total
        ratio = target / cur if cur else 1.0
        if TOLERANCE_LOW <= ratio <= TOLERANCE_HIGH:
            return " (ตรงเป้าแล้ว)"
        ctx.emit("voice", "running", f"ยาว {cur:.0f} วินาที เป้า {target:.0f} — ให้ AI ปรับบทให้พอดี", 0.9)
        try:
            changed = script_writer.fit_duration(ctx.provider("llm"), p, cfg, target)
        except ForgeError as e:
            return f" (ปรับบทอัตโนมัติไม่สำเร็จ: {e})"
        if not changed:
            return ""
        self._synthesize_all(ctx, tts)
        self._measure(ctx)
        after = build_timeline(p, cfg).speech_total
        return f" (ปรับบท {len(changed)} ฉาก: {cur:.0f}→{after:.0f} วินาที เป้า {target:.0f})"
