"""Studio = ประตูเดียวของระบบ — UI (Gradio) และ CLI เรียกใช้แค่คลาสนี้

อยากเปลี่ยน UI เป็น NiceGUI/Reflex/React ในอนาคต: เขียนหน้าใหม่ที่เรียก Studio เหมือนเดิม
แกนกลาง (core/skills/steps/providers) ไม่ต้องแตะแม้แต่บรรทัดเดียว
"""
from __future__ import annotations

import dataclasses
import os
from pathlib import Path
from typing import Iterator

from . import registry_bootstrap  # noqa: F401  (ให้ provider ถูก import)
from .core import registry
from .core.errors import ConfigError, ForgeError
from .core.events import CancelToken, Emitter, Event
from .core.models import STEP_LABELS, STEP_ORDER, Project, fingerprint
from .core.pipeline import Context, Pipeline
from .core.project_store import ProjectStore
from .core.settings import Cfg, Settings, load_dotenv
from .providers.base import Clip
from .skills import beats as beatlib
from .skills import editor, video_composer
from .skills.timing import ShotPlan, build_timeline, plan_scene, scene_lead
from .steps import default_pipeline
from .steps.visuals import fetch_clip

ROOT = Path(__file__).resolve().parents[1]


class Studio:
    def __init__(self, root: Path | str | None = None, data_dir: Path | str | None = None,
                 pipeline: Pipeline | None = None):
        self.root = Path(root) if root else ROOT
        load_dotenv(self.root / ".env")
        self.data_dir = Path(data_dir or os.environ.get("SF_DATA_DIR") or self.root / "data")
        self.settings = Settings(self.data_dir)
        from .core import quota
        quota.DATA_DIR = self.data_dir
        self.store = ProjectStore(self.data_dir)
        self.pipeline = pipeline or default_pipeline()
        self.cancel = CancelToken()
        from .skills import prompts
        prompts.USER_DIR = self.data_dir / "prompts"

    # ---------------------------------------------------------------- โปรเจกต์
    def cfg(self, project: Project | None = None) -> Cfg:
        return self.settings.effective(project.overrides if project else None)

    def new_project(self, topic: str, *, seconds: int | None = None, scenes: int | None = None,
                    language: str | None = None) -> Project:
        cfg = self.cfg()
        p = self.store.create(topic.strip(), language or cfg["language"])
        if seconds:
            p.overrides["target_seconds"] = int(seconds)
        if scenes:
            p.overrides["scene_count"] = int(scenes)
        self.store.save(p)
        return p

    def open(self, pid: str) -> Project:
        """เปิดโปรเจกต์ + ตรวจว่าค่าตั้งค่าเปลี่ยนจนบางสเต็ปล้าสมัยหรือไม่ (แล้วบันทึกสถานะใหม่)"""
        p = self.store.load(pid)
        changed = bool(self.pipeline.refresh(p, self.cfg(p)))
        if p.steps["visuals"].status == "done" and not self._shots_match_plan(p):
            # ภาพที่มีอยู่ถูกตัดตามแผนเก่า (เช่นโปรเจกต์จากเวอร์ชันก่อน หรือ undo ข้ามจุดตัด) → ให้สเต็ปหาภาพจัดใหม่
            # (คลิปเดิมที่คำค้นตรงกันจะถูกใช้ซ้ำ ไม่ค้น/ไม่โหลดใหม่)
            p.invalidate("visuals", "จุดตัดภาพเปลี่ยน — จัดภาพใหม่ (ใช้คลิปเดิมที่ยังใช้ได้)")
            changed = True
        if changed:
            self.store.save(p)
        return p

    def _shots_match_plan(self, p: Project) -> bool:
        try:
            cfg = self.cfg(p)
            tl = build_timeline(p, cfg)
            for i, item in enumerate(tl.items):
                s = item.scene
                if not s.beats:
                    return False
                plans = plan_scene(item, tl, i, float(cfg["max_shot_seconds"]))
                if [(x.beat, x.part) for x in plans] != [(sh.beat, sh.part) for sh in s.shots]:
                    return False
        except (ForgeError, KeyError, IndexError, ValueError):
            return False
        return True

    def save(self, p: Project) -> None:
        self.store.save(p)

    def projects(self) -> list[dict]:
        return self.store.list()

    # ---------------------------------------------------------------- รัน pipeline
    def context(self, p: Project) -> Context:
        self.cancel = CancelToken()
        return Context(p, self.cfg(p), self.store, Emitter(), self.cancel)

    def preflight(self, p: Project, start: str = "script") -> list[str]:
        """ตรวจก่อนเริ่มว่ามีอะไรขาดไหม — คืนรายการปัญหาที่อ่านแล้วรู้ว่าต้องทำอะไร"""
        cfg = self.cfg(p)
        issues: list[str] = []
        order = STEP_ORDER[STEP_ORDER.index(start):]

        def need(kind: str, name: str, step_label: str) -> None:
            ent = next((e for e in registry.entries(kind) if e.name == name), None)
            if ent is None:
                issues.append(f"{step_label}: ไม่รู้จักตัวเลือก '{name}'")
                return
            for k in ent.needs_keys:
                if not cfg.secret(k):
                    issues.append(f"{step_label}: ยังไม่ได้ใส่ {k.capitalize()} API key (แท็บตั้งค่า → API Keys)")

        if "script" in order or p.steps["voice"].status != "done":
            need("llm", cfg["llm.provider"], "เขียนบท")
        if "voice" in order:
            need("tts", cfg["tts.provider"], "เสียงพากย์")
            if cfg["tts.provider"] == "elevenlabs" and not str(cfg["elevenlabs.voice_id"]).strip():
                issues.append("เสียงพากย์: ยังไม่ได้เลือก Voice ID ของ ElevenLabs (แท็บเสียง & เพลง)")
        if "visuals" in order:
            from .skills.visual_picker import usable_providers
            ready, skipped = usable_providers(cfg)
            if not ready:
                issues.append("หาภาพ: ไม่มีแหล่งภาพที่พร้อมใช้ — ใส่ Pexels/Pixabay key หรือวางคลิปใน assets/stock")
        if "visuals" in order and str(cfg.get("image.provider", "none")) not in ("", "none", "mock"):
            need("image", cfg["image.provider"], "ภาพ AI")
            if cfg["image.provider"] == "cloudflare" and not str(cfg.get("cloudflare.account_id", "")).strip():
                issues.append("ภาพ AI: ยังไม่ได้ใส่ Cloudflare Account ID (แท็บตั้งค่า → ภาพ AI)")
        if "music" in order and cfg["music.provider"] not in ("none", "local", "mock"):
            need("music", cfg["music.provider"], "เพลง")
        return issues

    def run_iter(self, p: Project, *, start: str = "script", stop: str = "render",
                 force: set[str] | None = None) -> Iterator[Event]:
        issues = self.preflight(p, start)
        if issues:
            raise ConfigError("ยังรันไม่ได้:\n• " + "\n• ".join(issues))
        yield from self.pipeline.run_iter(self.context(p), start=start, stop=stop, force=force)

    def run(self, p: Project, *, start: str = "script", stop: str = "render",
            force: set[str] | None = None, on_event=None) -> None:
        for ev in self.run_iter(p, start=start, stop=stop, force=force):
            if on_event:
                on_event(ev)

    REVIEW_GATES = ("script", "voice", "visuals", "music")   # สเต็ปที่หยุดให้ตรวจ (ซับ+เรนเดอร์ทำต่อกันเลย)

    def review_mode(self, p: Project | None = None) -> bool:
        return bool(self.cfg(p).get("workflow.review", True))

    def next_stop(self, p: Project, start: str | None = None) -> str:
        """โหมดตรวจทีละสเต็ป: ทำแค่สเต็ปถัดไปแล้วหยุด · โหมดรวดเดียว: ทำจนเรนเดอร์จบ"""
        start = start or self.next_start(p)
        if not self.review_mode(p):
            return "render"
        if start in self.REVIEW_GATES:
            if start == "music" and self.cfg(p)["music.provider"] == "none":
                return "render"
            return start
        return "render"

    def next_label(self, p: Project | None) -> str:
        """ข้อความปุ่มหลัก บอกว่ากดแล้วจะเกิดอะไร"""
        if p is None or not p.scenes:
            return "① เขียนบท"
        if all(p.steps[s].status == "done" for s in STEP_ORDER):
            return "✓ เสร็จแล้ว — เรนเดอร์ซ้ำ"
        start = self.next_start(p)
        stop = self.next_stop(p, start)
        n = STEP_ORDER.index(start) + 1
        if start == stop:
            return f"▶ ถัดไป: ({n}) {STEP_LABELS[start]}"
        return f"▶ ทำต่อ: ({n}) {STEP_LABELS[start]} → เรนเดอร์"

    def next_start(self, p: Project) -> str:
        """สเต็ปแรกที่ยังไม่เสร็จ — ปุ่ม 'ทำต่อ' ใช้ตัวนี้"""
        for s in STEP_ORDER:
            if p.steps[s].status != "done":
                return s
        return "render"

    # ---------------------------------------------------------------- AI Editor
    def usage_text(self) -> str:
        from .core import quota
        return quota.summary()

    def plan_edit(self, p: Project, instruction: str, focus: dict | None = None) -> editor.EditPlan:
        cfg = self.cfg(p)
        ent = registry.create("llm", cfg["llm.provider"], cfg)
        return editor.plan_edit(ent, p, cfg, instruction, focus)

    def apply_ops(self, p: Project, ops: list[dict], label: str = "แก้ไข") -> editor.ApplyResult:
        """จุดแก้ไขเดียวของทั้งระบบ (AI และปุ่มมือใช้ร่วมกัน): snapshot → apply → บันทึก"""
        if not ops:
            return editor.ApplyResult()
        valid, rejected = editor.validate_ops(ops, p)
        if not valid:
            raise ForgeError("คำสั่งแก้ไขใช้ไม่ได้: " + "; ".join(rejected or ["ไม่มีรายการ"]))
        self.store.snapshot(p, label)
        res = editor.apply_ops(p, valid)
        res.messages += rejected
        self.store.save(p)
        return res

    def apply_plan(self, p: Project, plan: editor.EditPlan) -> editor.ApplyResult:
        return self.apply_ops(p, plan.ops, label="AI: " + plan.instruction[:60])

    def undo(self, p: Project) -> Project:
        return self.store.restore(p.id)

    def history(self, p: Project) -> list[dict]:
        return self.store.history(p.id)

    # ---------------------------------------------------------------- แก้ด้วยมือ (ผ่าน ops เดียวกัน)
    def set_narration(self, p: Project, scene_id: int, text: str) -> editor.ApplyResult:
        return self.apply_ops(p, [{"op": "set_narration", "scene_id": scene_id, "text": text}], "แก้บทฉาก")

    def set_keywords(self, p: Project, scene_id: int, keywords: list[str]) -> editor.ApplyResult:
        return self.apply_ops(p, [{"op": "set_keywords", "scene_id": scene_id, "keywords": keywords}], "แก้คำค้นภาพ")

    def pick_clip(self, p: Project, scene_id: int, shot_index: int, clip: dict) -> None:
        """ผู้ใช้เลือกคลิปจาก gallery มาแทนช็อตที่ระบุ → ปักหมุด (ระบบไม่เปลี่ยนให้เองอีก)"""
        s = p.scene(scene_id)
        if not (0 <= shot_index < len(s.shots)):
            raise ForgeError("ไม่มีช็อตนี้ในฉาก — รันสเต็ปหาภาพก่อน")
        self.store.snapshot(p, "เลือกคลิปเอง")
        c = Clip.from_dict(clip)
        path = fetch_clip(self.context(p), {}, c)
        old = s.shots[shot_index]
        s.shots[shot_index] = dataclasses.replace(
            old, clip=c.to_dict(), path=path, pinned=True, start=0.0, start_locked=False,
            score=clip.get("ai_score"), why=clip.get("ai_why") or "เลือกเอง")
        s.fp.pop("visual", None)
        p.invalidate("visuals", "เปลี่ยนคลิปเอง")
        self.store.save(p)

    # ---- ตัวตัดต่อในฉาก ----
    def set_visual(self, p: Project, scene_id: int, beat: int, query: str, visual: str = "") -> editor.ApplyResult:
        qs = [q.strip() for q in query.replace("\n", ",").split(",") if q.strip()]
        return self.apply_ops(p, [{"op": "set_visual", "scene_id": scene_id, "beat": beat, "queries": qs,
                                   "visual": visual}], "เปลี่ยนภาพของช่วงพูด")

    def set_graphic(self, p: Project, scene_id: int, beat: int, template: str, lines: str) -> editor.ApplyResult:
        """ทำช่วงนี้เป็นภาพอธิบาย / แก้ข้อความในภาพ (ข้อความหลายบรรทัด เรียงตามช่องของแบบนั้น)"""
        from .skills import graphics as gx
        data = gx.from_lines(template, lines)
        if data is None:
            raise ForgeError(f"ข้อความไม่ครบสำหรับแบบ “{gx.get(template).label}” — {gx.lines_help(template)}")
        return self.apply_ops(p, [{"op": "set_graphic", "scene_id": scene_id, "beat": beat, "template": template,
                                   "fields": data}], "ทำเป็นภาพอธิบาย")

    def set_aiimage(self, p: Project, scene_id: int, beat: int, prompt: str = "", reroll: bool = False) -> editor.ApplyResult:
        return self.apply_ops(p, [{"op": "set_aiimage", "scene_id": scene_id, "beat": beat, "prompt": prompt,
                                   "reroll": reroll}], "สุ่มภาพ AI ใหม่" if reroll else "ทำเป็นภาพ AI")

    def set_shot_start(self, p: Project, scene_id: int, shot: int, seconds: float) -> editor.ApplyResult:
        return self.apply_ops(p, [{"op": "set_shot_start", "scene_id": scene_id, "shot": shot, "seconds": seconds}],
                              "เลื่อนจุดเริ่มคลิป")

    def set_cut(self, p: Project, scene_id: int, beat: int, word: int) -> editor.ApplyResult:
        return self.apply_ops(p, [{"op": "set_cut", "scene_id": scene_id, "beat": beat, "word": word}], "เลื่อนจุดตัด")

    def split_at_word(self, p: Project, scene_id: int, word: int) -> editor.ApplyResult:
        return self.apply_ops(p, [{"op": "split_beat", "scene_id": scene_id, "word": word}], "เพิ่มจุดตัดภาพ")

    def merge_beat(self, p: Project, scene_id: int, beat: int) -> editor.ApplyResult:
        return self.apply_ops(p, [{"op": "merge_beat", "scene_id": scene_id, "beat": beat}], "ลบจุดตัดภาพ")

    def set_pause(self, p: Project, scene_id: int, seconds: float) -> editor.ApplyResult:
        return self.apply_ops(p, [{"op": "set_pause", "scene_id": scene_id, "seconds": seconds}], "ปรับช่วงเงียบท้ายฉาก")

    def scene_plan(self, p: Project, scene_id: int) -> tuple[list[ShotPlan], float, int]:
        """แผนช็อตของฉาก ตามข้อมูลล่าสุด → (แผน, lead ของฉากนี้, fps) ไว้ให้หน้าจอโชว์จุดตัด"""
        cfg = self.cfg(p)
        tl = build_timeline(p, cfg)
        i = p.index_of(scene_id)
        beatlib.ensure_beats(p.scenes[i], p.topic)
        return plan_scene(tl.items[i], tl, i, float(cfg["max_shot_seconds"])), scene_lead(tl, i), tl.fps

    def preview_scene(self, p: Project, scene_id: int) -> str:
        """เรนเดอร์เฉพาะฉากนี้ (ภาพ + เสียงพากย์ ไม่ใส่ซับ/เพลง) ไว้ตรวจจุดตัดเร็วๆ — ช็อตถูกแคชร่วมกับตอนเรนเดอร์จริง"""
        cfg = self.cfg(p)
        s = p.scene(scene_id)
        if not s.audio_path or not Path(s.audio_path).exists():
            raise ForgeError("ฉากนี้ยังไม่มีเสียงพากย์ — ทำสเต็ปเสียงพากย์ก่อน")
        plans, lead, fps = self.scene_plan(p, scene_id)
        if len(plans) != len(s.shots) or any(not sh.path or not Path(sh.path).exists() for sh in s.shots):
            raise ForgeError("ภาพของฉากนี้ยังไม่ตรงกับจุดตัดล่าสุด — กด “จัดภาพฉากนี้ใหม่” หรือทำสเต็ปหาภาพก่อน")
        w, h = (int(x) for x in str(cfg["resolution"]).split("x"))
        crf, preset = int(cfg["render.crf"]), str(cfg["render.preset"])
        shot_cache = self.store.cache_dir("shots")
        files = [video_composer.render_shot(sh.path, sh.start, pl.frames, shot_cache, width=w, height=h, fps=fps,
                                            crf=crf, preset=preset) for sh, pl in zip(s.shots, plans)]
        total = sum(pl.frames for pl in plans)
        out_dir = self.store.asset_dir(p, "previews")
        out = out_dir / f"scene{s.id}_{fingerprint([str(f) for f in files], s.audio_path, lead, total)}.mp4"
        if not out.exists():
            video_composer.render_preview(files, Path(s.audio_path), out, work=out_dir / "work", lead=lead,
                                          total_frames=total, fps=fps, crf=crf, preset=preset)
        return str(out)

    # ---------------------------------------------------------------- ตั้งค่า / รายการประกอบ UI
    def list_voices(self) -> list[tuple[str, str]]:
        cfg = self.cfg()
        return registry.create("tts", cfg["tts.provider"], cfg).list_voices()

    def list_ollama_models(self) -> list[str]:
        cfg = self.cfg()
        return registry.create("llm", "ollama", cfg).list_models()
