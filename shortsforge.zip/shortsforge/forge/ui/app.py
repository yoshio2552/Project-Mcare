"""หน้าโปรแกรม Gradio 6 — แสดงบท/ภาพ/เสียง/เพลง สั่งแก้ได้ ดูสเต็ปสด ตั้งค่าได้ในหน้าเดียว

หลักการใช้งาน (ตามที่ผู้ใช้ต้องการ):
  • กดอะไรก็ตาม แถบสถานะใต้สเต็ปขึ้น "⏳ กำลัง…" ทันที และปุ่มหลักถูกล็อกจนงานเสร็จ — ไม่มีอาการ "กดแล้วเงียบ"
  • โหมดตรวจทีละสเต็ป (ค่าเริ่มต้น): ปุ่มหลักทำแค่สเต็ปถัดไปแล้วหยุดรอ ปุ่มบอกชัดว่าจะทำอะไร (▶ ถัดไป: เสียงพากย์)
  • ✂ ตัวตัดต่อในแต่ละฉาก: ภาพตัดตามคำพูด เลื่อนจุดตัด/เพิ่ม/ลบจุดตัด เลื่อนช่วงของคลิป เปลี่ยนภาพเฉพาะช่วง และพรีวิวฉากเดียวได้

ทุกปุ่มเรียก Studio เท่านั้น และ handler ทุกตัวโหลดโปรเจกต์จากดิสก์ใหม่ทุกครั้ง (รีเฟรช/เปิดหลายแท็บได้)
ลำดับในไฟล์: ตัวช่วย → handler → เลย์เอาต์ → ผูกเหตุการณ์
"""
from __future__ import annotations

from functools import partial
from pathlib import Path

import gradio as gr

from ..core import registry
from ..core.errors import Cancelled, ForgeError
from ..core.models import STEP_LABELS, STEP_ORDER, Project
from ..core.settings import GROUPS, SCHEMA
from ..skills import graphics as gx
from ..skills.beats import beat_word_starts
from ..skills.timing import shot_text
from ..studio import Studio
from . import style, views

PREFERRED = {
    "llm": ["gemini", "ollama", "mock"],
    "tts": ["elevenlabs", "edge", "mock"],
    "stock": ["pexels", "pixabay", "local", "mock"],
    "music": ["elevenlabs", "local", "none", "mock"],
}
AREAS = [("ไม่ระบุ", ""), ("บทพากย์", "script"), ("ภาพ/คลิป", "visual"), ("เสียง/เพลง", "audio"), ("ซับไตเติล", "captions")]
CHIPS = [
    ("ฮุคแรงขึ้น", "ฉาก 1 ให้ฮุคแรงและน่าตกใจกว่านี้ ไม่ต้องเกริ่น"),
    ("ย่อบทให้กระชับ", "ย่อบทฉากนี้ให้กระชับขึ้นอีกประมาณ 20% แต่คงใจความไว้"),
    ("ภาพไม่ตรงบท", "ภาพของฉากนี้ไม่ตรงกับที่พูด เปลี่ยนให้ตรงกับประโยคที่ได้ยินในแต่ละช็อต"),
    ("เพลงเบาลง", "ลดเสียงเพลงพื้นหลังลงให้ฟังเสียงพากย์ชัดขึ้น"),
    ("พูดเร็วขึ้นนิด", "ให้เสียงพากย์พูดเร็วขึ้นเล็กน้อย"),
    ("ซับใหญ่ขึ้น", "ทำตัวหนังสือซับให้ใหญ่ขึ้น"),
]


def _ordered(kind: str) -> list[tuple[str, str]]:
    ch = registry.choices(kind)
    order = PREFERRED.get(kind, [])
    return sorted(ch, key=lambda t: order.index(t[1]) if t[1] in order else 99)


def _const(x):
    return x


def _on_select(evt: gr.SelectData):
    return evt.index


def _make_input(f, value):
    """สร้างช่องกรอกจาก Field ในตาราง SCHEMA — เพิ่ม Field ใหม่แล้วหน้านี้ขึ้นเองโดยไม่ต้องแก้โค้ด UI"""
    info = f.help or None
    if f.kind == "secret":
        return gr.Textbox(label=f.label, type="password", value="", info=info,
                          placeholder="ตั้งไว้แล้ว — เว้นว่างถ้าไม่เปลี่ยน" if value else "ยังไม่ได้ตั้ง")
    if f.kind == "multi":
        return gr.CheckboxGroup(label=f.label, choices=_ordered(f.registry) if f.registry else (f.choices or []),
                                value=value, info=info)
    if f.kind in ("choice", "choice_custom"):
        return gr.Dropdown(label=f.label, choices=_ordered(f.registry) if f.registry else (f.choices or []),
                           value=value, info=info, allow_custom_value=(f.kind == "choice_custom"))
    if f.kind in ("int", "float"):
        if f.min is not None and f.max is not None:
            return gr.Slider(f.min, f.max, value=value, step=f.step or (1 if f.kind == "int" else 0.1),
                             label=f.label, info=info)
        return gr.Number(label=f.label, value=value, info=info)
    if f.kind == "bool":
        return gr.Checkbox(label=f.label, value=bool(value), info=info)
    if f.kind == "color":
        return gr.ColorPicker(label=f.label, value=value, info=info)
    return gr.Textbox(label=f.label, value="" if value is None else str(value), info=info)


def build_app(studio: Studio) -> gr.Blocks:
    cfg0 = studio.cfg()

    # =====================================================================
    # ตัวช่วยสร้าง "เฟรม" ผลลัพธ์ที่ทุกปุ่มรันงานส่งกลับเหมือนกัน
    # ลำดับ: pid, stepper, banner, strip, video, files, history, tick, music_audio, proj_dd, b_go, b_all, b_script
    # =====================================================================
    def _video(p: Project | None):
        v = p.outputs.get("video") if p else None
        return v if v and Path(v).exists() else None

    def _music(p: Project | None):
        return p.music.path if p and p.music.path and Path(p.music.path).exists() else None

    def _proj_choices(selected: str | None):
        items = [(f"{x['title'][:48]} · {x['id'][:13]}", x["id"]) for x in studio.projects()]
        return gr.Dropdown(choices=items, value=selected)

    def _idle_hint(p: Project | None) -> str:
        if p is None or not p.scenes:
            return "พิมพ์หัวข้อคลิป เลือกความยาว/จำนวนฉาก แล้วกด ① เขียนบท"
        if all(p.steps[s].status == "done" for s in STEP_ORDER):
            return views.NEXT_HINT["render"]
        nxt = studio.next_start(p)
        return f"ขั้นต่อไป: {STEP_LABELS[nxt]} — กดปุ่ม {studio.next_label(p)}"

    def _buttons(p: Project | None, busy: bool) -> list:
        if busy:
            return [gr.Button(value="⏳ กำลังทำงาน… (กด หยุด ได้)", interactive=False),
                    gr.Button(interactive=False), gr.Button(interactive=False)]
        review = studio.review_mode(p)
        return [gr.Button(value=studio.next_label(p), interactive=True),
                gr.Button(value="⏩ ทำรวดเดียวจนจบ", visible=review, interactive=True),
                gr.Button(value="↻ เขียนบทใหม่ทั้งหมด" if p and p.scenes else "① เขียนบท", interactive=True)]

    def _frame(p: Project | None, pid_v: str, tick_v: int, *, busy: str | None = None, ok: str | None = None,
               warn: str | None = None, progress: float = 0.0, running: str | None = None, final: bool = False) -> list:
        cfg = studio.cfg(p) if p else studio.cfg()
        if busy:
            ban = views.banner_html("busy", busy)
        elif warn:
            ban = views.banner_html("warn", warn)
        elif ok:
            ban = views.banner_html("ok", ok)
        else:
            ban = views.banner_html("idle", _idle_hint(p))
        return [pid_v, views.stepper_html(p, "", progress, running), ban, views.timeline_strip_html(p, cfg),
                _video(p), views.outputs_files(p), views.history_markdown(studio.history(p) if p else []),
                tick_v, _music(p), _proj_choices(p.id if p else None) if final else gr.Dropdown(),
                *_buttons(p, busy is not None)]

    def _stream(p: Project, tick_v: int, start: str, stop: str = "render", force: set[str] | None = None):
        """รัน pipeline ช่วง start→stop แล้ว yield เฟรมสถานะให้หน้าจออัปเดตสด"""
        first = STEP_LABELS[start]
        yield _frame(p, p.id, tick_v, busy=f"กำลังเริ่ม: {first}…", running=start)
        warn = None
        try:
            for ev in studio.run_iter(p, start=start, stop=stop, force=force):
                label = STEP_LABELS.get(ev.step, ev.step)
                if ev.status == "done":
                    tick_v += 1                          # ให้กระดานฉากวาดใหม่ (เห็นเสียง/ภาพที่เพิ่งเสร็จ)
                if ev.status == "skipped":
                    continue
                running = ev.step if ev.status == "running" else None
                yield _frame(p, p.id, tick_v, busy=f"{label}: {ev.message}", progress=ev.progress, running=running)
        except Cancelled:
            warn = "หยุดแล้ว — งานที่ทำไปแล้วยังอยู่ กดปุ่มหลักเพื่อทำต่อ"
        except ForgeError as ex:
            warn = str(ex)
        except Exception as ex:  # noqa: BLE001  (บั๊กที่ไม่คาด: โชว์ให้เห็น ไม่ให้หน้าค้าง)
            warn = f"เกิดข้อผิดพลาดที่ไม่คาดคิด: {type(ex).__name__}: {ex}"
        p2 = studio.open(p.id)
        ok = None
        if not warn:
            if stop == "render":
                ok = "เรนเดอร์เสร็จ — " + views.NEXT_HINT["render"]
                gr.Info("คลิปเสร็จแล้ว 🎬")
            else:
                ok = f"{STEP_LABELS[stop]} เสร็จ — {views.NEXT_HINT.get(stop, '')}"
            from ..core import quota
            if quota.compact():
                ok += f"  ({quota.compact()})"
        yield _frame(p2, p.id, tick_v + 1, ok=ok, warn=warn, final=True)

    def _plan_run(p: Project, mode: str) -> tuple[str, str, set[str] | None]:
        """ปุ่มไหนกดแล้วรันช่วงไหน"""
        if all(p.steps[s].status == "done" for s in STEP_ORDER):
            return "render", "render", {"render"}
        start = studio.next_start(p)
        stop = "render" if mode == "all" else studio.next_stop(p, start)
        return start, stop, None

    # ------------------------------------------------ โปรเจกต์ / รัน
    def ensure_project(pid_v, topic_v, lang_v, secs_v, nsc_v) -> Project:
        if not pid_v:
            if not (topic_v or "").strip():
                raise ForgeError("พิมพ์หัวข้อคลิปก่อน")
            return studio.new_project(topic_v, seconds=int(secs_v), scenes=int(nsc_v), language=lang_v)
        p = studio.open(pid_v)
        if not p.scenes:                                  # ยังไม่มีบท: แก้หัวข้อ/จำนวนฉาก/ความยาวได้อิสระ
            p.topic = (topic_v or p.topic).strip()
            p.language = lang_v
            p.overrides["target_seconds"], p.overrides["scene_count"] = int(secs_v), int(nsc_v)
            studio.save(p)
        elif int(secs_v) != int(studio.cfg(p)["target_seconds"]):   # มีบทแล้ว: เปลี่ยนความยาว = ให้ AI ปรับบทให้พอดี
            studio.apply_ops(p, [{"op": "fit_duration", "seconds": int(secs_v)}], "เปลี่ยนความยาวเป้าหมาย")
        return studio.open(p.id)

    def run_mode(mode, pid_v, tick_v, topic_v, lang_v, secs_v, nsc_v):
        cur = studio.open(pid_v) if pid_v else None
        yield _frame(cur, pid_v, tick_v, busy="กำลังเตรียมงาน…")
        try:
            p = ensure_project(pid_v, topic_v, lang_v, secs_v, nsc_v)
        except ForgeError as ex:
            yield _frame(cur, pid_v, tick_v, warn=str(ex))
            return
        if mode == "script":
            if p.scenes:
                studio.apply_ops(p, [{"op": "regenerate_script", "instruction": ""}], "เขียนบทใหม่")
                p = studio.open(p.id)
            yield from _stream(p, tick_v, "script", "script", {"script"})
            return
        start, stop, force = _plan_run(p, mode)
        yield from _stream(p, tick_v, start, stop, force)

    def open_project(pid_v, tick_v):
        if not pid_v:
            return _frame(None, "", tick_v + 1, final=True) + ["", cfg0["language"], cfg0["target_seconds"],
                                                               cfg0["scene_count"], ""]
        p = studio.open(pid_v)
        cfg = studio.cfg(p)
        return _frame(p, pid_v, tick_v + 1, final=True) + [p.topic, p.language, cfg["target_seconds"],
                                                           cfg["scene_count"], p.music.prompt]

    def new_project_click(tick_v):
        return _frame(None, "", tick_v + 1, final=True) + ["", cfg0["language"], cfg0["target_seconds"],
                                                           cfg0["scene_count"], ""]

    def on_load():
        return _proj_choices(None)

    def stop():
        studio.cancel.cancel()
        gr.Info("กำลังหยุด… (รอให้งานย่อยที่ทำอยู่จบก่อน)")

    def undo(pid_v, tick_v):
        if not pid_v:
            return _frame(None, pid_v, tick_v, warn="ยังไม่มีโปรเจกต์")
        p = studio.open(pid_v)
        try:
            p = studio.undo(p)
        except FileNotFoundError:
            return _frame(p, pid_v, tick_v, warn="ยังไม่มีประวัติให้ย้อนกลับ")
        return _frame(p, pid_v, tick_v + 1, ok="ย้อนกลับแล้ว 1 ขั้น", final=True)

    def set_review(on, pid_v):
        studio.settings.update({"workflow.review": bool(on)})
        p = studio.open(pid_v) if pid_v else None
        return _buttons(p, False)

    # ------------------------------------------------ กระดานฉาก: แก้แล้วบอกผลทันที
    # ผลลัพธ์ของปุ่มในกระดาน: banner, stepper, strip, tick, b_go
    def _board(p: Project, tick_v: int, *, ok: str | None = None, warn: str | None = None, busy: str | None = None,
               bump: bool = True) -> list:
        ban = views.banner_html("busy", busy) if busy else views.banner_html("warn", warn) if warn else \
            views.banner_html("ok", ok) if ok else views.banner_html("idle", _idle_hint(p))
        return [ban, views.stepper_html(p), views.timeline_strip_html(p, studio.cfg(p)), tick_v + (1 if bump else 0),
                gr.Button(value=studio.next_label(p), interactive=busy is None)]

    def save_narration(pid_v, sid, text, tick_v):
        p = studio.open(pid_v)
        if not (text or "").strip():
            return _board(p, tick_v, warn="บทว่างไม่ได้", bump=False)
        studio.set_narration(p, sid, text)
        return _board(studio.open(pid_v), tick_v, ok="บันทึกบทแล้ว — กดปุ่มหลักเพื่อพากย์ใหม่เฉพาะฉากนี้")

    def save_keywords(pid_v, sid, text, tick_v):
        p = studio.open(pid_v)
        kws = [k.strip() for k in (text or "").replace("\n", ",").split(",") if k.strip()]
        if not kws:
            return _board(p, tick_v, warn="ใส่คำค้นอย่างน้อย 1 คำ", bump=False)
        studio.set_keywords(p, sid, kws)
        return _board(studio.open(pid_v), tick_v, ok="บันทึกคำค้นแล้ว — กดปุ่มหลักเพื่อหาภาพใหม่เฉพาะฉากนี้")

    def pick_clip(pid_v, sid, cands, sel_idx, shot_idx, tick_v):
        p = studio.open(pid_v)
        if sel_idx is None:
            return _board(p, tick_v, warn="คลิกเลือกรูปคลิปก่อน แล้วค่อยกด ใช้คลิปนี้", bump=False)
        try:
            studio.pick_clip(p, sid, int(shot_idx), cands[int(sel_idx)])
        except ForgeError as ex:
            return _board(p, tick_v, warn=str(ex), bump=False)
        return _board(studio.open(pid_v), tick_v, ok=f"ใช้คลิปที่เลือกในช็อต {int(shot_idx) + 1} แล้ว (ปักหมุด)")

    def _edit_then_visuals(pid_v, tick_v, action, busy_text: str, ok_text: str):
        """แก้จุดตัด/ภาพ → จัดภาพใหม่ทันที (เฉพาะฉากที่เปลี่ยน ใช้คลิปเดิมที่ยังใช้ได้) → วาดกระดานใหม่"""
        p = studio.open(pid_v)
        yield _board(p, tick_v, busy=busy_text, bump=False)
        try:
            res = action(p)
        except ForgeError as ex:
            yield _board(studio.open(pid_v), tick_v, warn=str(ex))
            return
        if res is not None and getattr(res, "messages", None):
            yield _board(studio.open(pid_v), tick_v, warn="; ".join(res.messages))
            return
        p = studio.open(pid_v)
        if p.steps["voice"].status == "done" and p.steps["visuals"].status != "done":
            try:
                for ev in studio.run_iter(p, start="visuals", stop="visuals"):
                    if ev.status == "running":
                        yield _board(p, tick_v, busy=f"{busy_text} — {ev.message}", bump=False)
            except ForgeError as ex:
                yield _board(studio.open(pid_v), tick_v, warn=str(ex))
                return
        yield _board(studio.open(pid_v), tick_v, ok=ok_text)

    def cut_move(pid_v, sid, beat, word, tick_v):
        if word is None:
            return
        yield from _edit_then_visuals(pid_v, tick_v, lambda p: studio.set_cut(p, sid, beat, int(word)),
                                      "กำลังเลื่อนจุดตัด", "เลื่อนจุดตัดแล้ว — กด ▶ พรีวิวฉากนี้ เพื่อดูผล")

    def cut_add(pid_v, sid, word, tick_v):
        if word is None:
            yield _board(studio.open(pid_v), tick_v, warn="เลือกคำที่จะตัดภาพก่อน", bump=False)
            return
        yield from _edit_then_visuals(pid_v, tick_v, lambda p: studio.split_at_word(p, sid, int(word)),
                                      "กำลังเพิ่มจุดตัดและหาภาพให้ช่วงใหม่",
                                      "เพิ่มจุดตัดแล้ว — ช่วงใหม่ใช้คำค้นเดิมไปก่อน แก้คำค้นของช็อตนั้นได้")

    def cut_remove(pid_v, sid, beat, tick_v):
        yield from _edit_then_visuals(pid_v, tick_v, lambda p: studio.merge_beat(p, sid, beat),
                                      "กำลังลบจุดตัด", "ลบจุดตัดแล้ว — ภาพช็อตก่อนหน้าเล่นต่อยาวขึ้น")

    def research(pid_v, sid, beat, query, tick_v):
        if not (query or "").strip():
            yield _board(studio.open(pid_v), tick_v, warn="พิมพ์คำค้น (อังกฤษ) ก่อน เช่น woman sleeping bed", bump=False)
            return
        yield from _edit_then_visuals(pid_v, tick_v, lambda p: studio.set_visual(p, sid, beat, query),
                                      f"กำลังหาภาพใหม่ “{query.split(',')[0].strip()}”",
                                      "ได้ภาพใหม่แล้ว (คลิปเก่าของช่วงนี้จะไม่ถูกเลือกอีก)")

    def make_graphic(pid_v, sid, beat, tpl, lines, tick_v):
        if not tpl:
            yield _board(studio.open(pid_v), tick_v, warn="เลือกแบบภาพอธิบายก่อน", bump=False)
            return
        yield from _edit_then_visuals(pid_v, tick_v, lambda p: studio.set_graphic(p, sid, beat, tpl, lines),
                                      f"กำลังวาดภาพอธิบาย “{gx.get(tpl).label}”",
                                      "ได้ภาพอธิบายแล้ว — กด ▶ พรีวิวฉากนี้ เพื่อดูแอนิเมชัน")

    def make_aiimage(pid_v, sid, beat, reroll, prompt, tick_v):
        if not reroll and not (prompt or "").strip():
            yield _board(studio.open(pid_v), tick_v, warn="พิมพ์ว่าอยากได้ภาพอะไรก่อน (ภาษาอังกฤษ)", bump=False)
            return
        yield from _edit_then_visuals(pid_v, tick_v,
                                      lambda p: studio.set_aiimage(p, sid, beat, "" if reroll else prompt, reroll),
                                      "กำลังสร้างภาพ AI (ใช้โควตา 1 ภาพ)",
                                      "ได้ภาพ AI แล้ว — กด ▶ พรีวิวฉากนี้ เพื่อดูการเคลื่อนไหว")

    def to_video(pid_v, sid, beat, query, tick_v):
        yield from research(pid_v, sid, beat, query, tick_v)

    def tpl_changed(tpl, lines):
        if not tpl:
            return gr.Textbox()
        ex = gx.to_lines(tpl, gx.normalize(tpl, gx.get(tpl).example) or {})
        return gr.Textbox(info=gx.lines_help(tpl), value=lines if (lines or "").strip() else ex)

    def set_pause(pid_v, sid, secs, tick_v):
        yield from _edit_then_visuals(pid_v, tick_v, lambda p: studio.set_pause(p, sid, float(secs)),
                                      "กำลังปรับช่วงเงียบท้ายฉาก", f"ช่วงเงียบท้ายฉาก = {float(secs):.2f} วินาที")

    def set_start(pid_v, sid, shot, secs, tick_v):
        p = studio.open(pid_v)
        try:
            studio.set_shot_start(p, sid, shot, float(secs))
        except ForgeError as ex:
            return _board(p, tick_v, warn=str(ex), bump=False)
        return _board(studio.open(pid_v), tick_v, ok=f"ช็อต {shot}: ใช้คลิปตั้งแต่วินาทีที่ {float(secs):.1f} — กด ▶ พรีวิวฉากนี้",
                      bump=False)

    def preview(pid_v, sid):
        yield [gr.Video(), views.banner_html("busy", "กำลังเรนเดอร์พรีวิวฉากนี้ (ภาพ + เสียงพากย์)…")]
        try:
            path = studio.preview_scene(studio.open(pid_v), sid)
        except ForgeError as ex:
            yield [gr.Video(), views.banner_html("warn", str(ex))]
            return
        yield [gr.Video(value=path, visible=True), views.banner_html("ok", "พรีวิวพร้อมแล้ว — ดูจุดตัดว่าตรงคำพูดไหม")]

    def focus_on(n):
        return n, "", gr.Tabs(selected="editor")

    # ------------------------------------------------ AI Editor
    def editor_plan(pid_v, text, scene_n, area):
        hide = gr.Button(visible=False)
        idle_btn = gr.Button(value="วิเคราะห์คำสั่ง", interactive=True)
        if not pid_v:
            yield ["⚠️ สร้างบทก่อน แล้วค่อยสั่งแก้", None, hide, hide, idle_btn]
            return
        if not (text or "").strip():
            yield ["⚠️ พิมพ์สิ่งที่อยากแก้ก่อน (หรือกดปุ่มลัดด้านบน)", None, hide, hide, idle_btn]
            return
        yield ["⏳ **AI กำลังอ่านคำสั่งและดูทั้งโปรเจกต์…** (ปกติ 3–20 วินาที)", None, hide, hide,
               gr.Button(value="⏳ กำลังวิเคราะห์…", interactive=False)]
        p = studio.open(pid_v)
        try:
            plan = studio.plan_edit(p, text, {"scene": int(scene_n) or None, "area": area or None})
        except ForgeError as ex:
            yield [f"⚠️ {ex}", None, hide, hide, idle_btn]
            return
        show = bool(plan.ops)
        tail = ("\n\n👉 กด **ใช้การแก้ไขนี้** เพื่อลงมือ" if show else "")
        yield [views.plan_markdown(plan, p) + tail, ({"ops": plan.ops, "instruction": text} if show else None),
               gr.Button(visible=show), gr.Button(visible=show), idle_btn]

    def editor_apply(pid_v, tick_v, state):
        tail = ["", None, gr.Button(visible=False), gr.Button(visible=False)]
        if not state or not pid_v:
            yield _frame(studio.open(pid_v) if pid_v else None, pid_v, tick_v,
                         warn="ยังไม่มีแผนให้ใช้ — กด วิเคราะห์คำสั่ง ก่อน") + tail
            return
        p = studio.open(pid_v)
        try:
            res = studio.apply_ops(p, state["ops"], "AI: " + state["instruction"][:60])
        except ForgeError as ex:
            yield _frame(p, pid_v, tick_v, warn=str(ex)) + tail
            return
        p = studio.open(pid_v)
        if res.regenerate_script:
            start, stop, force = "script", studio.next_stop(p, "script"), {"script"}
        else:
            start, stop, force = _plan_run(p, "go")
        for fr in _stream(p, tick_v, start, stop, force):
            yield fr + tail

    def editor_drop():
        return ["", None, gr.Button(visible=False), gr.Button(visible=False)]

    # ------------------------------------------------ เสียง & เพลง
    def load_voices():
        try:
            voices = studio.list_voices()
        except ForgeError as ex:
            gr.Warning(str(ex))
            return gr.Dropdown()
        if not voices:
            gr.Info("ตัวพากย์นี้ไม่มีรายการเสียงให้เลือก")
        else:
            gr.Info(f"โหลดแล้ว {len(voices)} เสียง")
        return gr.Dropdown(choices=voices, value=studio.settings.values.get("elevenlabs.voice_id") or None)

    def save_voice(voice_v, tts_v, pid_v):
        studio.settings.update({"elevenlabs.voice_id": voice_v or "", "tts.provider": tts_v})
        p = studio.open(pid_v) if pid_v else None
        return [views.stepper_html(p), views.banner_html("ok", "บันทึกเสียงแล้ว — สเต็ปเสียงพากย์จะขึ้น “ต้องทำใหม่” กดปุ่มหลักเพื่อพากย์ด้วยเสียงนี้"),
                gr.Button(value=studio.next_label(p))]

    def regen_music(pid_v, tick_v, prompt_v, music_v):
        if not pid_v:
            yield _frame(None, pid_v, tick_v, warn="สร้างบทก่อน")
            return
        if music_v != studio.settings.values.get("music.provider"):
            studio.settings.update({"music.provider": music_v})
        p = studio.open(pid_v)
        if (prompt_v or "").strip():
            studio.apply_ops(p, [{"op": "set_music_prompt", "text": prompt_v}], "สร้างเพลงใหม่")
        else:
            p.music.fp = ""
            p.invalidate("music")
            studio.save(p)
        p = studio.open(pid_v)
        start, stop, force = _plan_run(p, "go")
        yield from _stream(p, tick_v, start, stop, force)

    def apply_mix(pid_v, tick_v, speed_v, vol_v, duck_v, fade_v):
        if not pid_v:
            yield _frame(None, pid_v, tick_v, warn="สร้างบทก่อน")
            return
        p = studio.open(pid_v)
        cfg = studio.cfg(p)
        wants = {"tts.speed": speed_v, "music.volume_db": vol_v, "music.duck_db": duck_v, "music.fade_out": fade_v}
        ops = [{"op": "set_setting", "key": k, "value": v} for k, v in wants.items()
               if abs(float(cfg[k]) - float(v)) > 1e-9]
        if ops:
            studio.apply_ops(p, ops, "ปรับเสียง/มิกซ์")
        p = studio.open(pid_v)
        start, stop, force = _plan_run(p, "go")
        yield from _stream(p, tick_v, start, stop, force)

    # ------------------------------------------------ ตั้งค่า
    setting_keys: list[str] = []

    def save_settings(*vals):
        studio.settings.update(dict(zip(setting_keys, vals)))
        issues = studio.preflight(Project.new(""))
        msg = "✅ บันทึกแล้ว"
        if issues:
            msg += "\n\nยังขาด:\n" + "\n".join(f"- {i}" for i in issues)
        return msg

    def check_ready():
        issues = studio.preflight(Project.new(""))
        head = "✅ พร้อมใช้งานครบ" if not issues else "ยังขาด:\n" + "\n".join(f"- {i}" for i in issues)
        return head + "\n\n📊 " + studio.usage_text()

    def ollama_models():
        try:
            names = studio.list_ollama_models()
        except ForgeError as ex:
            return f"⚠️ {ex}"
        return "โมเดลใน Ollama: " + (", ".join(f"`{n}`" for n in names) if names else "_ยังไม่มี — ollama pull qwen3:14b_")

    # =====================================================================
    # เลย์เอาต์
    # =====================================================================
    with gr.Blocks(title="ShortsForge") as demo:
        pid = gr.State("")
        tick = gr.State(0)
        plan_state = gr.State(None)

        gr.HTML(views.header_html())
        with gr.Row():
            proj_dd = gr.Dropdown(label="โปรเจกต์", choices=[], value=None, scale=4, interactive=True,
                                  info="เลือกงานเก่ามาแก้ต่อได้ — ไฟล์ทุกชิ้นถูกเก็บไว้ ย้อนกลับได้")
            new_btn = gr.Button("＋ โปรเจกต์ใหม่", scale=1, size="sm")
        stepper = gr.HTML(views.stepper_html(None))
        banner = gr.HTML(views.banner_html("idle", _idle_hint(None)))
        strip = gr.HTML(views.timeline_strip_html(None, cfg0))
        with gr.Row():
            focus_scene = gr.Dropdown(label="จุดที่กำลังดู (ให้ AI เข้าใจคำว่า “ตรงนี้/อันนี้”)",
                                      choices=[("ไม่ระบุ", 0)] + [(f"ฉาก {i}", i) for i in range(1, 13)], value=0, scale=2)
            focus_area = gr.Dropdown(label="ส่วนที่กำลังแก้", choices=AREAS, value="", scale=2)
            undo_btn = gr.Button("↩ ย้อนกลับ 1 ขั้น", scale=1, size="sm")

        with gr.Row(equal_height=False):
            with gr.Column(scale=5, min_width=520):
                with gr.Tabs() as tabs:
                    # ======================= สตูดิโอ =======================
                    with gr.Tab("สตูดิโอ", id="studio"):
                        topic = gr.Textbox(label="หัวข้อคลิป", lines=2, placeholder="เช่น เทคนิคการนอนหลับให้ลึกขึ้นใน 5 นาที")
                        with gr.Row():
                            lang_dd = gr.Dropdown(label="ภาษา", choices=[("ไทย", "th"), ("English", "en")],
                                                  value=cfg0["language"], scale=1)
                            secs = gr.Slider(10, 180, value=cfg0["target_seconds"], step=1, label="ความยาว (วินาที)", scale=3)
                            nsc = gr.Slider(2, 12, value=cfg0["scene_count"], step=1, label="จำนวนฉาก", scale=2)
                        review_cb = gr.Checkbox(label="หยุดให้ตรวจทีละสเต็ป (แนะนำ) — ปุ่มหลักจะทำแค่สเต็ปถัดไปแล้วรอคุณ",
                                                value=bool(cfg0.get("workflow.review", True)))
                        with gr.Row():
                            b_script = gr.Button("① เขียนบท", variant="secondary")
                            b_go = gr.Button(studio.next_label(None), variant="primary", scale=2)
                            b_all = gr.Button("⏩ ทำรวดเดียวจนจบ", variant="secondary",
                                              visible=bool(cfg0.get("workflow.review", True)))
                            b_stop = gr.Button("■ หยุด", variant="stop", size="sm")
                        gr.Markdown("### กระดานฉาก\nแก้บทได้ตรงนี้ · ภาพแต่ละช็อตตัดตามคำพูด เปิด **✂ ตัวตัดต่อ** ของฉากเพื่อปรับจุดตัด/เปลี่ยนภาพ/พรีวิว")

                        @gr.render(inputs=[pid, tick])
                        def scene_board(pid_v, _tick):
                            if not pid_v:
                                gr.Markdown("_ยังไม่มีโปรเจกต์ — พิมพ์หัวข้อด้านบนแล้วกด “① เขียนบท”_")
                                return
                            p = studio.open(pid_v)
                            if not p.scenes:
                                gr.Markdown("_ยังไม่มีบท — กด “① เขียนบท”_")
                                return
                            cfg = studio.cfg(p)
                            board_outs = [banner, stepper, strip, tick, b_go]
                            for i, s in enumerate(p.scenes):
                                with gr.Group(elem_classes="sf-scene"):
                                    gr.HTML(views.scene_header(p, i, cfg))
                                    narr = gr.Textbox(value=s.narration, lines=3, max_lines=10, label="บทพากย์")
                                    with gr.Row():
                                        sv_n = gr.Button("บันทึกบท", size="sm")
                                        ai_b = gr.Button("ให้ AI แก้ฉากนี้", size="sm")
                                    sv_n.click(partial(save_narration, pid_v, s.id), [narr, tick], board_outs)
                                    ai_b.click(partial(focus_on, i + 1), None, [focus_scene, focus_area, tabs])
                                    if s.audio_path and Path(s.audio_path).exists():
                                        gr.Audio(value=s.audio_path, label="เสียงพากย์", interactive=False)
                                    if not s.shots:
                                        kw = gr.Textbox(value=", ".join(s.keywords),
                                                        label="คำค้นภาพ (อังกฤษ คั่นด้วย , — 1 คำค้น = 1 ช่วงพูด)")
                                        sv_k = gr.Button("บันทึกคำค้นภาพ", size="sm")
                                        sv_k.click(partial(save_keywords, pid_v, s.id), [kw, tick], board_outs)
                                        gr.Markdown("_ภาพจะขึ้นหลังสเต็ป “หาภาพ/คลิป”_")
                                        continue
                                    _cut_editor(p, s, i, pid_v, board_outs)

                    # ======================= AI Editor =======================
                    with gr.Tab("AI Editor", id="editor"):
                        gr.Markdown("พิมพ์สิ่งที่อยากแก้เป็นภาษาปกติ — AI อ่านบท/ภาพ (รู้ว่าแต่ละช็อตพูดว่าอะไร)/เสียง/เพลง และดู “จุดที่กำลังดู” "
                                    "ด้านบนเพื่อเข้าใจว่า “ตรงนี้” คืออะไร จากนั้น **สรุปว่าจะแก้อะไร** ให้ยืนยันก่อนลงมือ (ย้อนกลับได้เสมอ)")
                        instr = gr.Textbox(label="คำสั่งแก้ไข", lines=3,
                                           placeholder="เช่น “ฉาก 3 ช็อต 2 ภาพไม่ตรง อยากได้คนนอนไม่หลับในห้องมืด” หรือ “เพลงดังไป ลดลงหน่อย”")
                        with gr.Row():
                            chip_btns = [gr.Button(label, size="sm") for label, _ in CHIPS]
                        with gr.Row():
                            b_plan = gr.Button("วิเคราะห์คำสั่ง", variant="primary")
                            b_apply = gr.Button("✅ ใช้การแก้ไขนี้", variant="primary", visible=False)
                            b_drop = gr.Button("ยกเลิกแผน", size="sm", visible=False)
                        plan_md = gr.Markdown("", elem_classes="sf-plan")

                    # ======================= เสียง & เพลง =======================
                    with gr.Tab("เสียง & เพลง", id="audio"):
                        gr.Markdown("### เสียงพากย์")
                        with gr.Row():
                            tts_dd = gr.Dropdown(label="ตัวพากย์", choices=_ordered("tts"), value=cfg0["tts.provider"], scale=2)
                            voice_dd = gr.Dropdown(label="เสียง (ElevenLabs)", choices=[], value=cfg0["elevenlabs.voice_id"] or None,
                                                   allow_custom_value=True, scale=3,
                                                   info="กด “โหลดรายชื่อเสียง” หรือวาง Voice ID เอง — ภาษาไทยเลือกเสียงที่ออกไทยชัด")
                            voice_load = gr.Button("โหลดรายชื่อเสียง", size="sm", scale=1)
                        speed = gr.Slider(0.7, 1.2, value=cfg0["tts.speed"], step=0.05, label="ความเร็วพูด (เฉพาะโปรเจกต์นี้)")
                        voice_save = gr.Button("บันทึกเสียงที่เลือก (ใช้กับทุกโปรเจกต์)", size="sm")
                        gr.Markdown("### เพลงประกอบ")
                        music_dd = gr.Dropdown(label="แหล่งเพลง", choices=_ordered("music"), value=cfg0["music.provider"])
                        music_prompt = gr.Textbox(label="อธิบายเพลงที่ต้องการ (อังกฤษดีที่สุด)", lines=2,
                                                  placeholder="calm lo-fi piano, slow tempo, warm, no vocals")
                        b_music = gr.Button("สร้างเพลงใหม่ตามคำอธิบาย", variant="secondary")
                        music_audio = gr.Audio(label="เพลงที่ใช้อยู่", interactive=False)
                        gr.Markdown("### การมิกซ์ (เฉพาะโปรเจกต์นี้)")
                        with gr.Row():
                            vol = gr.Slider(-40, -5, value=cfg0["music.volume_db"], step=1, label="ระดับเพลง (dB)")
                            duck = gr.Slider(0, 24, value=cfg0["music.duck_db"], step=1, label="ลดเพลงตอนพูด (dB)")
                            fade_o = gr.Slider(0, 6, value=cfg0["music.fade_out"], step=0.1, label="เพลงเบาลงตอนจบ (วินาที)")
                        b_mix = gr.Button("ใช้ค่ามิกซ์นี้", variant="primary")

                    # ======================= ตั้งค่า =======================
                    with gr.Tab("ตั้งค่า", id="settings"):
                        gr.Markdown("ค่าทั้งหมดอยู่ที่นี่ เปลี่ยนแล้วกด **บันทึก** — สเต็ปที่ได้รับผลจะขึ้นสถานะ “ต้องทำใหม่” ให้เอง "
                                    "ส่วน API key ช่องว่าง = ไม่เปลี่ยนค่าเดิม")
                        setting_inputs: list = []
                        for gkey, glabel in GROUPS:
                            with gr.Accordion(glabel, open=(gkey in ("project", "keys"))):
                                for f in [x for x in SCHEMA if x.group == gkey]:
                                    setting_keys.append(f.key)
                                    setting_inputs.append(_make_input(f, studio.settings.values.get(f.key, f.default)))
                        with gr.Row():
                            b_save = gr.Button("บันทึกการตั้งค่า", variant="primary")
                            b_check = gr.Button("ตรวจความพร้อมของระบบ", size="sm")
                            b_ollama = gr.Button("ดูโมเดลใน Ollama", size="sm")
                        settings_md = gr.Markdown("")

            with gr.Column(scale=3, min_width=340):
                video = gr.Video(label="ตัวอย่างคลิป", interactive=False, height=620)
                files = gr.File(label="ไฟล์ที่ได้ (วิดีโอ / ซับ SRT / เครดิตคลิป)", file_count="multiple", interactive=False)
                gr.Markdown("**ประวัติการแก้ไข**")
                history_md = gr.Markdown("_ยังไม่มีประวัติการแก้ไข_")

        # ------------------------------------------------ ✂ ตัวตัดต่อของฉาก (เรียกจากกระดานฉาก)
        def _cut_editor(p: Project, s, i: int, pid_v: str, outs: list) -> None:
            try:
                plans, lead, fps = studio.scene_plan(p, s.id)
            except (ForgeError, IndexError, KeyError):
                plans, lead, fps = [], 0.0, 30
            aligned = len(plans) == len(s.shots)
            starts = beat_word_starts(s) if s.words else []
            images_on = str(studio.cfg(p).get("image.provider", "none")) not in ("", "none")
            with gr.Accordion(f"✂ ตัวตัดต่อภาพฉาก {i + 1} — {len(s.shots)} ช็อต (ตัดตามคำพูด)", open=False):
                if not aligned:
                    gr.Markdown("⚠️ _จุดตัดเปลี่ยนแล้วแต่ภาพยังไม่ได้จัดใหม่ — กดปุ่มหลักเพื่อทำสเต็ปหาภาพ_")
                for j, sh in enumerate(s.shots):
                    pl = plans[j] if aligned else None
                    t0 = (pl.start_f / fps - lead) if pl else sum(x.duration for x in s.shots[:j])
                    t1 = t0 + sh.duration
                    said = shot_text(s, plans, j) if pl else ""
                    beat = s.beats[sh.beat] if sh.beat < len(s.beats) else {}
                    is_gfx = (sh.clip or {}).get("provider") == "graphic"
                    is_ai = (sh.clip or {}).get("provider") == "aiimage"
                    is_gen = is_gfx or is_ai
                    with gr.Group(elem_classes="sf-shotbox"):
                        thumb = gx.thumbnail_data_uri(sh.path) if is_gen and sh.path and Path(sh.path).exists() else ""
                        gr.HTML(views.shot_card_html(j, sh, t0, t1, said, beat.get("text", ""), thumb))
                        g_now = beat.get("graphic") if beat.get("kind") == "graphic" else None
                        with gr.Accordion("🎨 แก้ข้อความในภาพอธิบาย" if is_gfx else "🎨 ทำช่วงนี้เป็นภาพอธิบาย",
                                          open=is_gfx):
                            tpl0 = (g_now or {}).get("template") or ""
                            with gr.Row():
                                tdd = gr.Dropdown(choices=gx.choices(), value=tpl0 or None, label="แบบภาพ", scale=1)
                                tlines = gr.Textbox(value=gx.to_lines(tpl0, g_now["data"]) if g_now else beat.get("text", ""),
                                                    lines=3, scale=3, label="ข้อความในภาพ (ทีละบรรทัด)",
                                                    info=gx.lines_help(tpl0) if tpl0 else "เลือกแบบภาพก่อน แล้วระบบจะบอกว่าแต่ละบรรทัดคืออะไร")
                            tdd.input(tpl_changed, [tdd, tlines], [tlines])
                            with gr.Row():
                                g_btn = gr.Button("💾 วาดภาพนี้" if not is_gfx else "💾 อัปเดตภาพ", size="sm")
                                g_btn.click(partial(make_graphic, pid_v, s.id, sh.beat + 1), [tdd, tlines, tick], outs)
                                if is_gfx:
                                    back_q = ", ".join(beat.get("queries") or s.keywords[:1] or [p.topic])
                                    v_btn = gr.Button("🎞 ใช้วิดีโอแทน", size="sm")
                                    v_btn.click(partial(to_video, pid_v, s.id, sh.beat + 1, back_q), [tick], outs)
                        if images_on or is_ai:
                            with gr.Accordion("🖼 ภาพ AI ของช่วงนี้" if is_ai else "🖼 ทำช่วงนี้เป็นภาพ AI", open=is_ai):
                                ip = gr.Textbox(value=beat.get("image_prompt") or beat.get("visual", ""), lines=2,
                                                label="อยากได้ภาพอะไร (อังกฤษ: สิ่งที่เห็น + กำลังทำอะไร + ที่ไหน — ไม่ต้องบอกสไตล์)")
                                with gr.Row():
                                    i_btn = gr.Button("💾 สร้างภาพตามนี้", size="sm")
                                    i_btn.click(partial(make_aiimage, pid_v, s.id, sh.beat + 1, False), [ip, tick], outs)
                                    if is_ai:
                                        r_btn = gr.Button("🎲 สุ่มภาพใหม่", size="sm")
                                        r_btn.click(partial(make_aiimage, pid_v, s.id, sh.beat + 1, True), [ip, tick], outs)
                                        back_q = ", ".join(beat.get("queries") or s.keywords[:1] or [p.topic])
                                        v2 = gr.Button("🎞 ใช้วิดีโอแทน", size="sm")
                                        v2.click(partial(to_video, pid_v, s.id, sh.beat + 1, back_q), [tick], outs)
                        if is_gen:
                            if pl and pl.part == 0 and sh.beat > 0 and s.words and starts:
                                k = sh.beat
                                lo = starts[k - 1] + 1
                                hi = (starts[k + 1] - 1) if k + 1 < len(starts) else len(s.words) - 1
                                opts = [(f"{views.fmt_t(s.words[w].start)} · {s.words[w].text}", w) for w in range(lo, hi + 1)]
                                with gr.Row():
                                    if opts:
                                        wd = gr.Dropdown(choices=opts, value=starts[k] if lo <= starts[k] <= hi else None,
                                                         scale=3, label="ตัดเข้าช็อตนี้ตอนพูดคำว่า")
                                        wd.input(partial(cut_move, pid_v, s.id, k + 1), [wd, tick], outs)
                                    rm = gr.Button("✕ ลบจุดตัดนี้", size="sm", scale=1)
                                    rm.click(partial(cut_remove, pid_v, s.id, k + 1), [tick], outs)
                            continue
                        with gr.Row():
                            q = gr.Textbox(value=", ".join(beat.get("queries") or [sh.keyword]), scale=4, show_label=True,
                                           label="ภาพที่อยากได้ช่วงนี้ (คำค้นอังกฤษ คั่นด้วย ,)")
                            q_btn = gr.Button("🔎 หาภาพใหม่", size="sm", scale=1)
                        q_btn.click(partial(research, pid_v, s.id, sh.beat + 1), [q, tick], outs)
                        with gr.Row():
                            room = float((sh.clip or {}).get("duration") or 0) - sh.duration
                            if room > 0.15:
                                st = gr.Slider(0, round(room, 1), value=min(sh.start, round(room, 1)), step=0.1, scale=3,
                                               label="ใช้คลิปตั้งแต่วินาทีที่ (เลื่อนเพื่อเลือกช่วงที่ตรงกว่า)")
                                st.release(partial(set_start, pid_v, s.id, j + 1), [st, tick], outs)
                            if pl and pl.part == 0 and sh.beat > 0 and s.words and starts:
                                k = sh.beat
                                lo = starts[k - 1] + 1
                                hi = (starts[k + 1] - 1) if k + 1 < len(starts) else len(s.words) - 1
                                opts = [(f"{views.fmt_t(s.words[w].start)} · {s.words[w].text}", w) for w in range(lo, hi + 1)]
                                if opts:
                                    wd = gr.Dropdown(choices=opts, value=starts[k] if lo <= starts[k] <= hi else None, scale=3,
                                                     label="ตัดเข้าช็อตนี้ตอนพูดคำว่า")
                                    wd.input(partial(cut_move, pid_v, s.id, k + 1), [wd, tick], outs)
                                rm = gr.Button("✕ ลบจุดตัดนี้", size="sm", scale=1)
                                rm.click(partial(cut_remove, pid_v, s.id, k + 1), [tick], outs)
                # ---- ระดับฉาก ----
                with gr.Row():
                    if s.words:
                        cut_set = set(starts)
                        add_opts = [(f"{views.fmt_t(w.start)} · {w.text}", n) for n, w in enumerate(s.words)
                                    if n > 0 and n not in cut_set]
                        add_dd = gr.Dropdown(choices=add_opts, value=None, scale=3, label="เพิ่มจุดตัดภาพตอนพูดคำว่า")
                        add_b = gr.Button("＋ เพิ่มจุดตัด", size="sm", scale=1)
                        add_b.click(partial(cut_add, pid_v, s.id), [add_dd, tick], outs)
                with gr.Row():
                    pause_now = s.pause if s.pause is not None else float(studio.cfg(p)["scene_pause"])
                    pz = gr.Slider(0, 1.5, value=pause_now, step=0.05, scale=3, label="เว้นเงียบท้ายฉาก (วินาที)")
                    pz.release(partial(set_pause, pid_v, s.id), [pz, tick], outs)
                    pv_b = gr.Button("▶ พรีวิวฉากนี้", variant="secondary", size="sm", scale=1)
                pv = gr.Video(label="พรีวิวฉาก (ภาพ + เสียงพากย์)", interactive=False, visible=True, height=360)
                pv_b.click(partial(preview, pid_v, s.id), None, [pv, banner])
                # ---- เลือกคลิปเองจากตัวเลือก ----
                cands = [c for c in s.candidates if c.get("preview_url")]
                if cands:
                    with gr.Accordion(f"เลือกคลิปอื่นเอง ({len(cands)} ตัวเลือก — เรียงตามความตรง)", open=False):
                        def cap(c):
                            sc = f"AI {c['ai_score']:.0f}/10 · " if c.get("ai_score") is not None else ""
                            return f"{sc}{(c.get('title') or c['provider'])[:40]} · {c['duration']:.0f}วิ"
                        gal = gr.Gallery(value=[(c["preview_url"], cap(c)) for c in cands], label="คลิกรูปที่ต้องการ",
                                         columns=5, height=200, allow_preview=False, interactive=False)
                        sel = gr.State(None)
                        gal.select(_on_select, None, [sel])
                        with gr.Row():
                            shot_dd = gr.Dropdown(label="ใช้แทนช็อต", value=0, scale=2,
                                                  choices=[(f"ช็อต {j}", j - 1) for j in range(1, len(s.shots) + 1)])
                            pick_b = gr.Button("ใช้คลิปนี้ (ปักหมุด)", size="sm", scale=1)
                        pick_b.click(partial(pick_clip, pid_v, s.id, cands), [sel, shot_dd, tick], outs)

        # =====================================================================
        # ผูกเหตุการณ์
        # =====================================================================
        RUN_OUTS = [pid, stepper, banner, strip, video, files, history_md, tick, music_audio, proj_dd, b_go, b_all, b_script]
        run_inputs = [pid, tick, topic, lang_dd, secs, nsc]
        proj_extra = [topic, lang_dd, secs, nsc, music_prompt]

        b_script.click(partial(run_mode, "script"), run_inputs, RUN_OUTS)
        b_go.click(partial(run_mode, "go"), run_inputs, RUN_OUTS)
        b_all.click(partial(run_mode, "all"), run_inputs, RUN_OUTS)
        b_stop.click(stop, None, None)
        review_cb.input(set_review, [review_cb, pid], [b_go, b_all, b_script])

        proj_dd.input(open_project, [proj_dd, tick], RUN_OUTS + proj_extra)
        new_btn.click(new_project_click, [tick], RUN_OUTS + proj_extra)
        demo.load(on_load, None, [proj_dd])
        undo_btn.click(undo, [pid, tick], RUN_OUTS)

        for (_, text), btn in zip(CHIPS, chip_btns):
            btn.click(partial(_const, text), None, [instr])
        b_plan.click(editor_plan, [pid, instr, focus_scene, focus_area], [plan_md, plan_state, b_apply, b_drop, b_plan])
        b_apply.click(editor_apply, [pid, tick, plan_state], RUN_OUTS + [plan_md, plan_state, b_apply, b_drop])
        b_drop.click(editor_drop, None, [plan_md, plan_state, b_apply, b_drop])

        voice_load.click(load_voices, None, [voice_dd])
        voice_save.click(save_voice, [voice_dd, tts_dd, pid], [stepper, banner, b_go])
        b_music.click(regen_music, [pid, tick, music_prompt, music_dd], RUN_OUTS)
        b_mix.click(apply_mix, [pid, tick, speed, vol, duck, fade_o], RUN_OUTS)

        b_save.click(save_settings, setting_inputs, [settings_md])
        b_check.click(check_ready, None, [settings_md])
        b_ollama.click(ollama_models, None, [settings_md])

    return demo


def launch(studio: Studio | None = None, **kw) -> None:
    studio = studio or Studio()
    demo = build_app(studio)
    try:
        demo.queue(default_concurrency_limit=4)
    except TypeError:
        demo.queue()
    theme = gr.themes.Base(primary_hue="indigo", neutral_hue="slate", radius_size="sm",
                           font=[gr.themes.GoogleFont("Noto Sans Thai"), "Tahoma", "sans-serif"])
    demo.launch(server_name=kw.pop("server_name", "127.0.0.1"), server_port=kw.pop("server_port", 7860),
                inbrowser=kw.pop("inbrowser", True), theme=theme, css=style.CSS, head=style.HEAD,
                allowed_paths=[str(studio.data_dir.resolve())], **kw)
