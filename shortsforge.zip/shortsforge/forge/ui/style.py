"""สไตล์หน้าจอ — เอกลักษณ์เดียวของหน้านี้คือ "ไม้บรรทัดไทม์โค้ด" ของแถบสเต็ป ส่วนอื่นเรียบ ให้เนื้องานเป็นพระเอก"""

HEAD = ('<link rel="preconnect" href="https://fonts.googleapis.com">'
        '<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@400;500;700&display=swap" rel="stylesheet">')

CSS = """
:root{
  --sf-ink:#1B2430; --sf-sub:#5B6676; --sf-paper:#EEF1F5; --sf-panel:#FFFFFF; --sf-line:#D3DAE4;
  --sf-accent:#2446D6; --sf-done:#14796B; --sf-run:#B7791F; --sf-err:#C2362B;
}
.dark{ --sf-ink:#E6EAF0; --sf-sub:#9AA6B6; --sf-paper:#12161C; --sf-panel:#1A2029; --sf-line:#2B3441;
  --sf-accent:#7C93FF; --sf-done:#43B8A5; --sf-run:#E3A63C; --sf-err:#F0776C; }
.gradio-container{ max-width:1560px !important; font-family:"Noto Sans Thai","Leelawadee UI",Tahoma,system-ui,sans-serif !important; }

.sf-brand{ display:flex; gap:12px; align-items:center; padding:4px 0 10px; }
.sf-brand b{ font-size:20px; color:var(--sf-ink); display:block; line-height:1.2; }
.sf-brand small{ color:var(--sf-sub); font-size:13px; }
.sf-mark{ background:var(--sf-ink); color:var(--sf-panel); font-weight:700; font-size:14px; letter-spacing:1px;
  width:38px; height:38px; border-radius:6px; display:grid; place-items:center; }

/* แถบสเต็ป: ขอบบนเป็นไม้บรรทัดขีดเวลา */
.sf-ruler{ display:grid; grid-template-columns:repeat(6,1fr); gap:0; border:1px solid var(--sf-line);
  background:var(--sf-panel); border-radius:6px 6px 0 0; overflow:hidden;
  background-image:repeating-linear-gradient(90deg, var(--sf-line) 0 1px, transparent 1px 16.6667%);
}
.sf-ruler::before{ content:""; grid-column:1/-1; height:9px;
  background-image:repeating-linear-gradient(90deg, var(--sf-sub) 0 1px, transparent 1px 10px),
                   repeating-linear-gradient(90deg, var(--sf-ink) 0 1px, transparent 1px 50px);
  background-size:100% 4px, 100% 9px; background-repeat:no-repeat; background-position:0 100%, 0 100%; opacity:.55; }
.sf-step{ padding:8px 12px 10px; display:grid; grid-template-columns:auto 1fr; column-gap:8px; align-items:baseline;
  border-left:1px solid var(--sf-line); }
.sf-step:first-of-type{ border-left:0; }
.sf-no{ font-weight:700; color:var(--sf-sub); font-size:13px; }
.sf-step b{ color:var(--sf-ink); font-size:14px; }
.sf-step i{ grid-column:2; font-style:normal; font-size:12px; color:var(--sf-sub); }
.sf-done .sf-no, .sf-done i{ color:var(--sf-done); }
.sf-running{ box-shadow:inset 0 -3px 0 var(--sf-accent); }
.sf-running .sf-no, .sf-running i{ color:var(--sf-accent); font-weight:600; }
.sf-stale{ background-image:repeating-linear-gradient(135deg, transparent 0 6px, color-mix(in srgb, var(--sf-run) 14%, transparent) 6px 7px); }
.sf-stale .sf-no, .sf-stale i{ color:var(--sf-run); }
.sf-error{ box-shadow:inset 0 -3px 0 var(--sf-err); }
.sf-error .sf-no, .sf-error i{ color:var(--sf-err); font-weight:600; }
.sf-bar{ height:4px; background:var(--sf-line); }
.sf-bar div{ height:100%; background:var(--sf-accent); transition:width .35s ease; }
.sf-msg{ padding:6px 2px 2px; font-size:13px; color:var(--sf-sub); min-height:22px; }
.sf-msg-err{ color:var(--sf-err); font-weight:500; }

/* แถบโครงเรื่อง */
.sf-strip{ display:flex; height:34px; border:1px solid var(--sf-line); border-radius:4px; overflow:hidden; background:var(--sf-panel); }
.sf-strip-empty{ align-items:center; justify-content:center; color:var(--sf-sub); font-size:13px; }
.sf-seg{ position:relative; display:grid; place-items:center; border-left:2px solid var(--sf-panel); font-size:12px; font-weight:600; color:#fff; }
.sf-seg:first-child{ border-left:0; }
.sf-role-hook{ background:#C2362B; } .sf-role-body{ background:#2446D6; } .sf-role-cta{ background:#14796B; }
.sf-seg u{ position:absolute; top:0; bottom:0; width:1px; background:rgba(255,255,255,.55); }
.sf-strip-note{ font-size:12px; color:var(--sf-sub); padding:3px 2px 0; }

.sf-scene{ border:1px solid var(--sf-line) !important; border-radius:6px !important; padding:10px 12px !important; margin-bottom:10px; }
.sf-scene-head{ display:flex; gap:10px; align-items:baseline; margin-bottom:4px; }
.sf-scene-head b{ color:var(--sf-ink); font-size:15px; }
.sf-scene-head span{ color:var(--sf-sub); font-size:12.5px; }
.sf-plan{ border-left:3px solid var(--sf-accent); padding-left:12px; }

/* แถบสถานะ: เห็นทันทีว่ากดแล้วระบบกำลังทำอะไร */
.sf-banner{ display:flex; gap:10px; align-items:center; padding:10px 14px; border-radius:6px; font-size:14.5px;
  border:1px solid var(--sf-line); background:var(--sf-panel); color:var(--sf-ink); margin-top:6px; }
.sf-banner-empty{ display:none; }
.sf-banner-busy{ border-color:var(--sf-accent); box-shadow:inset 4px 0 0 var(--sf-accent); }
.sf-banner-ok{ border-color:var(--sf-done); box-shadow:inset 4px 0 0 var(--sf-done); }
.sf-banner-warn{ border-color:var(--sf-err); box-shadow:inset 4px 0 0 var(--sf-err); color:var(--sf-err); }
.sf-banner-idle{ box-shadow:inset 4px 0 0 var(--sf-sub); }
.sf-spin{ width:16px; height:16px; border-radius:50%; border:2.5px solid var(--sf-line); border-top-color:var(--sf-accent);
  animation:sf-rot .8s linear infinite; flex:none; }
@keyframes sf-rot{ to{ transform:rotate(360deg); } }
@media (prefers-reduced-motion: reduce){ .sf-spin{ animation-duration:2.4s; } }

/* ตัวตัดต่อในฉาก */
.sf-shot{ display:grid; grid-template-columns:72px 1fr; gap:10px; align-items:start; }
.sf-shot img, .sf-noimg{ width:72px; height:128px; object-fit:cover; border-radius:4px; background:var(--sf-line); }
.sf-noimg{ display:grid; place-items:center; font-size:11px; color:var(--sf-sub); }
.sf-shot-body{ font-size:13px; color:var(--sf-ink); display:grid; gap:3px; }
.sf-said{ font-size:14px; }
.sf-meta{ color:var(--sf-sub); font-size:12.5px; }
.sf-score{ font-weight:700; font-size:12px; padding:1px 6px; border-radius:3px; color:#fff; }
.sf-score-hi{ background:var(--sf-done); } .sf-score-mid{ background:var(--sf-run); } .sf-score-lo{ background:var(--sf-err); }
.sf-pin{ font-size:12px; color:var(--sf-accent); }
.sf-gfx{ font-size:12px; font-weight:700; color:var(--sf-accent); }
.sf-shotbox{ border-top:1px dashed var(--sf-line); padding-top:8px !important; margin-top:6px; }
"""
