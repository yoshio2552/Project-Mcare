"""ตัวสร้าง HTML/ข้อความสำหรับหน้าจอ — ฟังก์ชันล้วน (ข้อมูลเข้า → ข้อความออก) ทดสอบได้โดยไม่ต้องมี Gradio"""
from __future__ import annotations

import html
from pathlib import Path

from ..core.models import STEP_LABELS, STEP_ORDER, Project
from ..skills.timing import build_timeline

STATUS_TEXT = {"pending": "รอคิว", "running": "กำลังทำ", "done": "เสร็จ", "stale": "ต้องทำใหม่", "error": "ผิดพลาด"}
ROLE_TH = {"hook": "ฮุค", "body": "เนื้อหา", "cta": "ปิดท้าย"}


def e(s) -> str:
    return html.escape(str(s or ""), quote=True)


NEXT_HINT = {
    "script": "อ่าน/แก้บทในกระดานฉากด้านล่างได้เลย พอใจแล้วกดปุ่ม ▶ ถัดไป",
    "voice": "ฟังเสียงพากย์แต่ละฉาก (แก้บทแล้วพากย์ใหม่เฉพาะฉากได้) พอใจแล้วกด ▶ ถัดไป",
    "visuals": "ดูภาพทีละช็อตใน ✂ ตัวตัดต่อของแต่ละฉาก — เปลี่ยนภาพ/เลื่อนจุดตัด/พรีวิวได้ พอใจแล้วกด ▶ ถัดไป",
    "music": "ฟังเพลงในแท็บ “เสียง & เพลง” พอใจแล้วกด ▶ ถัดไป เพื่อเรนเดอร์",
    "captions": "กด ▶ ถัดไป เพื่อเรนเดอร์",
    "render": "คลิปเสร็จแล้ว ดูได้ทางขวา — แก้อะไรเพิ่มแล้วกดเรนเดอร์ใหม่ได้เสมอ",
}


def banner_html(kind: str = "idle", text: str = "") -> str:
    """แถบสถานะใหญ่ใต้สเต็ป: บอกทันทีว่ากำลังทำอะไรอยู่ / เสร็จแล้ว / ต้องทำอะไรต่อ"""
    icon = {"busy": '<span class="sf-spin"></span>', "ok": "✅", "warn": "⚠️", "idle": "👉"}.get(kind, "")
    return f'<div class="sf-banner sf-banner-{kind}">{icon}<span>{e(text)}</span></div>' if text else \
        '<div class="sf-banner sf-banner-empty"></div>'


def fmt_t(sec: float) -> str:
    sec = max(0.0, sec)
    return f"{int(sec // 60)}:{sec % 60:04.1f}"


def shot_card_html(i: int, sh, start: float, end: float, said: str, beat_text: str, thumb: str = "") -> str:
    """การ์ดช็อตในตัวตัดต่อ: รูปตัวอย่าง + ช่วงเวลา + ประโยคที่ได้ยิน + คำค้น/แบบภาพ + คะแนน AI"""
    c = sh.clip or {}
    url = thumb or c.get("preview_url", "")
    img = (f'<img src="{e(url)}" alt="">' if url.startswith(("http://", "https://", "data:image/"))
           else f'<div class="sf-noimg">{e(c.get("provider", "?"))}</div>')
    if c.get("provider") == "aiimage":
        return (f'<div class="sf-shot">{img}<div class="sf-shot-body">'
                f'<div><b>ช็อต {i + 1}</b> · {fmt_t(start)}–{fmt_t(end)} ({end - start:.1f} วิ) '
                f'<span class="sf-gfx">🖼 ภาพ AI</span></div>'
                f'<div class="sf-said">🗣 «{e(said or beat_text)}»</div>'
                f'<div class="sf-meta">✏️ {e(c.get("title", ""))}</div></div></div>')
    if c.get("provider") == "graphic":
        return (f'<div class="sf-shot">{img}<div class="sf-shot-body">'
                f'<div><b>ช็อต {i + 1}</b> · {fmt_t(start)}–{fmt_t(end)} ({end - start:.1f} วิ) '
                f'<span class="sf-gfx">🎨 ภาพอธิบาย: {e(c.get("title", ""))}</span></div>'
                f'<div class="sf-said">🗣 «{e(said or beat_text)}»</div></div></div>')
    score = ""
    if sh.score is not None:
        lvl = "hi" if sh.score >= 7 else "mid" if sh.score >= 4 else "lo"
        score = f'<span class="sf-score sf-score-{lvl}" title="{e(sh.why)}">AI {sh.score:.0f}/10</span> <small>{e(sh.why)}</small>'
    pin = ' <span class="sf-pin">📌 เลือกเอง</span>' if sh.pinned else ""
    part = f" (ต่อ {sh.part + 1})" if sh.part else ""
    return (f'<div class="sf-shot">{img}<div class="sf-shot-body">'
            f'<div><b>ช็อต {i + 1}</b>{part} · {fmt_t(start)}–{fmt_t(end)} ({end - start:.1f} วิ){pin}</div>'
            f'<div class="sf-said">🗣 «{e(said or beat_text)}»</div>'
            f'<div class="sf-meta">🔎 {e(sh.keyword)} · {e(c.get("title", "") or c.get("id", ""))}</div>'
            f'<div>{score}</div></div></div>')


def header_html() -> str:
    return ('<div class="sf-brand"><span class="sf-mark">SF</span>'
            '<div><b>ShortsForge</b><small>โรงงานคลิปสั้น · แก้ได้ทีละชิ้น ไม่พังทั้งหมด</small></div></div>')


def stepper_html(p: Project | None, message: str = "", progress: float = 0.0, running: str | None = None) -> str:
    """แถบสเต็ปแบบไม้บรรทัดไทม์โค้ด: บอกว่าตอนนี้ถึงไหน สเต็ปไหนเสร็จ/ต้องทำใหม่/พัง"""
    cells, done = [], 0
    for i, name in enumerate(STEP_ORDER, 1):
        st = p.steps[name] if p else None
        status = "running" if name == running else (st.status if st else "pending")
        done += status == "done"
        detail = ""
        if st and st.message and status in ("done", "stale", "error"):
            detail = st.message
        cells.append(
            f'<div class="sf-step sf-{status}" title="{e(detail)}">'
            f'<span class="sf-no">{i}</span><b>{e(STEP_LABELS[name])}</b>'
            f'<i>{e(STATUS_TEXT[status])}</i></div>')
    cur = progress if running else 0.0
    pct = min(100.0, (done + cur) / len(STEP_ORDER) * 100)
    err = next((p.steps[n].message for n in STEP_ORDER if p and p.steps[n].status == "error"), "")
    msg = message or err
    cls = "sf-msg sf-msg-err" if (err and not running) else "sf-msg"
    return (f'<div class="sf-ruler">{"".join(cells)}</div>'
            f'<div class="sf-bar"><div style="width:{pct:.1f}%"></div></div>'
            f'<div class="{cls}">{e(msg)}</div>')


def timeline_strip_html(p: Project | None, cfg) -> str:
    """แถบสรุปโครงเรื่อง: ความกว้างแต่ละฉากเทียบตามเวลาจริง + เส้นแบ่งช็อตภาพ"""
    if not p or not p.scenes or not any(s.audio_duration for s in p.scenes):
        return '<div class="sf-strip sf-strip-empty">ไทม์ไลน์จะแสดงหลังพากย์เสียงเสร็จ</div>'
    tl = build_timeline(p, cfg)
    total = tl.total_frames
    blocks = []
    for i, it in enumerate(tl.items, 1):
        w = it.v_frames / total * 100
        ticks = ""
        if it.scene.shots:
            acc = 0.0
            for sh in it.scene.shots[:-1]:
                acc += sh.duration
                ticks += f'<u style="left:{min(99.0, acc / (it.v_frames / tl.fps) * 100):.1f}%"></u>'
        blocks.append(f'<div class="sf-seg sf-role-{it.scene.role}" style="width:{w:.2f}%" '
                      f'title="ฉาก {i}: {e(it.scene.narration[:80])}"><span>{i}</span>{ticks}</div>')
    return (f'<div class="sf-strip">{"".join(blocks)}</div>'
            f'<div class="sf-strip-note">รวม {tl.total:.1f} วินาที · {sum(len(i.scene.shots) for i in tl.items)} ช็อตภาพ · '
            f'เป้า {cfg["target_seconds"]} วินาที</div>')


def scene_header(p: Project, idx: int, cfg) -> str:
    s = p.scenes[idx]
    bits = [ROLE_TH.get(s.role, s.role)]
    if s.audio_duration:
        bits.append(f"{s.audio_duration:.1f} วินาที")
    bits.append(f"{len(''.join(s.narration.split()))} ตัวอักษร")
    if s.shots:
        bits.append(f"{len(s.shots)} ช็อต")
    return f'<div class="sf-scene-head"><b>ฉาก {idx + 1}</b><span>{e(" · ".join(bits))}</span></div>'


def shots_markdown(s) -> str:
    if not s.shots:
        return "_ยังไม่มีภาพ — กด “ทำต่อ” เพื่อหาภาพ_"
    lines = []
    for j, sh in enumerate(s.shots, 1):
        c = sh.clip or {}
        pin = " 📌" if sh.pinned else ""
        lines.append(f"- ช็อต {j}{pin} · `{sh.keyword}` · {c.get('provider', '?')}:{c.get('id', '?')} · {sh.duration:.1f} วินาที")
    return "\n".join(lines)


def history_markdown(items: list[dict]) -> str:
    import time as _t
    if not items:
        return "_ยังไม่มีประวัติการแก้ไข_"
    return "\n".join(f"- {_t.strftime('%H:%M:%S', _t.localtime(h['ts']))} — {h['label']}" for h in items[:8])


def plan_markdown(plan, p: Project) -> str:
    out = []
    if plan.explanation:
        out.append(f"**{plan.explanation}**")
    if plan.clarify:
        out.append(f"❓ {plan.clarify}")
    if plan.ops:
        out.append("จะทำสิ่งนี้:\n" + "\n".join(f"{i}. {line}" for i, line in enumerate(plan.describe(p), 1)))
    if plan.rejected:
        out.append("ข้ามรายการที่ใช้ไม่ได้:\n" + "\n".join(f"- {r}" for r in plan.rejected))
    return "\n\n".join(out) or "AI ไม่ได้เสนอการแก้ไข ลองอธิบายให้ละเอียดขึ้น"


def outputs_files(p: Project | None) -> list[str]:
    if not p:
        return []
    files = []
    for k in ("video", "srt"):
        f = p.outputs.get(k)
        if f and Path(f).exists():
            files.append(f)
    if p.outputs.get("credits"):
        cf = Path(p.outputs["video"]).parent / "credits.txt" if p.outputs.get("video") else None
        if cf and cf.exists():
            files.append(str(cf))
    return files
