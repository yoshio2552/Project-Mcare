"""ทดสอบภาพ AI: สไตล์ประจำช่อง, seed/สุ่มใหม่, คุมสัดส่วน, คำสั่งแก้, ไปป์ไลน์จริงด้วยตัวสร้างภาพจำลอง"""
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from forge.core.models import Project, Shot
from forge.core.settings import Settings
from forge.skills import aiimage as ai
from forge.skills.editor import apply_ops, validate_ops
from forge.skills.script_writer import build_prompt, enforce_graphics


def cfg(**kw):
    s = Settings(Path(tempfile.mkdtemp()))
    s.values.update(kw)
    return s.effective()


class Style(unittest.TestCase):
    def test_prompt_gets_channel_style_and_no_text_rule(self):
        p = ai.full_prompt("a tired brain charging like a battery", cfg(**{"image.style": "clay"}))
        self.assertIn("clay", p)
        self.assertIn("no text", p)
        self.assertIn("navy", ai.full_prompt("x", cfg(**{"image.style": "custom", "image.style_custom": "navy line art"})))
        self.assertTrue(ai.is_photoreal(cfg(**{"image.style": "cinematic"})))
        self.assertFalse(ai.is_photoreal(cfg()))

    def test_reroll_changes_seed_deterministically(self):
        b = {"text": "x", "image_prompt": "y"}
        s0 = ai.seed_for(b)
        self.assertEqual(s0, ai.seed_for(dict(b)))
        self.assertNotEqual(s0, ai.seed_for({**b, "seed": 1}))


class Planner(unittest.TestCase):
    def _p(self, kinds):
        p = Project.new("t")
        s = p.new_scene(narration="ก ข", keywords=["x"])
        s.beats = [{"text": f"b{i}", "queries": ["q"], "kind": k, "start_word": None, "visual": "",
                    **({"image_prompt": "a cat"} if k == "aiimage" else {})} for i, k in enumerate(kinds)]
        p.scenes = [s]
        return p

    def test_prompt_mentions_aiimage_only_when_a_generator_is_chosen(self):
        self.assertNotIn("aiimage", build_prompt(Project.new("t"), cfg()))
        self.assertIn('"aiimage"', build_prompt(Project.new("t"), cfg(**{"image.provider": "cloudflare"})))

    def test_disabled_generator_turns_aiimage_beats_into_footage(self):
        p = self._p(["aiimage", "stock"])
        enforce_graphics(p, cfg())
        self.assertEqual(p.scenes[0].beats[0]["kind"], "stock")

    def test_cap_and_no_three_in_a_row(self):
        p = self._p(["aiimage"] * 3 + ["stock"] * 7)
        enforce_graphics(p, cfg(**{"image.provider": "mock", "image.share": "many"}))
        self.assertEqual([b["kind"] for b in p.scenes[0].beats[:3]], ["aiimage", "aiimage", "stock"])

    def test_set_aiimage_op_and_reroll(self):
        p = self._p(["stock", "stock"])
        s = p.scenes[0]
        s.shots = [Shot("q", {"provider": "x", "id": "1"}, "/a", beat=0), Shot("q", {"provider": "x", "id": "2"}, "/b", beat=1)]
        ops, rej = validate_ops([{"op": "set_aiimage", "scene": 1, "shot": 2, "prompt": "a glowing brain"}], p)
        self.assertEqual(rej, [])
        self.assertEqual(validate_ops(ops, p)[0], ops)
        apply_ops(p, ops)
        self.assertEqual((s.beats[1]["kind"], s.beats[1]["image_prompt"]), ("aiimage", "a glowing brain"))
        ops, _ = validate_ops([{"op": "set_aiimage", "scene": 1, "beat": 2, "reroll": True}], p)
        apply_ops(p, ops)
        self.assertEqual(s.beats[1]["seed"], 1)
        self.assertEqual(s.beats[1]["image_prompt"], "a glowing brain")     # สุ่มใหม่ไม่ทำคำบรรยายหาย
        _, rej = validate_ops([{"op": "set_aiimage", "scene": 1, "beat": 1}], p)
        self.assertTrue(rej)


class Pipeline(unittest.TestCase):
    def test_mixed_video_with_ai_images_renders_and_discloses(self):
        from forge.studio import Studio
        st = Studio(data_dir=tempfile.mkdtemp())
        st.settings.update({"llm.provider": "mock", "tts.provider": "mock", "stock.providers": ["mock"],
                            "music.provider": "mock", "image.provider": "mock", "image.share": "balanced",
                            "resolution": "720x1280"}, save=False)
        p = st.new_project("การนอนหลับ", seconds=22, scenes=4)
        st.run(p)
        p = st.open(p.id)
        kinds = {(sh.clip or {}).get("provider") for s in p.scenes for sh in s.shots}
        self.assertIn("aiimage", kinds)
        self.assertEqual(p.steps["render"].status, "done")
        self.assertIn("AI-generated image", p.outputs["credits"])
        # รันซ้ำ: ภาพ AI มาจากแคช ไม่สร้างใหม่ (ไม่เสียโควตา)
        from forge.providers.image import mock as m
        calls = {"n": 0}
        orig = m.MockImage.generate

        def counting(self, *a, **k):
            calls["n"] += 1
            return orig(self, *a, **k)
        m.MockImage.generate = counting
        try:
            p.scenes[0].fp.clear()
            for s in p.scenes:
                s.fp.pop("visual", None)
            p.invalidate("visuals")
            st.save(p)
            st.run(st.open(p.id), start="visuals", stop="visuals")
        finally:
            m.MockImage.generate = orig
        self.assertEqual(calls["n"], 0)


if __name__ == "__main__":
    unittest.main()
