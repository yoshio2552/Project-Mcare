"""ทดสอบหัวใจของ "ภาพตรงคำพูด": แบ่งบทเป็น beat, ตัดช็อตตรงคำแรกของ beat, AI เลือกคลิปที่ตรงความหมาย"""
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from forge.core.models import Project, Word
from forge.core.settings import Settings
from forge.core.text import estimate_words
from forge.providers.base import Clip, LLMProvider
from forge.skills import beats as B
from forge.skills import visual_judge as vj
from forge.skills.editor import apply_ops, validate_ops
from forge.skills.timing import ANTICIPATE, MIN_BEAT_SECONDS, build_timeline, plan_scene, shot_text

NARR = "นอนไม่หลับทุกคืน ใช่ไหม ลองวิธีนี้ดู ปิดมือถือก่อนนอน หนึ่งชั่วโมง แล้วจดสิ่งที่กังวล ลงกระดาษ"


def ns(t):
    return "".join(t.split())


def cfg(**kw):
    s = Settings(Path(tempfile.mkdtemp()))
    s.values.update({"music.provider": "mock", **kw})
    return s.effective()


def scene_with_audio(narr=NARR, kws=("insomnia bed", "phone off night", "writing notebook"), dur=7.0):
    p = Project.new("sleep")
    s = p.new_scene(narration=narr, keywords=list(kws))
    p.scenes = [s]
    B.ensure_beats(s)
    s.audio_duration, s.words = dur, estimate_words(narr, dur)
    return p, s


class Beats(unittest.TestCase):
    def test_split_keeps_every_character(self):
        for k in (1, 2, 3, 5, 9):
            parts = B.split_text(NARR, [1.0] * k)
            self.assertEqual(ns("".join(parts)), ns(NARR))
            self.assertLessEqual(len(parts), k)
            self.assertTrue(all(parts))

    def test_ensure_beats_idempotent_and_follows_narration_edits(self):
        p, s = scene_with_audio()
        self.assertEqual(len(s.beats), 3)
        self.assertFalse(B.ensure_beats(s))                       # เรียกซ้ำไม่เปลี่ยน
        s.beats[1]["visual"] = "hand switching off phone"
        s.narration = "บทใหม่ สั้นกว่าเดิม มาก แต่ยังมี สามช่วง"
        self.assertTrue(B.ensure_beats(s))
        self.assertEqual(ns("".join(b["text"] for b in s.beats)), ns(s.narration))
        self.assertEqual(s.beats[1]["queries"], ["phone off night"])  # ภาพ/คำค้นของแต่ละช่วงยังอยู่
        self.assertEqual(s.beats[1]["visual"], "hand switching off phone")

    def test_cuts_land_on_first_word_of_each_beat(self):
        p, s = scene_with_audio()
        c = cfg()
        tl = build_timeline(p, c)
        plans = plan_scene(tl.items[0], tl, 0, 3.5)
        self.assertEqual(sum(x.frames for x in plans), tl.items[0].v_frames)
        starts = B.beat_word_starts(s)
        fps = tl.fps
        for x in plans:
            if x.part == 0 and x.beat > 0:
                w = s.words[starts[x.beat]]
                self.assertAlmostEqual(x.start_f / fps, tl.lead + w.start - ANTICIPATE, delta=1.0 / fps + 1e-6)
        # ข้อความที่ได้ยินในแต่ละช็อตต่อกันแล้วครบทั้งบท
        self.assertEqual(ns("".join(shot_text(s, plans, i) for i in range(len(plans)))), ns(NARR))

    def test_tiny_beats_merge_and_long_beats_split(self):
        p, s = scene_with_audio(kws=["a"], dur=11.0)          # beat เดียวยาว 11 วิ → ต้องแบ่ง
        c = cfg()
        tl = build_timeline(p, c)
        plans = plan_scene(tl.items[0], tl, 0, 3.0)
        self.assertGreaterEqual(len(plans), 3)
        self.assertTrue(all(x.beat == 0 for x in plans))
        self.assertTrue(all(x.frames >= MIN_BEAT_SECONDS * tl.fps - 1 for x in plans))
        # beat ที่สั้นกว่าเกณฑ์ → ไม่สร้างช็อตจิ๋ว
        p, s = scene_with_audio(kws=[str(i) for i in range(7)], dur=4.0)
        tl = build_timeline(p, c)
        plans = plan_scene(tl.items[0], tl, 0, 3.0)
        self.assertTrue(all(x.frames >= MIN_BEAT_SECONDS * tl.fps - 1 for x in plans))

    def test_manual_cut_split_merge(self):
        p, s = scene_with_audio()
        n = len(s.beats)
        starts = B.beat_word_starts(s)
        w = next(i for i in range(1, len(s.words)) if i not in starts)
        k = B.split_beat_at_word(s, w)
        self.assertIsNotNone(k)
        self.assertEqual(len(s.beats), n + 1)
        self.assertIn(w, B.beat_word_starts(s))
        self.assertEqual(ns("".join(b["text"] for b in s.beats)), ns(NARR))
        self.assertTrue(B.merge_beat(s, k))
        self.assertEqual(len(s.beats), n)
        self.assertEqual(ns("".join(b["text"] for b in s.beats)), ns(NARR))

    def test_set_visual_op_targets_the_beat_of_that_shot_and_avoids_old_clip(self):
        from forge.core.models import Shot
        p, s = scene_with_audio()
        s.shots = [Shot("insomnia bed", {"provider": "x", "id": "1"}, "/tmp/a", beat=0),
                   Shot("phone off night", {"provider": "x", "id": "2"}, "/tmp/b", beat=1)]
        ops, rej = validate_ops([{"op": "set_visual", "scene": 1, "shot": 2, "visual": "hand turns off smartphone in dark",
                                  "queries": ["turn off phone", "smartphone dark", "phone"]}], p)
        self.assertEqual(rej, [])
        self.assertEqual(ops[0]["beat"], 2)
        again, _ = validate_ops(ops, p)                             # validate ซ้ำได้ผลเดิม
        self.assertEqual(again, ops)
        apply_ops(p, ops)
        self.assertEqual(s.beats[1]["queries"][0], "turn off phone")
        self.assertIn("x:2", s.avoid)
        self.assertIsNone(s.shots[1].clip)
        self.assertIsNotNone(s.shots[0].clip)                       # ช็อตอื่นไม่โดนแตะ


class CountingLLM(LLMProvider):
    def __init__(self, scores):
        super().__init__(cfg())
        self.calls, self.scores = 0, scores

    def _complete(self, system, prompt, json_mode, images=None):
        import json
        self.calls += 1
        self.last_prompt = prompt
        return json.dumps({"scores": [{"id": f"A{i + 1}", "score": sc, "why": "w"} for i, sc in enumerate(self.scores)]})


class Judge(unittest.TestCase):
    def test_judge_scores_and_caches(self):
        d = Path(tempfile.mkdtemp())
        clips = [Clip("pexels", "1", "u", title="city traffic"), Clip("pexels", "2", "u", title="woman sleeping bed")]
        llm = CountingLLM([2, 9])
        kw = dict(topic="sleep", language_name="Thai", scene_text=NARR, beat_text="นอนไม่หลับทุกคืน",
                  visual="woman lying awake in bed", cache_dir=d, thumbs_dir=d / "t")
        out = vj.judge(llm, "text", clips, **kw)
        self.assertEqual(out["pexels:2"][0], 9)
        self.assertIn("นอนไม่หลับทุกคืน", llm.last_prompt)
        self.assertIn("woman sleeping bed", llm.last_prompt)
        vj.judge(llm, "text", clips, **kw)
        self.assertEqual(llm.calls, 1)                              # รอบสองมาจากแคช ไม่เสียโควตา

    def test_judge_failure_is_not_fatal(self):
        from forge.core.errors import ProviderError

        class Broken(CountingLLM):
            def _complete(self, *a, **k):
                raise ProviderError("down")
        warns = []
        out = vj.judge(Broken([]), "vision", [Clip("p", "1", "u")], topic="t", language_name="Thai", scene_text="x",
                       beat_text="x", visual="", cache_dir=Path(tempfile.mkdtemp()), thumbs_dir=Path(tempfile.mkdtemp()),
                       warn=warns.append)
        self.assertEqual(out, {})
        self.assertTrue(warns)

    def test_text_relevance(self):
        c = Clip("p", "1", "u", title="woman sleeping in bed")
        self.assertGreater(vj.text_relevance(c, "woman sleeping"), vj.text_relevance(c, "city traffic"))

    def test_local_clip_thumbnail(self):
        import subprocess
        d = Path(tempfile.mkdtemp())
        f = d / "c.mp4"
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "lavfi", "-i", "testsrc=s=640x360:d=2:r=24",
                        "-pix_fmt", "yuv420p", str(f)], check=True)
        img = vj.thumbnail(Clip("local", "c.mp4", str(f), local_path=str(f), duration=2.0), d / "t")
        self.assertTrue(img and img[:2] == b"\xff\xd8")              # JPEG


class BatchedJudge(unittest.TestCase):
    def test_one_request_judges_every_shot_of_a_scene(self):
        import json as _j

        class Spy(LLMProvider):
            def __init__(self):
                super().__init__(cfg())
                self.calls = 0

            def _complete(self, system, prompt, json_mode, images=None):
                import re
                self.calls += 1
                ids = re.findall(r"^\s+([A-Z]\d+)\.", prompt, re.M)
                return _j.dumps({"scores": [{"id": i, "score": 5 + (i[0] == "B") * 4, "why": i} for i in ids]})
        d = Path(tempfile.mkdtemp())
        groups = [("phrase a", "", [Clip("p", str(i), "u") for i in range(6)]),
                  ("phrase b", "", [Clip("p", str(i), "u") for i in range(6, 12)]),
                  ("phrase c", "", [Clip("p", str(i), "u") for i in range(12, 15)])]
        spy = Spy()
        res = vj.judge_many(spy, "text", groups, topic="t", language_name="Thai", scene_text="x", cache_dir=d,
                            thumbs_dir=d / "t")
        self.assertEqual(spy.calls, 1)
        self.assertEqual(len(res[0]), 6)
        self.assertEqual(res[1]["p:7"][0], 9)                       # คะแนนกลับไปถูกช็อต
        self.assertEqual(len(res[2]), 3)
        vj.judge_many(spy, "text", groups, topic="t", language_name="Thai", scene_text="x", cache_dir=d,
                      thumbs_dir=d / "t")
        self.assertEqual(spy.calls, 1)                              # แคช

    def test_pipeline_makes_at_most_two_judge_calls_per_scene(self):
        from forge.providers.llm.mock import MockLLM
        from forge.studio import Studio
        calls = {"n": 0}
        orig = MockLLM._complete

        def counting(self, system, prompt, json_mode, images=None):
            if "TASK: judge" in prompt:
                calls["n"] += 1
            return orig(self, system, prompt, json_mode, images)
        MockLLM._complete = counting
        try:
            st = Studio(data_dir=tempfile.mkdtemp())
            st.settings.update({"llm.provider": "mock", "tts.provider": "mock", "stock.providers": ["mock"],
                                "music.provider": "mock", "graphics.enabled": False}, save=False)
            p = st.new_project("การนอนหลับ", seconds=20, scenes=3)
            st.run(p, stop="visuals")
            p = st.open(p.id)
        finally:
            MockLLM._complete = orig
        shots = sum(len(s.shots) for s in p.scenes)
        self.assertLessEqual(calls["n"], 2 * len(p.scenes))
        self.assertLess(calls["n"], shots)                         # น้อยกว่าแบบเดิม (ช็อตละครั้ง)


class PipelinePicksMatchingClip(unittest.TestCase):
    def test_visuals_prefers_clips_whose_content_matches_the_phrase(self):
        """คลังจำลอง: ครึ่งหนึ่งชื่อตรงคำค้น อีกครึ่งเป็น 'generic background' → ต้องได้ตัวที่ตรงทุกช็อต"""
        from forge.studio import Studio
        st = Studio(data_dir=tempfile.mkdtemp())
        st.settings.update({"llm.provider": "mock", "tts.provider": "mock", "stock.providers": ["mock"],
                            "music.provider": "mock", "workflow.review": False}, save=False)
        p = st.new_project("การนอนหลับ", seconds=15, scenes=3)
        st.run(p, stop="visuals")
        p = st.open(p.id)
        shots = [sh for s in p.scenes for sh in s.shots if (sh.clip or {}).get("provider") != "graphic"]
        self.assertTrue(shots)
        for sh in shots:
            self.assertNotEqual(sh.clip["title"], "generic background", sh)
            self.assertIsNotNone(sh.score)
        # ช็อตเรียงตาม beat และไม่มีช็อตชี้ beat ที่ไม่มีอยู่
        for s in p.scenes:
            beats_seq = [sh.beat for sh in s.shots]
            self.assertEqual(beats_seq, sorted(beats_seq))
            self.assertTrue(all(0 <= b < len(s.beats) for b in beats_seq))


if __name__ == "__main__":
    unittest.main()
