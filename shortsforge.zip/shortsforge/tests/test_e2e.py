"""ทดสอบทั้งระบบด้วย provider จำลอง + ffmpeg จริง (ไม่ต้องมี API key/อินเทอร์เน็ต)

รัน:  python -m unittest discover -s tests -v
"""
from __future__ import annotations

import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from forge.core import ffmpeg
from forge.core.errors import ForgeError
from forge.core.models import STEP_ORDER, Project, downstream
from forge.skills import audio_mixer, captions, editor
from forge.skills.timing import build_timeline, plan_shots
from forge.studio import Studio

FONT = "Loma" if shutil.which("fc-list") and "Loma" in subprocess.run(
    ["fc-list"], capture_output=True, text=True).stdout else "DejaVu Sans"


def make_studio(tmp: Path) -> Studio:
    st = Studio(data_dir=tmp)
    st.settings.update({
        "llm.provider": "mock", "tts.provider": "mock", "stock.providers": ["mock"],
        "music.provider": "mock", "resolution": "720x1280", "render.preset": "ultrafast",
        "captions.font": FONT, "fps": 30,
    }, save=False)
    return st


def ebur128_integrated(path: str) -> float:
    p = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", path, "-af", "ebur128", "-f", "null", "-"],
                       capture_output=True, text=True)
    m = re.findall(r"I:\s+(-?\d+\.\d+) LUFS", p.stderr)
    return float(m[-1])


class CoreUnits(unittest.TestCase):
    def test_downstream_graph(self):
        self.assertEqual(downstream("voice"), ["voice", "visuals", "music", "captions", "render"])
        self.assertEqual(downstream("music"), ["music", "render"])
        self.assertEqual(downstream("render"), ["render"])

    def test_plan_shots_sums_and_bounds(self):
        for secs in (2.0, 5.3, 9.0, 14.7):
            frames = int(round(secs * 30))
            plan = plan_shots(frames, 30, 3.5)
            self.assertEqual(sum(plan), frames)
            self.assertTrue(all(f / 30 >= 1.0 for f in plan), plan)
            self.assertTrue(max(plan) / 30 <= 4.6, plan)

    def test_validate_rejects_bad_ops_but_keeps_good(self):
        p = Project.new("x")
        for t in ("a", "b", "c"):
            p.scenes.append(p.new_scene(narration=t * 10, keywords=["k"]))
        ops, rejected = editor.validate_ops([
            {"op": "set_narration", "scene": 2, "text": "ok"},
            {"op": "set_narration", "scene": 9, "text": "ผิดเลขฉาก"},
            {"op": "set_setting", "key": "key.elevenlabs", "value": "hack"},
            {"op": "format_disk"},
            {"op": "set_pause", "scene": 1, "seconds": 99},
        ], p)
        self.assertEqual([o["op"] for o in ops], ["set_narration"])
        self.assertEqual(len(rejected), 4)
        self.assertEqual(ops[0]["scene_id"], p.scenes[1].id)

    def test_validate_is_idempotent_for_every_op(self):
        """AI plan ผ่าน validate รอบแรก แล้ว apply_ops validate อีกรอบ — ผลต้องไม่เพี้ยน"""
        p = Project.new("x")
        for t in ("a", "b", "c"):
            p.scenes.append(p.new_scene(narration=t * 10, keywords=["k"]))
        raw = [
            {"op": "set_narration", "scene": 1, "text": "ใหม่"},
            {"op": "set_keywords", "scene": 2, "keywords": ["x y", "z"]},
            {"op": "swap_visual", "scene": 2, "shot": 2},
            {"op": "swap_visual", "scene": 3},
            {"op": "set_note", "scene": 1, "text": "โน้ต"},
            {"op": "add_scene", "after": 0, "narration": "เพิ่ม", "keywords": ["k2"], "role": "body"},
            {"op": "add_scene", "after": 2, "narration": "เพิ่ม2"},
            {"op": "move_scene", "scene": 3, "after": 1},
            {"op": "delete_scene", "scene": 2},
            {"op": "set_pause", "scene": 1, "seconds": 0.5},
            {"op": "set_music_prompt", "text": "calm"},
            {"op": "set_music_volume", "db": -20},
            {"op": "set_setting", "key": "tts.speed", "value": 1.1},
            {"op": "regenerate_script", "instruction": "สั้นลง"},
            {"op": "fit_duration", "seconds": 30},
        ]
        once, rej1 = editor.validate_ops(raw, p)
        twice, rej2 = editor.validate_ops(once, p)
        self.assertEqual(rej1, [])
        self.assertEqual(rej2, [])
        self.assertEqual(once, twice)

    def test_cannot_delete_last_scene(self):
        p = Project.new("x")
        p.scenes.append(p.new_scene(narration="a"))
        ops, rej = editor.validate_ops([{"op": "delete_scene", "scene": 1}], p)
        self.assertFalse(ops)
        self.assertTrue(rej)

    def test_ducking_expression_shape(self):
        e = audio_mixer.duck_expression([(1.0, 2.0), (4.0, 5.0)], 9)
        self.assertIn("clip(", e)
        self.assertEqual(audio_mixer.duck_expression([], 9), "1")
        self.assertEqual(audio_mixer.duck_expression([(1, 2)], 0), "1")


class EndToEnd(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        ffmpeg.require_ffmpeg()
        cls.tmp = Path(tempfile.mkdtemp(prefix="sf_test_"))
        cls.st = make_studio(cls.tmp)
        cls.p = cls.st.new_project("เทคนิคการนอนหลับให้ลึกขึ้น", seconds=20, scenes=4)
        cls.events: list = []
        cls.st.run(cls.p, on_event=cls.events.append)

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    # ---------- ผลลัพธ์หลัก ----------
    def test_01_all_steps_done_and_video_valid(self):
        p = self.p
        self.assertTrue(all(p.steps[s].status == "done" for s in STEP_ORDER),
                        {s: p.steps[s].status for s in STEP_ORDER})
        info = ffmpeg.probe(p.outputs["video"])
        self.assertEqual((info["width"], info["height"]), (720, 1280))
        self.assertTrue(info["has_audio"])
        tl = build_timeline(p, self.st.cfg(p))
        self.assertAlmostEqual(info["duration"], tl.total, delta=0.12)
        self.assertAlmostEqual(info["fps"], 30, delta=0.1)

    def test_02_events_cover_every_step_in_order(self):
        seen = [e.step for e in self.events if e.status == "done"]
        self.assertEqual(seen, STEP_ORDER)

    def test_03_scene_count_and_shots(self):
        self.assertEqual(len(self.p.scenes), 4)
        for s in self.p.scenes:
            self.assertGreaterEqual(len(s.shots), 1)
            self.assertTrue(all(Path(sh.path).exists() for sh in s.shots))
        # ฉากหนึ่งยาวเกินช็อตสูงสุด ต้องถูกแบ่งเป็นหลายช็อต
        self.assertTrue(any(len(s.shots) > 1 for s in self.p.scenes))

    def test_04_no_clip_reused_within_video(self):
        keys = [(sh.clip["provider"], sh.clip["id"]) for s in self.p.scenes for sh in s.shots]
        self.assertEqual(len(keys), len(set(keys)))

    def test_05_length_close_to_target_after_auto_fit(self):
        tl = build_timeline(self.p, self.st.cfg(self.p))
        self.assertLess(abs(tl.speech_total - 20) / 20, 0.15, tl.speech_total)

    def test_06_loudness_hits_target(self):
        lufs = ebur128_integrated(self.p.outputs["video"])
        self.assertAlmostEqual(lufs, -14.0, delta=1.5)

    def test_07_captions_in_sync_with_timeline(self):
        ass = Path(self.p.outputs["ass"]).read_text(encoding="utf-8")
        starts = [m.group(1) for m in re.finditer(r"Dialogue: 0,([\d:.]+),", ass)]
        self.assertGreater(len(starts), 4)
        to_s = lambda t: sum(float(x) * k for x, k in zip(t.split(":"), (3600, 60, 1)))
        vals = [to_s(s) for s in starts]
        self.assertEqual(vals, sorted(vals))
        tl = build_timeline(self.p, self.st.cfg(self.p))
        self.assertGreaterEqual(vals[0], tl.lead - 0.01)      # ซับไม่โผล่ก่อนเสียงพากย์เริ่ม
        self.assertLessEqual(vals[-1], tl.total)
        self.assertTrue(Path(self.p.outputs["srt"]).read_text(encoding="utf-8").startswith("1\n"))

    # ---------- incremental / undo / AI editor ----------
    def test_10_edit_narration_only_revoices_that_scene(self):
        st, p = self.st, self.p
        before = {s.id: s.audio_path for s in p.scenes}
        target = p.scenes[1]
        st.set_narration(p, target.id, "ประโยคใหม่ที่ผู้ใช้พิมพ์เองสำหรับฉากที่สองเท่านั้น ครับ")
        self.assertEqual(p.steps["voice"].status, "stale")
        self.assertEqual(p.steps["script"].status, "done")        # ไม่แตะบท/ฉากอื่น
        old_final = p.outputs["video"]
        st.run(p, start=st.next_start(p))
        after = {s.id: s.audio_path for s in p.scenes}
        changed = [i for i in before if before[i] != after[i]]
        self.assertEqual(changed, [target.id])
        self.assertNotEqual(old_final, p.outputs["video"])
        self.assertTrue(all(p.steps[s].status == "done" for s in STEP_ORDER))

    def test_11_music_volume_only_rerenders(self):
        st, p = self.st, self.p
        voice_paths = [s.audio_path for s in p.scenes]
        music_path = p.music.path
        res = st.apply_ops(p, [{"op": "set_music_volume", "db": -26}], "ทดสอบ")
        self.assertEqual(res.changed_steps, ["render"])
        self.assertEqual(p.steps["voice"].status, "done")
        st.run(p, start=st.next_start(p))
        self.assertEqual(voice_paths, [s.audio_path for s in p.scenes])
        self.assertEqual(music_path, p.music.path)                 # ไม่สร้างเพลงใหม่ (ไม่เสียเครดิต)

    def test_12_undo_restores_previous_state(self):
        st, p = self.st, self.p
        original = p.scenes[0].narration
        st.set_narration(p, p.scenes[0].id, "ข้อความที่จะถูกย้อนกลับ")
        p2 = st.undo(p)
        self.assertEqual(p2.scenes[0].narration, original)
        self.__class__.p = p2

    def test_13_ai_editor_plan_and_apply(self):
        st, p = self.st, self.p
        plan = st.plan_edit(p, "ภาพฉาก 2 เปลี่ยนเป็น city skyline sunset", {"scene": 2, "area": "visual"})
        self.assertEqual([o["op"] for o in plan.ops], ["set_keywords"])
        self.assertEqual(plan.ops[0]["scene_id"], p.scenes[1].id)
        self.assertTrue(plan.describe(p)[0].startswith("ฉาก 2"))
        old_clip = p.scenes[1].shots[0].clip["id"]
        st.apply_plan(p, plan)
        st.run(p, start=st.next_start(p))
        self.assertEqual(p.scenes[1].shots[0].keyword, "city skyline sunset")
        self.assertNotEqual(p.scenes[1].shots[0].clip["id"], old_clip)
        self.assertEqual(p.steps["voice"].status, "done")          # แก้ภาพ ไม่ต้องพากย์ใหม่

    def test_14_ai_unclear_instruction_asks_back(self):
        plan = self.st.plan_edit(self.p, "ทำให้มันดีขึ้นหน่อย")
        self.assertFalse(plan.ops)
        self.assertTrue(plan.clarify)

    def test_15_swap_visual_changes_clip_and_avoids_old(self):
        st, p = self.st, self.p
        sc = p.scenes[2]
        old = sc.shots[0].clip["id"]
        st.apply_ops(p, [{"op": "swap_visual", "scene_id": sc.id, "shot": 1}], "สลับภาพ")
        st.run(p, start=st.next_start(p))
        self.assertNotEqual(sc.shots[0].clip["id"], old)
        self.assertIn(f"mock:{old}", sc.avoid)

    def test_16_pinned_clip_survives_other_edits(self):
        st, p = self.st, self.p
        sc = p.scenes[0]
        cand = sc.candidates[0]
        st.pick_clip(p, sc.id, 0, cand)
        st.run(p, start=st.next_start(p))
        self.assertEqual(sc.shots[0].clip["id"], cand["id"])
        self.assertTrue(sc.shots[0].pinned)
        st.apply_ops(p, [{"op": "set_pause", "scene_id": p.scenes[3].id, "seconds": 0.8}], "เว้นจังหวะ")
        st.run(p, start=st.next_start(p))
        self.assertEqual(sc.shots[0].clip["id"], cand["id"])      # แก้ฉากอื่น คลิปที่ปักหมุดต้องอยู่

    def test_17_add_delete_move_scene_keeps_roles(self):
        st, p = self.st, self.p
        n0 = len(p.scenes)
        st.apply_ops(p, [{"op": "add_scene", "after": 1, "narration": "ฉากเสริมที่เพิ่มเข้ามาใหม่ ครับ",
                          "keywords": ["extra scene"]}], "เพิ่มฉาก")
        self.assertEqual(len(p.scenes), n0 + 1)
        self.assertEqual([s.role for s in p.scenes][0], "hook")
        self.assertEqual([s.role for s in p.scenes][-1], "cta")
        st.run(p, start=st.next_start(p))
        self.assertTrue(all(p.steps[s].status == "done" for s in STEP_ORDER))
        st.apply_ops(p, [{"op": "delete_scene", "scene_id": p.scenes[1].id}], "ลบฉาก")
        self.assertEqual(len(p.scenes), n0)

    def test_19_settings_change_marks_only_affected_steps_stale(self):
        st = self.st
        p = st.open(self.p.id)
        st.run(p, start=st.next_start(p))        # test_17 ทิ้งงานค้าง (ลบฉากแล้วยังไม่รัน) → ทำให้เสร็จก่อน
        p = st.open(self.p.id)
        self.assertTrue(all(p.steps[s].status == "done" for s in STEP_ORDER),
                        {s: p.steps[s].status for s in STEP_ORDER})            # ยังไม่เปลี่ยนค่า → ไม่ stale มั่ว
        st.settings.update({"captions.size": 60}, save=False)
        p = st.open(self.p.id)
        self.assertEqual(p.steps["voice"].status, "done")
        self.assertEqual(p.steps["visuals"].status, "done")
        self.assertEqual(p.steps["captions"].status, "stale")
        self.assertEqual(p.steps["render"].status, "stale")
        before = [s.audio_path for s in p.scenes]
        st.run(p, start=st.next_start(p))
        self.assertEqual(before, [s.audio_path for s in p.scenes])
        self.assertIn("Fontsize", Path(p.outputs["ass"]).read_text(encoding="utf-8"))
        # ความเร็วพูดเปลี่ยน → ต้องพากย์ใหม่ทั้งหมดและไล่ทำต่อถึงเรนเดอร์
        st.settings.update({"tts.speed": 1.1}, save=False)
        p = st.open(self.p.id)
        self.assertEqual(p.steps["voice"].status, "stale")
        st.run(p, start=st.next_start(p))
        self.assertNotEqual(before, [s.audio_path for s in p.scenes])
        self.assertTrue(all(p.steps[s].status == "done" for s in STEP_ORDER))

    def test_18_preflight_flags_missing_keys(self):
        st = Studio(data_dir=self.tmp / "other")
        st.settings.values.update({"key.elevenlabs": "", "key.gemini": "", "tts.provider": "elevenlabs",
                                   "llm.provider": "gemini", "stock.providers": ["pexels"]})
        p = st.new_project("t")
        issues = st.preflight(p)
        joined = "\n".join(issues)
        self.assertIn("Gemini", joined)
        self.assertIn("Elevenlabs", joined)
        with self.assertRaises(ForgeError):
            list(st.run_iter(p))


if __name__ == "__main__":
    unittest.main(verbosity=2)
