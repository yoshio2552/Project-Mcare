"""ทดสอบภาพอธิบาย: ตรวจข้อมูล, ตัดบรรทัดไทย, วาดได้ครบทุกแบบ (จำนวนเฟรมเป๊ะ), ตัววางแผนคุมจังหวะ, คำสั่งแก้"""
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from forge.core.models import Project, Shot
from forge.core.settings import Settings
from forge.skills import graphics as gx
from forge.skills.editor import apply_ops, validate_ops
from forge.skills.graphics.engine import _COMBINING, _LEADING, units
from forge.skills.script_writer import build_prompt, enforce_graphics, parse_graphic

FONT = "Loma" if "Loma" in subprocess.run(["fc-list"], capture_output=True, text=True).stdout else "DejaVu Sans"


def cfg(**kw):
    s = Settings(Path(tempfile.mkdtemp()))
    s.values.update(kw)
    return s.effective()


class Data(unittest.TestCase):
    def test_every_template_example_is_valid_and_roundtrips_through_lines(self):
        for name, t in gx.REGISTRY.items():
            d = gx.normalize(name, t.example)
            self.assertIsNotNone(d, name)
            back = gx.from_lines(name, gx.to_lines(name, d))
            self.assertEqual(back, d, name)
            self.assertTrue(gx.lines_help(name))

    def test_normalize_rejects_missing_and_clamps(self):
        self.assertIsNone(gx.normalize("big_number", {"value": "70%"}))           # ไม่มี label
        self.assertIsNone(gx.normalize("steps", {"title": "x", "items": ["one"]}))  # รายการน้อยไป
        self.assertIsNone(gx.normalize("nope", {"a": 1}))
        d = gx.normalize("steps", {"title": "t" * 200, "items": [f"i{i}" for i in range(9)]})
        self.assertLessEqual(len(d["title"]), 60)
        self.assertEqual(len(d["items"]), 5)
        b = gx.normalize("bar_chart", {"title": "x", "bars": [{"label": "a", "value": "9 ชม."}, {"label": "b", "value": 7}]})
        self.assertEqual(b["bars"][0]["value"], 9.0)

    def test_parse_graphic_accepts_flat_or_nested_fields(self):
        self.assertEqual(parse_graphic({"template": "headline", "text": "ว้าว"})["data"]["text"], "ว้าว")
        self.assertEqual(parse_graphic({"template": "headline", "fields": {"text": "ว้าว"}})["template"], "headline")
        self.assertIsNone(parse_graphic({"template": "headline"}))
        self.assertIsNone(parse_graphic("big_number"))


class ThaiWrap(unittest.TestCase):
    def test_wrap_never_orphans_vowels_or_tone_marks(self):
        samples = ["ร่างกายต้องการการนอนหลับอย่างน้อยเจ็ดชั่วโมงทุกคืนเพื่อซ่อมแซมตัวเอง",
                   "ปิดจอก่อนนอน 1 ชม. แล้วจะหลับไวขึ้นแบบเห็นผลในหนึ่งสัปดาห์", "short english words that wrap nicely"]
        for text in samples:
            for width in (5, 8, 12, 20):
                lines = gx.wrap(text, width)
                self.assertEqual("".join("".join(lines).split()), "".join(text.split()), (text, width))
                for ln in lines:
                    self.assertFalse(_COMBINING.match(ln[0]), (ln, width))       # ไม่ขึ้นบรรทัดด้วยสระบน/ล่าง
                    self.assertNotIn(ln[-1], _LEADING, (ln, width))             # ไม่จบบรรทัดด้วย เ แ โ ใ ไ
                    self.assertLessEqual(units(ln), width + 3, (ln, width))


class Render(unittest.TestCase):
    def test_every_template_renders_exact_frames(self):
        d = Path(tempfile.mkdtemp())
        for name, t in gx.REGISTRY.items():
            out = gx.render(name, gx.normalize(name, t.example), d, width=360, height=640, fps=24, frames=50,
                            palette=gx.palette_for("auto", name), font=FONT, lang="th", preset="ultrafast", crf=30)
            n = subprocess.run(["ffprobe", "-v", "error", "-count_frames", "-select_streams", "v:0", "-show_entries",
                                "stream=nb_read_frames", "-of", "csv=p=0", str(out)], capture_output=True, text=True)
            self.assertEqual(int(n.stdout.strip()), 50, name)
            again = gx.render(name, gx.normalize(name, t.example), d, width=360, height=640, fps=24, frames=50,
                              palette=gx.palette_for("auto", name), font=FONT, lang="th", preset="ultrafast", crf=30)
            self.assertEqual(out, again)                                        # แคช
        self.assertTrue(gx.thumbnail_data_uri(out).startswith("data:image/jpeg;base64,"))


class Planner(unittest.TestCase):
    def _project(self, kinds):
        p = Project.new("t")
        s = p.new_scene(narration="ก ข ค", keywords=["x"])
        s.beats = [{"text": f"b{i}", "queries": ["q"], "kind": k, "start_word": None, "visual": "",
                    **({"graphic": {"template": tpl, "data": {"text": "x"}}} if k == "graphic" else {})}
                   for i, (k, tpl) in enumerate(kinds)]
        p.scenes = [s]
        return p

    def test_enforce_no_three_in_a_row_and_no_repeat_template(self):
        p = self._project([("graphic", "headline"), ("graphic", "big_number"), ("graphic", "steps"),
                           ("stock", None), ("graphic", "steps"), ("graphic", "steps")])
        enforce_graphics(p, cfg(**{"graphics.share": "many"}))
        kinds = [b["kind"] for b in p.scenes[0].beats]
        self.assertEqual(kinds[:3], ["graphic", "graphic", "stock"])           # ห้ามติดกัน 3
        self.assertEqual(kinds[4:], ["graphic", "stock"])                      # แบบเดียวกันห้ามติดกัน

    def test_disabled_makes_everything_stock_and_prompt_says_so(self):
        p = self._project([("graphic", "headline"), ("stock", None)])
        enforce_graphics(p, cfg(**{"graphics.enabled": False}))
        self.assertEqual({b["kind"] for b in p.scenes[0].beats}, {"stock"})
        c = cfg(**{"graphics.enabled": False})
        self.assertIn('Every beat is real footage', build_prompt(Project.new("t"), c))
        self.assertIn('"big_number"', build_prompt(Project.new("t"), cfg()))

    def test_set_graphic_op_and_back_to_video(self):
        p = self._project([("stock", None), ("stock", None)])
        s = p.scenes[0]
        s.shots = [Shot("q", {"provider": "x", "id": "1"}, "/a", beat=0), Shot("q", {"provider": "x", "id": "2"}, "/b", beat=1)]
        ops, rej = validate_ops([{"op": "set_graphic", "scene": 1, "shot": 2, "template": "big_number",
                                  "value": "70%", "label": "ของคนนอนน้อย"}], p)
        self.assertEqual(rej, [])
        self.assertEqual(validate_ops(ops, p)[0], ops)                          # validate ซ้ำได้ผลเดิม
        apply_ops(p, ops)
        self.assertEqual(s.beats[1]["kind"], "graphic")
        self.assertEqual(s.beats[1]["graphic"]["data"]["value"], "70%")
        self.assertIsNone(s.shots[1].clip)
        _, rej = validate_ops([{"op": "set_graphic", "scene": 1, "shot": 1, "template": "big_number"}], p)
        self.assertTrue(rej)                                                    # ข้อมูลไม่ครบ → ปฏิเสธ
        ops, _ = validate_ops([{"op": "set_visual", "scene": 1, "beat": 2, "queries": ["woman sleeping"]}], p)
        apply_ops(p, ops)
        self.assertEqual(s.beats[1]["kind"], "stock")


class Pipeline(unittest.TestCase):
    def test_pipeline_renders_graphic_shots(self):
        from forge.studio import Studio
        st = Studio(data_dir=tempfile.mkdtemp())
        st.settings.update({"llm.provider": "mock", "tts.provider": "mock", "stock.providers": ["mock"],
                            "music.provider": "mock", "captions.font": FONT, "resolution": "720x1280"}, save=False)
        p = st.new_project("การนอนหลับ", seconds=18, scenes=3)
        st.run(p)
        p = st.open(p.id)
        g = [sh for s in p.scenes for sh in s.shots if (sh.clip or {}).get("provider") == "graphic"]
        self.assertTrue(g)
        self.assertTrue(all(Path(sh.path).exists() for sh in g))
        self.assertEqual(p.steps["render"].status, "done")
        self.assertNotIn("graphic", p.outputs.get("credits", ""))


if __name__ == "__main__":
    unittest.main()
