"""ทดสอบโค้ดของ provider จริง (Gemini/Ollama/ElevenLabs/Pexels/Pixabay) กับเซิร์ฟเวอร์จำลองในเครื่อง

ข้อจำกัด: เซิร์ฟเวอร์จำลองเขียนตามเอกสารของแต่ละเจ้า — ทดสอบได้ว่าโค้ดเราสร้าง request ครบ/แปลงผลลัพธ์ถูก
แต่ไม่ได้พิสูจน์ว่า API ตัวจริงตอบแบบเดียวกัน (ต้องลองด้วย key จริงอีกที)
"""
from __future__ import annotations

import base64
import json
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from forge.core import http
from forge.core.errors import ConfigError, ProviderError
from forge.core.settings import Settings
from forge.providers.base import extract_json

TMP = Path(tempfile.mkdtemp(prefix="sf_http_"))


def _ffmpeg_file(name: str, args: list[str]) -> bytes:
    f = TMP / name
    subprocess.run(["ffmpeg", "-v", "error", "-y", *args, str(f)], check=True)
    return f.read_bytes()


MP3 = _ffmpeg_file("t.mp3", ["-f", "lavfi", "-i", "sine=f=300:d=2", "-c:a", "libmp3lame"])
MP4 = _ffmpeg_file("t.mp4", ["-f", "lavfi", "-i", "gradients=s=320x568:d=2:r=24", "-c:v", "libx264", "-pix_fmt", "yuv420p"])
JPG = _ffmpeg_file("t.jpg", ["-f", "lavfi", "-i", "testsrc2=s=64x64", "-frames:v", "1"])
REQS: list[dict] = []
FLAKY = {"n": 0}


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):  # เงียบ
        pass

    def _send(self, code: int, body: bytes, ctype: str = "application/json"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj).encode())

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}")

    def do_GET(self):
        path = self.path.split("?")[0]
        REQS.append({"m": "GET", "path": self.path, "h": dict(self.headers)})
        if path == "/v1/voices":
            return self._json({"voices": [{"name": "Nok", "voice_id": "v123",
                                           "labels": {"language": "th", "gender": "female"}}]})
        if path == "/videos/search":
            return self._json({"videos": [
                {"id": 11, "url": "https://www.pexels.com/video/woman-sleeping-in-bed-11/", "duration": 9, "image": "http://x/11.jpg",
                 "user": {"name": "Ann"}, "video_files": [
                     {"file_type": "video/mp4", "width": 540, "height": 960, "link": f"{self.base()}/dl/a.mp4"},
                     {"file_type": "video/mp4", "width": 1080, "height": 1920, "link": f"{self.base()}/dl/b.mp4"},
                     {"file_type": "video/mp4", "width": 2160, "height": 3840, "link": f"{self.base()}/dl/c.mp4"},
                     {"file_type": "video/webm", "width": 1080, "height": 1920, "link": "x"}]},
                {"id": 12, "url": "https://pexels.com/v/12", "duration": 5, "image": "", "user": {},
                 "video_files": [{"file_type": "video/mp4", "width": 1280, "height": 720, "link": f"{self.base()}/dl/d.mp4"},
                                 {"file_type": "video/mp4", "width": 3840, "height": 2160, "link": f"{self.base()}/dl/e.mp4"}]}]})
        if path == "/api/videos/":
            return self._json({"hits": [{"id": 77, "pageURL": "https://pixabay.com/v/77", "duration": 12, "user": "Bob",
                                         "tags": "city, night, traffic",
                                         "videos": {
                                             "large": {"url": "", "width": 0, "height": 0},
                                             "medium": {"url": f"{self.base()}/dl/m.mp4", "width": 1080, "height": 1920, "thumbnail": "http://t/1.jpg"},
                                             "small": {"url": f"{self.base()}/dl/s.mp4", "width": 540, "height": 960, "thumbnail": "http://t/2.jpg"}}}]})
        if path.startswith("/dl/"):
            return self._send(200, MP4, "video/mp4")
        if path == "/api/tags":
            return self._json({"models": [{"name": "qwen3:14b"}]})
        self._json({"error": "nope"}, 404)

    def base(self):
        return f"http://127.0.0.1:{self.server.server_port}"

    def do_POST(self):
        path = self.path.split("?")[0]
        body = self._body()
        REQS.append({"m": "POST", "path": self.path, "h": dict(self.headers), "body": body})
        if path.startswith("/v1/text-to-speech/") and path.endswith("/with-timestamps"):
            text = body["text"]
            chars = list(text)
            starts = [round(i * 0.05, 3) for i in range(len(chars))]
            ends = [round(i * 0.05 + 0.05, 3) for i in range(len(chars))]
            return self._json({"audio_base64": base64.b64encode(MP3).decode(),
                               "alignment": {"characters": chars, "character_start_times_seconds": starts,
                                             "character_end_times_seconds": ends}})
        if path == "/v1/music":
            return self._send(200, MP3, "audio/mpeg")
        if "/ai/run/" in path:
            if "quota" in path:
                return self._json({"success": False, "errors": [
                    {"message": "You have used up your daily free allocation of 10,000 neurons"}]}, 429)
            if self.headers.get("Authorization") != "Bearer CF-SECRET-TOKEN-111":
                return self._json({"success": False, "errors": [{"message": "Authentication error"}]}, 401)
            return self._json({"result": {"image": base64.b64encode(JPG).decode()}, "success": True, "errors": []})
        if ":generateContent" in path and "image-ok" in path:
            return self._json({"candidates": [{"content": {"parts": [
                {"text": "here"}, {"inlineData": {"mimeType": "image/jpeg", "data": base64.b64encode(JPG).decode()}}]}}]})
        if ":generateContent" in path and "image-free" in path:
            return self._json({"error": {"code": 429, "message": "Quota exceeded, limit: 0"}}, 429)
        if ":generateContent" in path and "quota-day" in path:
            body429 = {"error": {"code": 429, "status": "RESOURCE_EXHAUSTED", "message": "You exceeded your current quota",
                                 "details": [{"@type": "type.googleapis.com/google.rpc.QuotaFailure", "violations": [
                                     {"quotaId": "GenerateRequestsPerDayPerProjectPerModel-FreeTier"}]},
                                     {"@type": "type.googleapis.com/google.rpc.RetryInfo", "retryDelay": "40s"}]}}
            return self._json(body429, 429)
        if ":generateContent" in path and "quota-min" in path:
            FLAKY["m"] = FLAKY.get("m", 0) + 1
            if FLAKY["m"] == 1:
                return self._json({"error": {"code": 429, "details": [
                    {"@type": "type.googleapis.com/google.rpc.RetryInfo", "retryDelay": "0.2s"}]}}, 429)
            return self._json({"candidates": [{"content": {"parts": [{"text": "{\"ok\": 1}"}]}}]})
        if ":generateContent" in path:
            FLAKY["n"] += 1
            if FLAKY["n"] == 1:                               # ครั้งแรกจำลอง 429 เพื่อทดสอบ retry
                self.send_response(429)
                self.send_header("Retry-After", "0")
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            payload = {"title": "t", "scenes": [{"role": "hook", "narration": "สวัสดี", "keywords": ["a b"]}]}
            return self._json({"candidates": [{"content": {"parts": [
                {"text": "คิดอยู่...", "thought": True}, {"text": json.dumps(payload, ensure_ascii=False)}]}}]})
        if path == "/api/chat":
            if body.get("think") is False and "bad-think" in body["model"]:
                return self._json({"error": "model does not support think"}, 400)
            content = "```json\n" + json.dumps({"ok": True, "n": len(body["messages"])}) + "\n```"
            return self._json({"message": {"role": "assistant", "content": content}})
        self._json({"error": "nope"}, 404)


class Server:
    def __enter__(self):
        self.srv = HTTPServer(("127.0.0.1", 0), H)
        self.url = f"http://127.0.0.1:{self.srv.server_port}"
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        return self

    def __exit__(self, *a):
        self.srv.shutdown()
        self.srv.server_close()


def cfg_with(**kw):
    s = Settings(TMP / "data")
    s.values.update({"key.elevenlabs": "XI-SECRET-KEY-123", "key.gemini": "GEM-SECRET-KEY-456",
                     "key.cloudflare": "CF-SECRET-TOKEN-111", "cloudflare.account_id": "acc123",
                     "key.pexels": "PEX-SECRET-KEY-789", "key.pixabay": "PIX-SECRET-KEY-000",
                     "elevenlabs.voice_id": "v123", **kw})
    http.set_redactions(v for k, v in s.values.items() if k.startswith("key."))
    return s.effective()


class ProviderHTTP(unittest.TestCase):
    def setUp(self):
        REQS.clear()
        FLAKY["n"] = 0

    def test_extract_json_variants(self):
        self.assertEqual(extract_json('```json\n{"a": 1}\n```'), {"a": 1})
        self.assertEqual(extract_json('ได้เลยครับ: {"a": {"b": [1, 2]}} จบ'), {"a": {"b": [1, 2]}})
        self.assertEqual(extract_json("<think>x</think>[1,2]"), [1, 2])
        with self.assertRaises(ProviderError):
            extract_json("ไม่มี json เลย")

    def test_gemini_request_shape_retry_and_thought_filter(self):
        from forge.providers.llm import gemini
        with Server() as srv:
            gemini.API = srv.url + "/v1beta/models/{model}:generateContent"
            llm = gemini.Gemini(cfg_with(**{"gemini.model": "gemini-3.6-flash"}))
            out = llm.generate_json("sys", "prompt")
        self.assertEqual(out["scenes"][0]["narration"], "สวัสดี")             # ข้ามส่วน thought แล้ว
        posts = [r for r in REQS if r["m"] == "POST"]
        self.assertEqual(len(posts), 2)                                       # 429 → retry สำเร็จ
        r = posts[-1]
        self.assertEqual(r["h"].get("x-goog-api-key"), "GEM-SECRET-KEY-456")
        self.assertIn("gemini-3.6-flash", r["path"])
        self.assertEqual(r["body"]["generationConfig"]["responseMimeType"], "application/json")
        self.assertEqual(r["body"]["systemInstruction"]["parts"][0]["text"], "sys")

    def test_gemini_sends_images_for_visual_judging(self):
        from forge.providers.llm import gemini
        with Server() as srv:
            gemini.API = srv.url + "/v1beta/models/{model}:generateContent"
            llm = gemini.Gemini(cfg_with())
            self.assertTrue(llm.supports_vision)
            llm.generate_json("sys", "rate these", images=[b"\xff\xd8jpeg-1", b"\xff\xd8jpeg-2"])
        parts = [r for r in REQS if r["m"] == "POST"][-1]["body"]["contents"][0]["parts"]
        imgs = [p["inline_data"] for p in parts if "inline_data" in p]
        self.assertEqual(len(imgs), 2)
        self.assertEqual(imgs[0]["mime_type"], "image/jpeg")
        self.assertEqual(base64.b64decode(imgs[1]["data"]), b"\xff\xd8jpeg-2")
        self.assertEqual(parts[0]["text"], "rate these")
        self.assertIn({"text": "[image 2]"}, parts)                    # บอกลำดับรูปให้ตรงกับเลขตัวเลือก

    def test_gemini_daily_quota_fails_fast_with_reset_time_and_light_model(self):
        import time as _t
        from forge.core import quota
        from forge.providers.llm import gemini
        quota._EXHAUSTED.clear()
        quota.DATA_DIR = TMP / "q"
        with Server() as srv:
            gemini.API = srv.url + "/v1beta/models/{model}:generateContent"
            llm = gemini.Gemini(cfg_with(**{"gemini.model": "quota-day-flash"}))
            t0 = _t.time()
            with self.assertRaises(ConfigError) as cm:
                llm.generate_json("s", "p")
            self.assertLess(_t.time() - t0, 5)                              # ไม่รอ/ไม่ลองซ้ำเปล่าๆ
            self.assertIn("โควตาฟรี", str(cm.exception))
            self.assertIn("รีเซ็ต", str(cm.exception))
            n = len([r for r in REQS if r["m"] == "POST"])
            with self.assertRaises(ConfigError):
                llm.generate_json("s", "p")                                 # รอบสอง: ไม่ยิง API อีกเลย
            self.assertEqual(len([r for r in REQS if r["m"] == "POST"]), n)
            # ข้อจำกัดต่อนาที: รอตาม retryDelay แล้วลองใหม่สำเร็จ + งานเบาใช้รุ่น Lite + นับการใช้งาน
            lite = gemini.Gemini(cfg_with(**{"gemini.model": "x", "gemini.model_light": "quota-min-lite"}))
            lite.light = True
            self.assertEqual(lite.generate_json("s", "p"), {"ok": 1})
            self.assertIn("quota-min-lite", REQS[-1]["path"])
        self.assertEqual(quota.today().get("gemini:quota-min-lite"), 1)
        self.assertIn("quota-min-lite", quota.compact())

    def test_cloudflare_image_request_and_errors(self):
        from forge.core import quota
        from forge.providers.image import cloudflare
        quota._EXHAUSTED.clear()
        with Server() as srv:
            cloudflare.API = srv.url + "/client/v4/accounts/{account}/ai/run/{model}"
            prov = cloudflare.CloudflareImage(cfg_with(**{"cloudflare.steps": 5}))
            res = prov.generate("a calm brain on a cloud", TMP / "cf.jpg", seed=42)
            r = [x for x in REQS if x["m"] == "POST"][-1]
            self.assertIn("/accounts/acc123/ai/run/@cf/black-forest-labs/flux-1-schnell", r["path"])
            self.assertEqual(r["h"].get("Authorization"), "Bearer CF-SECRET-TOKEN-111")
            self.assertEqual((r["body"]["steps"], r["body"]["seed"]), (5, 42))
            self.assertEqual((res.width, res.height), (64, 64))
            bad = cloudflare.CloudflareImage(cfg_with(**{"key.cloudflare": "wrong-token-xx"}))
            with self.assertRaises(ConfigError) as cm:
                bad.generate("x", TMP / "cf2.jpg", seed=1)
            self.assertIn("token", str(cm.exception))
            over = cloudflare.CloudflareImage(cfg_with(**{"cloudflare.image_model": "@cf/quota-model"}))
            with self.assertRaises(ConfigError) as cm:
                over.generate("x", TMP / "cf3.jpg", seed=1)
            self.assertIn("โควตาฟรี", str(cm.exception))
            no_acc = cloudflare.CloudflareImage(cfg_with(**{"cloudflare.account_id": ""}))
            with self.assertRaises(ConfigError):
                no_acc.generate("x", TMP / "cf4.jpg", seed=1)

    def test_gemini_image_parses_inline_data_and_explains_free_key(self):
        from forge.providers.image import gemini_image
        with Server() as srv:
            gemini_image.API = srv.url + "/v1beta/models/{model}:generateContent"
            ok = gemini_image.GeminiImage(cfg_with(**{"gemini.image_model": "image-ok"}))
            res = ok.generate("a fox", TMP / "gi.jpg", seed=3)
            body = [x for x in REQS if x["m"] == "POST"][-1]["body"]
            self.assertEqual(body["generationConfig"]["responseModalities"], ["IMAGE"])
            self.assertEqual(body["generationConfig"]["imageConfig"]["aspectRatio"], "9:16")
            self.assertEqual(res.width, 64)
            free = gemini_image.GeminiImage(cfg_with(**{"gemini.image_model": "image-free"}))
            with self.assertRaises(ConfigError) as cm:
                free.generate("a fox", TMP / "gi2.jpg", seed=3)
            self.assertIn("billing", str(cm.exception))

    def test_pacific_reset_time_handles_dst(self):
        from datetime import datetime, timezone
        from forge.core import quota
        self.assertEqual(quota.pacific_now(datetime(2026, 7, 1, 12, tzinfo=timezone.utc)).utcoffset().total_seconds(), -7 * 3600)
        self.assertEqual(quota.pacific_now(datetime(2026, 11, 10, 12, tzinfo=timezone.utc)).utcoffset().total_seconds(), -8 * 3600)
        self.assertEqual(quota.pacific_date(datetime(2026, 11, 10, 7, tzinfo=timezone.utc)), "2026-11-09")

    def test_ollama_vision_model_only_when_configured(self):
        from forge.providers.llm import ollama
        with Server() as srv:
            plain = ollama.Ollama(cfg_with(**{"ollama.host": srv.url, "ollama.model": "qwen3:14b"}))
            self.assertFalse(plain.supports_vision)
            plain.generate_json("s", "p", images=[b"img"])
            self.assertEqual(REQS[-1]["body"]["model"], "qwen3:14b")
            self.assertNotIn("images", REQS[-1]["body"]["messages"][-1])      # โมเดลข้อความล้วน: ไม่ส่งรูป
            vis = ollama.Ollama(cfg_with(**{"ollama.host": srv.url, "ollama.model": "qwen3:14b",
                                            "ollama.vision_model": "qwen2.5vl:7b"}))
            self.assertTrue(vis.supports_vision)
            vis.generate_json("s", "p", images=[b"img"])
            self.assertEqual(REQS[-1]["body"]["model"], "qwen2.5vl:7b")
            self.assertEqual(REQS[-1]["body"]["messages"][-1]["images"], [base64.b64encode(b"img").decode()])

    def test_ollama_fenced_json_and_think_fallback(self):
        from forge.providers.llm import ollama
        with Server() as srv:
            c = cfg_with(**{"ollama.host": srv.url, "ollama.model": "qwen3:14b"})
            out = ollama.Ollama(c).generate_json("s", "p")
            self.assertEqual(out["ok"], True)
            self.assertEqual(REQS[-1]["body"]["format"], "json")
            self.assertIs(REQS[-1]["body"]["think"], False)
            self.assertEqual(ollama.Ollama(c).list_models(), ["qwen3:14b"])
            # โมเดลที่ไม่รู้จักฟิลด์ think → ส่งใหม่โดยไม่มี think
            c2 = cfg_with(**{"ollama.host": srv.url, "ollama.model": "bad-think"})
            ollama.Ollama(c2).generate_json("s", "p")
            self.assertNotIn("think", REQS[-1]["body"])

    def test_ollama_unreachable_gives_actionable_error(self):
        from forge.providers.llm import ollama
        c = cfg_with(**{"ollama.host": "http://127.0.0.1:9", "ollama.model": "qwen3:14b"})
        with self.assertRaises(ConfigError) as cm:
            ollama.Ollama(c)._complete("", "hi", False)
        self.assertIn("Ollama", str(cm.exception))

    def test_elevenlabs_tts_alignment_to_words(self):
        from forge.providers.tts import elevenlabs
        with Server() as srv:
            elevenlabs.BASE = srv.url
            tts = elevenlabs.ElevenLabsTTS(cfg_with(**{"elevenlabs.model": "eleven_v3", "tts.speed": 1.1}))
            res = tts.synthesize("สวัสดีครับ วันนี้ มาคุยกัน", TMP / "o.mp3", language="th")
            voices = tts.list_voices()
        r = [x for x in REQS if x["m"] == "POST"][0]
        self.assertEqual(r["h"].get("xi-api-key"), "XI-SECRET-KEY-123")
        self.assertEqual(r["body"]["model_id"], "eleven_v3")
        self.assertEqual(r["body"]["language_code"], "th")
        self.assertEqual(r["body"]["voice_settings"]["speed"], 1.1)
        self.assertIn("/v1/text-to-speech/v123/with-timestamps", r["path"])
        self.assertEqual(res.meta["timing"], "alignment")
        self.assertEqual([w.text for w in res.words], ["สวัสดีครับ", "วันนี้", "มาคุยกัน"])
        self.assertAlmostEqual(res.words[1].start, 11 * 0.05, places=2)       # "สวัสดีครับ " = 11 ตัวอักษร
        self.assertGreater(res.duration, 1.5)
        self.assertEqual(voices, [("Nok (th, female)", "v123")])

    def test_elevenlabs_music_request(self):
        from forge.providers.music import elevenlabs_music as em
        with Server() as srv:
            em.URL = srv.url + "/v1/music?output_format=mp3_44100_128"
            res = em.ElevenLabsMusic(cfg_with()).compose("calm piano", 27.0, TMP / "m.mp3")
        b = REQS[-1]["body"]
        self.assertEqual((b["music_length_ms"], b["force_instrumental"], b["model_id"]), (27000, True, "music_v1"))
        self.assertGreater(res.duration, 1.5)

    def test_pexels_picks_smallest_sharp_file_and_credits(self):
        from forge.providers.stock import pexels
        with Server() as srv:
            pexels.API = srv.url + "/videos/search"
            clips = pexels.Pexels(cfg_with()).search("doctor", per_page=5)
            path = pexels.Pexels(cfg_with()).download(clips[0], TMP / "dl.mp4")
        req = [r for r in REQS if r["m"] == "GET" and "/videos/search" in r["path"]][0]
        self.assertEqual(req["h"].get("Authorization"), "PEX-SECRET-KEY-789")
        self.assertIn("orientation=portrait", req["path"])
        a, b = clips
        self.assertTrue(a.download_url.endswith("/dl/b.mp4"))        # 1080×1920 (ไม่เอา 540p ที่ไม่คม และไม่เอา 4K ที่ใหญ่เกิน)
        self.assertTrue(b.download_url.endswith("/dl/e.mp4"))        # แนวนอน: 4K คมที่สุดที่มี
        self.assertEqual(a.credit, "Video by Ann on Pexels")
        self.assertTrue(a.portrait and not b.portrait)
        self.assertEqual(a.title, "woman sleeping in bed")            # ชื่อคลิปจาก URL → ใช้ตัดสินว่าตรงบทไหม
        self.assertGreater(Path(path).stat().st_size, 1000)

    def test_pixabay_skips_empty_urls_and_hides_key_in_errors(self):
        from forge.providers.stock import pixabay
        with Server() as srv:
            pixabay.API = srv.url + "/api/videos/"
            clips = pixabay.Pixabay(cfg_with()).search("city night")
            self.assertEqual(len(clips), 1)
            self.assertTrue(clips[0].download_url.endswith("/dl/m.mp4"))
            self.assertEqual(clips[0].preview_url, "http://t/1.jpg")
            self.assertEqual(clips[0].title, "city, night, traffic")
            pixabay.API = srv.url + "/api/missing/"
            with self.assertRaises(ProviderError) as cm:
                pixabay.Pixabay(cfg_with()).search("x")
        self.assertNotIn("PIX-SECRET-KEY-000", str(cm.exception))      # key อยู่ใน URL แต่ต้องไม่หลุดลงข้อความ error


if __name__ == "__main__":
    unittest.main(verbosity=2)
