"""ทดสอบหน้า UI โดยไม่ต้องมี Gradio จริง: ใช้ gradio ปลอมที่บันทึกคอมโพเนนต์/การผูกเหตุการณ์
ตรวจ 3 อย่าง: (1) โมดูลนำเข้า/สร้างหน้าได้ (2) ทุกเหตุการณ์ผูก fn กับจำนวน inputs/outputs ที่ตรงกับพารามิเตอร์/ค่าที่คืน
(3) views ล้วนๆ ทำงานกับโปรเจกต์จริง  — ไม่ได้ยืนยันว่าหน้าตาใน Gradio จริงถูกต้อง"""
import inspect
import sys
import tempfile
import types
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


RENDERS: list = []


class Comp:
    created: list = []
    def __init__(self, *a, **k):
        self.a, self.k = a, k
        self.kind = type(self).__name__
        self.events = []
        Comp.created.append(self)
    def __enter__(self): return self
    def __exit__(self, *x): return False
    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        def bind(fn=None, inputs=None, outputs=None, *a, **k):
            self.events.append((name, fn, inputs, outputs))
            return self
        return bind


def make_fake_gradio():
    g = types.ModuleType("gradio")
    for n in ["Blocks", "State", "HTML", "Row", "Column", "Tabs", "Tab", "Dropdown", "Button", "Markdown", "Textbox",
              "Slider", "Number", "Checkbox", "CheckboxGroup", "ColorPicker", "Group", "Audio", "Gallery", "Accordion",
              "Video", "File"]:
        setattr(g, n, type(n, (Comp,), {}))
    class SelectData:  # noqa
        index = 0
    g.SelectData = SelectData
    g.Info = g.Warning = lambda *a, **k: None
    g.render = lambda inputs=None, **k: (lambda fn: (RENDERS.append(fn), fn)[1])
    th = types.SimpleNamespace(Base=lambda **k: None, GoogleFont=lambda n: n)
    g.themes = th
    return g


class UiSmoke(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls._old = sys.modules.get("gradio")
        sys.modules["gradio"] = make_fake_gradio()
        for m in [m for m in sys.modules if m.startswith("forge.ui")]:
            del sys.modules[m]
        from forge.studio import Studio
        from forge.ui import app
        cls.app = app
        cls.tmp = tempfile.TemporaryDirectory()
        cls.studio = Studio(root=ROOT, data_dir=cls.tmp.name)
        cls.studio.settings.update({"llm.provider": "mock", "tts.provider": "mock", "stock.providers": ["mock"],
                                    "music.provider": "mock", "image.provider": "mock"})
        Comp.created.clear()
        cls.demo = app.build_app(cls.studio)
        cls.built = list(Comp.created)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()
        if cls._old is None:
            sys.modules.pop("gradio", None)
        else:
            sys.modules["gradio"] = cls._old

    def test_builds_and_binds(self):
        evs = [(c, e) for c in self.built for e in c.events]
        self.assertGreater(len(evs), 20)
        bad = []
        for comp, (name, fn, inputs, outputs) in evs:
            if fn is None or not callable(fn):
                continue
            ins = inputs if isinstance(inputs, list) else ([] if inputs is None else [inputs])
            try:
                sig = inspect.signature(fn)
            except (TypeError, ValueError):
                continue
            params = [p for p in sig.parameters.values()
                      if p.default is p.empty and p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)]
            if len(params) != len(ins) and not any(p.kind == p.VAR_POSITIONAL for p in sig.parameters.values()):
                bad.append(f"{getattr(fn, '__name__', fn)}: ต้องการ {len(params)} arg แต่ผูก {len(ins)}")
        self.assertEqual(bad, [])

    def _click(self, mode):
        evs = [e for c in self.built for e in c.events if e[0] == "click" and e[1] is not None]
        hit = [e for e in evs if getattr(e[1], "func", None) is not None and e[1].args == (mode,)]
        self.assertTrue(hit, mode)
        return hit[0][1], hit[0][3]

    def _check(self, frames, outputs):
        self.assertTrue(frames)
        for fr in frames:
            self.assertEqual(len(fr), len(outputs))
        # เฟรมแรกต้องขึ้น "กำลัง…" ทันที (ผู้ใช้ไม่ต้องเดาว่ากดติดไหม) และปุ่มหลักถูกล็อก
        self.assertIn("sf-banner-busy", frames[0][2])
        self.assertFalse(frames[0][10].k.get("interactive", True))
        self.assertTrue(frames[-1][10].k.get("interactive"))

    def test_a_run_outputs_arity(self):
        """โหมดตรวจทีละสเต็ป: ปุ่มหลักต้องหยุดทุกสเต็ป ไม่วิ่งพรวดไปจนเรนเดอร์ (บั๊กที่ผู้ใช้เจอ)"""
        self.studio.settings.update({"workflow.review": True})
        go, outputs = self._click("go")
        frames = list(go("", 0, "ทดสอบการนอน", "th", 12, 3))
        self._check(frames, outputs)
        pid = frames[-1][0]
        p = self.studio.open(pid)
        self.assertEqual(p.steps["script"].status, "done")
        self.assertEqual(p.steps["voice"].status, "pending")         # หยุดหลังเขียนบท
        self.assertIn("เสียงพากย์", frames[-1][10].k["value"])          # ปุ่มบอกว่าขั้นต่อไปคืออะไร
        frames = list(go(pid, 1, "ทดสอบการนอน", "th", 12, 3))
        self._check(frames, outputs)
        p = self.studio.open(pid)
        self.assertEqual(p.steps["voice"].status, "done")
        self.assertEqual(p.steps["visuals"].status, "pending")       # หยุดหลังพากย์
        run_all, outputs = self._click("all")
        frames = list(run_all(pid, 2, "ทดสอบการนอน", "th", 12, 3))
        self._check(frames, outputs)
        p = self.studio.open(pid)
        self.assertEqual(p.steps["render"].status, "done")
        self.assertTrue(frames[-1][4])                              # มีวิดีโอ
        self.assertIn("sf-banner-ok", frames[-1][2])

    def _handler(self, name):
        for c in Comp.created + self.built:
            for _, fn, ins, outs in c.events:
                f = getattr(fn, "func", fn)
                if getattr(f, "__name__", "") == name:
                    return fn, ins, outs
        self.fail(name)

    def test_b_other_handlers(self):
        pid = self.studio.projects()[0]["id"]
        fn, ins, outs = self._handler("open_project")
        self.assertEqual(len(fn(pid, 0)), len(outs))
        self.assertEqual(len(fn("", 0)), len(outs))
        fn, ins, outs = self._handler("editor_plan")
        frames = list(fn(pid, "ฉาก 1 ให้ฮุคแรงขึ้น", 1, "script"))
        self.assertIn("⏳", frames[0][0])                             # ขึ้น "กำลังวิเคราะห์" ทันที
        self.assertTrue(all(len(f) == len(outs) for f in frames))
        fn, ins, outs = self._handler("save_settings")
        cur = [self.studio.settings.values.get(k, "") for k in self.app_keys()]
        self.assertIn("บันทึก", fn(*cur))

        # ---- กระดานฉาก (@gr.render) + ✂ ตัวตัดต่อ ----
        p0 = self.studio.open(pid)           # mock ไม่มีรูปตัวอย่าง → ใส่เองเพื่อให้ทดสอบเส้นทาง gallery/ปักหมุด
        for sc in p0.scenes:
            for c in sc.candidates:
                c["preview_url"] = "https://example.invalid/a.jpg"
            for sh in sc.shots:
                sh.clip["preview_url"] = "https://example.invalid/a.jpg"
        self.studio.save(p0)

        def board():
            Comp.created.clear()
            RENDERS[-1](pid, 0)

        board()
        RENDERS[-1]("", 0)
        board()
        fn, ins, outs = self._handler("preview")
        fr = list(fn())
        self.assertIn("sf-banner-ok", fr[-1][1], fr[-1][1])
        fn, ins, outs = self._handler("set_start")
        self.assertEqual(len(fn(0.5, 0)), len(outs))
        sid = self.studio.open(pid).scenes[1].id if len(self.studio.open(pid).scenes) > 1 else None
        p = self.studio.open(pid)
        n_before = len(p.scenes[0].shots)
        fn, ins, outs = self._handler("cut_add")              # ฉากแรก: เพิ่มจุดตัดที่คำที่ 1
        fr = list(fn(1, 0))
        self.assertTrue(all(len(f) == len(outs) for f in fr))
        p = self.studio.open(pid)
        self.assertEqual(p.steps["visuals"].status, "done", fr[-1][0])   # จัดภาพใหม่ให้ทันที
        self.assertGreaterEqual(len(p.scenes[0].beats), 2)
        board()
        fn, ins, outs = self._handler("research")
        fr = list(fn("woman sleeping, bed", 0))
        self.assertIn("sf-banner-ok", fr[-1][0], fr[-1][0])
        self.assertIn("woman sleeping", self.studio.open(pid).scenes[0].beats[0]["queries"])
        board()
        fn, ins, outs = self._handler("tpl_changed")
        upd = fn("big_number", "")
        self.assertIn("70%", upd.k["value"])                          # เลือกแบบแล้วได้ตัวอย่างข้อความให้แก้
        fn, ins, outs = self._handler("make_graphic")
        fr = list(fn("big_number", "85%\nของคนนอนดึก\nที่มา: ทดสอบ", 0))
        self.assertIn("sf-banner-ok", fr[-1][0], fr[-1][0])
        p = self.studio.open(pid)
        self.assertTrue(any((sh.clip or {}).get("provider") == "graphic" for sc in p.scenes for sh in sc.shots))
        board()
        fn, ins, outs = self._handler("make_aiimage")
        fr = list(fn("a tired brain charging like a battery", 0))
        self.assertIn("sf-banner-ok", fr[-1][0], fr[-1][0])
        p = self.studio.open(pid)
        ai = [sh for sc in p.scenes for sh in sc.shots if (sh.clip or {}).get("provider") == "aiimage"]
        self.assertTrue(ai)
        board()
        rer = [e for c in Comp.created for e in c.events if getattr(e[1], "func", None) is not None
               and e[1].func.__name__ == "make_aiimage" and e[1].args[3] is True]
        self.assertTrue(rer)                                        # มีปุ่มสุ่มภาพใหม่บนช็อตภาพ AI
        old_id = ai[0].clip["id"]
        fr = list(rer[0][1]("", 0))
        self.assertIn("sf-banner-ok", fr[-1][0], fr[-1][0])
        p = self.studio.open(pid)
        ids = [sh.clip["id"] for sc in p.scenes for sh in sc.shots if (sh.clip or {}).get("provider") == "aiimage"]
        self.assertNotIn(old_id, ids)                               # สุ่มใหม่ = ภาพใหม่จริง
        board()
        fn, ins, outs = self._handler("to_video")
        fr = list(fn(0))
        self.assertIn("sf-banner-ok", fr[-1][0], fr[-1][0])
        board()
        fn, ins, outs = self._handler("cut_remove")
        fr = list(fn(0))
        self.assertIn("sf-banner-ok", fr[-1][0], fr[-1][0])
        board()
        fn, ins, outs = self._handler("set_pause")
        fr = list(fn(0.6, 0))
        self.assertEqual(self.studio.open(pid).scenes[0].pause, 0.6)
        board()
        fn, ins, outs = self._handler("save_narration")
        r = fn("บทใหม่ทดสอบ", 0)
        self.assertEqual(len(r), len(outs))
        self.assertEqual(self.studio.open(pid).scenes[0].narration, "บทใหม่ทดสอบ")
        fn, ins, outs = self._handler("pick_clip")
        self.assertEqual(len(fn(None, 0, 0)), len(outs))           # ยังไม่เลือกรูป → เตือนเฉยๆ
        self.assertEqual(len(fn(0, 0, 0)), len(outs))              # เลือกรูปแรก → ปักหมุดช็อต 1
        self.assertTrue(any(sc.shots and sc.shots[0].pinned for sc in self.studio.open(pid).scenes))
        fn, ins, outs = self._handler("undo")
        self.assertEqual(len(fn(pid, 0)), len(outs))

    def app_keys(self):
        from forge.core.settings import GROUPS, SCHEMA
        return [f.key for g, _ in GROUPS for f in SCHEMA if f.group == g]      # ลำดับเดียวกับหน้าตั้งค่า

    def test_c_views_pure(self):
        from forge.ui import views
        p = self.studio.open(self.studio.projects()[0]["id"])
        cfg = self.studio.cfg(p)
        for s in (views.stepper_html(p, "x", .5, "voice"), views.timeline_strip_html(p, cfg),
                  views.scene_header(p, 0, cfg), views.shots_markdown(p.scenes[0]),
                  views.history_markdown(self.studio.history(p))):
            self.assertIsInstance(s, str)
        self.assertIn("sf-ruler", views.stepper_html(None))
        self.assertTrue(views.outputs_files(p))


if __name__ == "__main__":
    unittest.main()
